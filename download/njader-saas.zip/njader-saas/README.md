# NJADDER SaaS — Telegram Login Flow

تطبيق Next.js 16 كامل لتسجيل دخول تيليجرام (GramJS + Prisma + JWT + KV store محلي).

## التشغيل المحلي

```bash
# 1) ثبّت الحزم
bun install   # أو npm install

# 2) أنشئ ملف .env (المشروع يأتي مع .env يحتوي DATABASE_URL=file:./db/custom.db)

# 3) ادفع schema لقاعدة البيانات
bun run db:push

# 4) أنشئ حساب المالك
bun run create-owner
# username: NMDDER
# password: njader-owner-2026

# 5) شغّل السيرفر
bun run dev   # http://localhost:3000
```

## الحساب الافتراضي للمالك

- Username: `NMDDER`
- Password: `njader-owner-2026`
- Email: `owner@njader.dev`
- لوحة المالك: `/admin-secret`
- لوحة API pool: `/admin/api-pool`

## لتشغيل تسجيل دخول تيليجرام الحقيقي

1. سجّل دخول كمالك
2. اذهب إلى `/admin/api-pool`
3. أضف `api_id` و `api_hash` حقيقيين من https://my.telegram.org/apps
4. جرّب `/telegram-login`

## النشر على Vercel

1. بدّل في `prisma/schema.prisma`:
   - `provider = "postgresql"`
   - `url = env("POSTGRES_URL")`
2. أنشئ Postgres + KV في Vercel Storage
3. استبدل `src/lib/kv-store.ts` بـ `@vercel/kv` (اختياري للحالة متعددة المثيلات)
4. اضبط متغيرات البيئة: `POSTGRES_URL`, `KV_REST_API_URL`, `KV_REST_API_TOKEN`, `NEXTAUTH_SECRET`

## التقنيات

- Next.js 16 (App Router) + TypeScript 5
- Prisma ORM (SQLite محلياً، PostgreSQL على Vercel)
- GramJS (`telegram@2.26.x`) — تسجيل دخول تيليجرام بدون Python
- bcryptjs + jose (JWT cookies) للمصادقة
- shadcn/ui + Tailwind CSS 4
- KV store محلي (in-memory مع TTL)

## بنية المشروع

```
src/
├── app/
│   ├── (auth)/          # login + signup
│   ├── (dashboard)/     # dashboard + accounts + telegram-login + admin
│   ├── api/             # auth + telegram + admin routes
│   └── page.tsx         # landing
├── components/
│   ├── telegram/        # TelegramLogin component
│   ├── dashboard/       # nav
│   └── ui/              # shadcn/ui
├── lib/
│   ├── auth.ts          # JWT + bcrypt
│   ├── db.ts            # Prisma client
│   ├── kv-store.ts      # local KV (TTL)
│   └── telegram/client.ts  # GramJS client
├── scripts/create-owner.ts
└── prisma/schema.prisma
```

© 2026 NMDDER · @NMDDER_DEV
