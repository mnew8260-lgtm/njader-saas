# njadder

Professional Telegram automation suite — merged from `opthree.py`,
`ramexfour.py`, and `ts.py`.

## Features

- **Modular architecture**: 9 categories, ~24 Python files (all < 350 lines)
- **Async-first**: proper `async`/`await` patterns via Pyrogram
- **Type-safe**: full type hints throughout; PEP 604 unions on Python 3.10+
- **Tested**: unit tests for helpers, dedup, config, errors, scrapers
- **Anti-detection**: smart delays (log-normal distribution), per-phone
  session locking, human-like inter-action jitter
- **3-layer dedup**: in-memory set + disk CSV + live API check
- **Multi-strategy add_member**: `InputPhoneContact` → `add_contact` →
  `add_chat_members` by ID → by username → `get_users` retry
- **CSV reports**: one file per operation with timestamp
- **ErrorCounter**: smart thresholds (`PeerIdInvalid` doesn't stop,
  only `PeerFlood` / banned do)
- **CLI flags**: `--config`, `--log`, `--no-color`, `-v`, `--version`

## Installation

```bash
pip install -r requirements.txt            # runtime deps
pip install -r requirements-dev.txt        # + dev tools (pytest, ruff, …)
# Or, install as a package (creates the `njadder` console entry-point):
pip install .
```

## Configuration

Edit `config.ini`:

```ini
[NJaddingZone]
api_id = YOUR_API_ID_HERE
api_hash = YOUR_API_HASH_HERE
startingaccount = 1
endaccount = 50
enterstop = 1000000
togroup = @your_target_group
fromgroup = @source_group
phone = +9665XXXXXXXXX
proxy_enabled = false
proxy_type = socks5
proxy_host = 127.0.0.1
proxy_port = 1080
proxy_username =
proxy_password =
support_group = @NMDDER_SUPPORT
```

Get `api_id` and `api_hash` from <https://my.telegram.org> → API development tools.

You can override the config path at runtime with `--config /path/to/config.ini`
or the `NJADDER_CONFIG` environment variable.

## 🔐 Secure Login (per-account API + device + proxy rotation)

The **Accounts → 2. SECURE LOGIN** menu item is the recommended way to log
in multiple accounts. It reads three optional CSV files and rotates them
per account so every saved session has a different fingerprint:

| File           | Format                                | Purpose                            |
|----------------|----------------------------------------|------------------------------------|
| `api.csv`      | `api_id,api_hash` (one per row)       | Per-account unique API credentials |
| `devices.csv`  | `device_model,system_version,app_version` | Per-account device spoofing |
| `proxies.csv`  | `type,host,port,username,password`    | Per-account proxy with failover    |

If any file is missing, the corresponding fallback is used:
- No `api.csv` → all accounts use `config.ini` API (high risk).
- No `devices.csv` → built-in pool of 10 popular phones.
- No `proxies.csv` → all accounts use the same IP (HIGH RISK).

Templates are provided: `api.csv.example`, `devices.csv.example`,
`proxies.csv.example`. Copy them to drop the `.example` suffix and edit.

Features:
- **Round-robin rotation** — if you have 100 accounts and 10 APIs, each API
  is used for 10 accounts max.
- **Failover** — if a proxy is dead, the next available one is used
  automatically with a warning in the log.
- **Pre-flight check** — all proxies are tested before any login starts.
- **Resource summary** — before login, the tool prints how many APIs,
  proxies, and devices will be used and how they are distributed.

## Usage

```bash
# Interactive menu
python -m njadder

# With explicit config file and verbose logging
python -m njadder --config /etc/njadder.ini -v

# Disable colors and log to a custom file
python -m njadder --no-color --log /var/log/njadder.log

# Print version and exit
python -m njadder --version

# After `pip install .`, the console entry-point is also available:
njadder
```

## Project Structure

```
njadder/
├── __init__.py             # lazy public API (Config, SessionManager, ...)
├── __main__.py             # argparse + setup_logging + entry point
├── config.py               # Config wrapper (singleton via get_config)
├── core/
│   ├── session.py          # per-phone async-locked Pyrogram client
│   ├── errors.py           # ErrorCounter + exception hierarchy
│   ├── dedup.py            # DedupManager (in-mem + disk CSV)
│   ├── helpers.py          # smart_delay, load_phones, chunk_list, ...
│   └── report.py           # OpReport (async-safe CSV writer)
├── scrapers/               # public/private/hidden/full/premium
├── adders/                 # direct/contact/bulk/file_to_contacts/
│   │                         contacts_to_group/ramex/single
│   └── base.py             # _add_member_safe_v44 + sub-strategies
├── nearby/                 # NearbyAdder with COUNTRY_MAP (20 countries)
├── messaging/              # send_to_group, send_to_group_with_photo,
│   │                         forward_to_channels
├── reports/                # 11 report reasons unified into run_report()
├── account/                # login, otp_viewer, profile tools
├── utilities/              # csv_tools (blank remover, ban filter, …)
└── ui/
    ├── colors.py           # ANSI colors with graceful fallback
    └── menu.py             # interactive CLI menu
```

## Categories Explained

### 1. Accounts
- `login_all()` — login all accounts + join support channels
- `ban_filter()` — remove banned numbers from `phone.csv`
- `otp_viewer()` — view latest OTP code from chat `777000`
- `account_info_getter()` — show account info

### 2. Scrapers
- `PublicScraper` — get members from public groups (with A-Z distribution)
- `PrivateScraper` — same for private groups (via invite link)
- `HiddenScraper` — get members from chat history (hidden users)
- `FullScraper` — A-Z distribution with a higher per-account cap
- `PremiumScraper` — only Telegram Premium members

### 3. Adders
- `DirectAdder` — source → target group, direct add
- `ContactAdder` — add via `add_contact` first (v44 multi-strategy)
- `BulkAdder` — add the user's own contacts in batches
- `FileToContactsAdder` — read `data.csv` → add as contacts
- `ContactsToGroupAdder` — contacts → target group
- `RamexAdder` — unified scraper + adder with 7 modes
  (`all`, `hidden`, `daily`, `weekly`, `monthly`, `online`, `nonactive`)
- `SingleAdder` — one-by-one addition

### 4. Filters
Daily, Weekly, Monthly, Online, Non-Active, Hidden — all unified in
`RamexAdder` (mode parameter).

### 5. Nearby
20 country-specific functions unified into one `NearbyAdder` with
`COUNTRY_MAP`.

### 6. Messaging
- `send_to_group()` — broadcast a text message
- `send_to_group_with_photo()` — broadcast a photo + caption
- `forward_to_channels()` — forward recent source-channel posts

### 7. Reports
11 separate `reportreason*` functions unified into
`run_report(reason_type, channel, post_id, num=5, delay=2.0)`. Reasons:
`fake`, `spam`, `violence`, `childabuse`, `copyright`, `geoirrelevant`,
`personaldetails`, `illegaldrugs`, `pornography`, `others`.

### 8. Account Tools
Change first/last name & bio, set profile picture (other tools pending
implementation — marked in the menu).

### 9. Utilities
CSV blank remover (atomic write), auto-remove banned numbers, status viewer.

## Tests

```bash
pip install -r requirements-dev.txt
pytest -v
```

## Development

```bash
# Format
black njadder tests
# Lint
ruff check njadder tests
# Type check
mypy njadder
```

## License

MIT — see [LICENSE](LICENSE).
