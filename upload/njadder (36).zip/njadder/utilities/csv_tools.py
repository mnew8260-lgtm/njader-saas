"""CSV utilities: clean, filter, deduplicate phone.csv.

Plus VCF extraction, phone-number validation, dedup cleanup, and
group-operations helpers (auto group maker, limit checker, group
chat cloner).
"""
from __future__ import annotations

import asyncio
import csv
import logging
import os
import random
import string
from pathlib import Path
from typing import Any

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# phone.csv maintenance
# ---------------------------------------------------------------------------

def csv_blank_remover(phone_file: str = "phone.csv") -> None:
    """Remove blank lines from ``phone_file`` (atomic write)."""
    p = Path(phone_file)
    if not p.exists():
        p.touch()
        print(f"[i] Created empty {phone_file}")
        return
    with open(p, "r", encoding="utf-8") as f:
        lines = f.readlines()
    clean = [line for line in lines if line.strip()]
    if len(lines) != len(clean):
        tmp = p.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(clean)
        os.replace(str(tmp), str(p))
        print(f"[+] Removed {len(lines) - len(clean)} blank lines")
    else:
        print("[i] No blank lines found")


def auto_remove(phone_file: str = "phone.csv", ban_file: str = "BanNumbers.csv") -> None:
    """Remove banned numbers (listed in ``ban_file``) from ``phone_file``."""
    p_phone = Path(phone_file)
    p_ban = Path(ban_file)
    if not p_phone.exists():
        print(f"[!] {phone_file} not found")
        return
    if not p_ban.exists():
        p_ban.touch()
        print(f"[i] No {ban_file} found — created empty. 0 banned numbers removed.")
        return
    with open(p_phone, "r", encoding="utf-8") as f:
        phones = {line.strip() for line in f if line.strip()}
    with open(p_ban, "r", encoding="utf-8") as f:
        banned = {line.strip().replace(",", "") for line in f if line.strip()}
    keep = phones - banned
    tmp = p_phone.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for ph in keep:
            f.write(ph + "\n")
    os.replace(str(tmp), str(p_phone))
    print(f"[+] Removed {len(phones) - len(keep)} banned numbers")


def ban_filter(phone_file: str = "phone.csv", ban_file: str = "BanNumbers.csv") -> int:
    """Run :func:`auto_remove` and report before/after counts."""
    p = Path(phone_file)
    if not p.exists():
        print(f"[!] {phone_file} not found")
        return 0
    with open(p, "r", encoding="utf-8") as f:
        before = sum(1 for line in f if line.strip())
    auto_remove(phone_file, ban_file)
    with open(p, "r", encoding="utf-8") as f:
        after = sum(1 for line in f if line.strip())
    print(f"[i] Before: {before}, After: {after}, Removed: {before - after}")
    return before - after


def specific_acc_remove(phone_file: str = "phone.csv") -> None:
    """Interactive removal of one phone number from ``phone_file``."""
    p = Path(phone_file)
    if not p.exists():
        print(f"[!] {phone_file} not found")
        return
    target = input("Enter phone number to remove: ").strip()
    if not target:
        return
    with open(p, "r", encoding="utf-8") as f:
        lines = f.readlines()
    keep = [line for line in lines if target not in line]
    tmp = p.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.writelines(keep)
    os.replace(str(tmp), str(p))
    print(f"[+] Removed {len(lines) - len(keep)} lines")


# ---------------------------------------------------------------------------
# VCF (vCard) extraction
# ---------------------------------------------------------------------------

def extract_vcf_to_numbers(
    vcf_path: str,
    out_path: str = "numbers.csv",
) -> int:
    """Extract phone numbers from a vCard (.vcf) file to a CSV.

    The output CSV has a single ``numbers`` column. Requires the
    optional ``vobject`` dependency (``pip install vobject``).
    """
    try:
        import vobject  # type: ignore[import]
    except ImportError:
        log.error("vobject not installed — run: pip install vobject")
        return 0

    p = Path(vcf_path)
    if not p.exists():
        log.error("VCF file not found: %s", vcf_path)
        return 0

    try:
        with open(p, "r", encoding="utf-8") as f:
            data = f.read()
    except Exception as e:
        log.error("Failed to read %s: %s", vcf_path, e)
        return 0

    numbers: list[str] = []
    try:
        for vcard in vobject.readComponents(data):
            if "tel" in vcard.contents:
                for tel in vcard.tel_list:
                    numbers.append(tel.value)
    except Exception as e:
        log.error("vobject parse error: %s", e)
        return 0

    with open(out_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["numbers"])
        for n in numbers:
            w.writerow([n])

    log.info("Extracted %d numbers → %s", len(numbers), out_path)
    return len(numbers)


# ---------------------------------------------------------------------------
# Phone-number validation (via Telegram API)
# ---------------------------------------------------------------------------

async def check_numbers(
    session_mgr: SessionManager,
    numbers_csv: str = "numbers.csv",
    out_csv: str = "filternumbers.csv",
    delay: float = 3.0,
) -> int:
    """Check which phone numbers are registered on Telegram.

    Uses the first account in ``phone.csv`` to call
    ``contacts.ResolvePhone`` for each number in ``numbers_csv``.
    Valid numbers are appended to ``filternumbers.csv``.

    Returns:
        Count of valid numbers.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv — needed to authenticate")
        return 0

    numbers_path = Path(numbers_csv)
    if not numbers_path.exists():
        log.error("%s not found", numbers_csv)
        return 0

    numbers: list[str] = []
    with open(numbers_path, "r", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows:
        log.error("%s is empty", numbers_csv)
        return 0
    # Skip a header row if the first cell is non-numeric.
    first_val = (rows[0][0] if rows[0] else "").strip()
    try:
        int(first_val.replace("+", "").replace("-", "").replace(" ", ""))
    except ValueError:
        rows = rows[1:]
    for row in rows:
        if row and row[0].strip():
            numbers.append(row[0].strip())

    from pyrogram.raw import functions

    valid = 0
    async with session_mgr.acquire(phones[0]) as app:
        for num in numbers:
            try:
                result = await app.invoke(
                    functions.contacts.ResolvePhone(phone=num)
                )
                if result and result.users:
                    valid += 1
                    with open(out_csv, "a", encoding="utf-8", newline="") as f:
                        csv.writer(f).writerow([num])
                    log.info("%s: valid (user_id=%s)", num, result.users[0].id)
                else:
                    log.info("%s: not a Telegram user", num)
            except Exception as e:
                log.warning("%s: %s", num, e)
            await asyncio.sleep(delay)

    log.info("Validation complete: %d valid / %d total", valid, len(numbers))
    return valid


# ---------------------------------------------------------------------------
# data.csv cleanup: delete already-done rows
# ---------------------------------------------------------------------------

def delete_already_filter(
    data_csv: str = "data.csv",
    done_csv: str = "done.csv",
) -> int:
    """Remove rows from ``data.csv`` whose user_id is already in ``done.csv``.

    Returns:
        Number of rows removed.
    """
    data_path = Path(data_csv)
    done_path = Path(done_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0
    if not done_path.exists():
        log.warning("%s not found — nothing to filter", done_csv)
        return 0

    # Load done user_ids.
    done_ids: set[str] = set()
    with open(done_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            uid = str(row.get("user_id", "") or "").strip()
            if uid:
                done_ids.add(uid)

    if not done_ids:
        log.info("done.csv has no user_ids — nothing to filter")
        return 0

    # Filter data.csv rows.
    kept_rows: list[dict[str, Any]] = []
    removed = 0
    fieldnames: list[str] = []
    with open(data_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or ["user_id"]
        for row in reader:
            uid = str(row.get("user_id", "") or "").strip()
            if uid in done_ids:
                removed += 1
            else:
                kept_rows.append(row)

    # Atomic rewrite.
    tmp = data_path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(kept_rows)
    os.replace(str(tmp), str(data_path))

    log.info("Removed %d already-done rows from %s", removed, data_csv)
    return removed


# ---------------------------------------------------------------------------
# Auto Group Maker — create supergroups with random usernames
# ---------------------------------------------------------------------------

def _random_username(length: int = 12) -> str:
    """Generate a random alphanumeric username of ``length`` chars."""
    return "".join(
        random.choice(string.ascii_letters + string.digits) for _ in range(length)
    )


async def auto_group_maker(
    session_mgr: SessionManager,
    per_account: int = 5,
    delay: float = 1.0,
) -> int:
    """Create ``per_account`` supergroups per account.

    Each group is given a random 12-character alphanumeric username.
    Returns the total number of groups created.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    created = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                for _ in range(per_account):
                    username = _random_username()
                    try:
                        await app.create_supergroup(username)
                        created += 1
                        log.info("%s: created supergroup %s", phone, username)
                        await smart_delay(delay, "fast")
                    except Exception as e:
                        log.warning("%s: create group failed: %s", phone, e)
                        break  # Move to next account on FloodWait-like errors.
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("auto_group_maker complete: %d groups created", created)
    return created


# ---------------------------------------------------------------------------
# Limit Checker & Remover (via @spambot)
# ---------------------------------------------------------------------------

SPAMBOT_USERNAME = "spambot"

# Known spambot response messages used for state-machine logic.
_NO_LIMIT_MSG = (
    "Good news, no limits are currently applied to your account. "
    "You're free as a bird!"
)
_HARSH_MSG = (
    "Unfortunately, some phone numbers may trigger a harsh response from "
    "our anti-spam systems."
)
_LIMITED_MSG_PREFIX = "Hello"

# Message sent to spambot's "describe what happened" prompt.
_COMplaint_TEXT = (
    "I'm a developer testing my application. I never sent any spam "
    "and would never do that. Please remove the limit."
)


async def limit_check_and_remove(session_mgr: SessionManager) -> int:
    """Check + auto-attempt to remove Telegram limits via @spambot.

    For each account: sends ``/start`` to @spambot, reads the
    response, and walks the spambot menu to submit a complaint.

    Returns:
        Number of accounts successfully processed (not necessarily
        unlimited — see logs for the per-account outcome).
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    processed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                ok = await _spambot_walk(app, phone)
                if ok:
                    processed += 1
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    log.info("limit_check_and_remove: %d/%d processed", processed, len(phones))
    return processed


async def _spambot_walk(app, phone: str) -> bool:
    """Walk @spambot's conversation flow for a single account."""
    try:
        await app.send_message(SPAMBOT_USERNAME, "/start")
        await asyncio.sleep(1.0)
        # Get latest message
        async for msg in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
            text = msg.text or ""
            break
        else:
            text = ""
        log.info("%s: spambot says: %s", phone, text[:80])

        if _NO_LIMIT_MSG in text:
            await app.send_message(SPAMBOT_USERNAME, "Cool, thanks")
            log.info("%s: no limit — all clear", phone)
            return True

        if _HARSH_MSG in text or "limited" in text.lower():
            # Submit a complaint automatically.
            await app.send_message(SPAMBOT_USERNAME, "This is a mistake")
            await asyncio.sleep(1.0)
            async for m2 in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                t2 = m2.text or ""
                break
            if "submit a complaint" in t2.lower():
                await app.send_message(SPAMBOT_USERNAME, "Yes")
                await asyncio.sleep(1.0)
                async for m3 in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                    t3 = m3.text or ""
                    break
                if "Please confirm" in t3 or "never send" in t3.lower():
                    await app.send_message(SPAMBOT_USERNAME, "No, I'll never do any of this!")
                    await asyncio.sleep(1.0)
                    await app.send_message(SPAMBOT_USERNAME, _COMplaint_TEXT)
                    log.info("%s: complaint submitted", phone)
                    return True
            log.warning("%s: limit detected but flow not followed", phone)
            return True

        log.info("%s: spambot returned unhandled response", phone)
        return True
    except Exception as e:
        log.error("%s: spambot walk failed: %s", phone, e)
        return False


# ---------------------------------------------------------------------------
# Group Chat Cloner — copy messages from one group to another
# ---------------------------------------------------------------------------

async def group_chat_cloner(
    session_mgr: SessionManager,
    source_group: str,
    target_group: str,
    num_messages: int = 100,
    delay: float = 2.0,
) -> int:
    """Clone the latest ``num_messages`` from ``source_group`` to ``target_group``.

    Uses ``app.copy_message`` so the messages arrive without a
    "forwarded from" tag.

    Args:
        session_mgr: Shared session manager.
        source_group: @username or link of the group to copy from.
        target_group: @username or link of the destination group.
        num_messages: How many recent messages to copy.
        delay: Delay between copies.

    Returns:
        Number of messages successfully copied.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    copied = 0
    # Use only the first account for cloning (others may not have
    # access to source group).
    phone = phones[0]
    try:
        async with session_mgr.acquire(phone) as app:
            from pyrogram.errors import UserAlreadyParticipant

            # Join both groups.
            for grp in (source_group, target_group):
                try:
                    await app.join_chat(grp)
                except UserAlreadyParticipant:
                    pass
                except Exception as e:
                    log.error("Failed to join %s: %s", grp, e)
                    return 0

            try:
                src = await app.get_chat(source_group)
                tgt = await app.get_chat(target_group)
            except Exception as e:
                log.error("Failed to resolve chats: %s", e)
                return 0

            # Collect message IDs (in chronological order).
            msg_ids: list[int] = []
            async for msg in app.get_chat_history(src.id, limit=num_messages):
                msg_ids.append(msg.id)
            msg_ids.reverse()  # oldest first

            for mid in msg_ids:
                try:
                    await app.copy_message(tgt.id, src.id, mid)
                    copied += 1
                    log.info("Copied msg %d → %s", mid, target_group)
                    await smart_delay(delay, "send_message")
                except Exception as e:
                    log.warning("Copy msg %d failed: %s", mid, e)
    except Exception as e:
        log.error("%s: clone failed: %s", phone, e)

    log.info("group_chat_cloner complete: %d copied", copied)
    return copied


# ---------------------------------------------------------------------------
# Live-group filter: remove rows from data.csv that are already in a target group
# ---------------------------------------------------------------------------

async def filter_data_csv_against_group(
    session_mgr: SessionManager,
    target_group: str,
    data_csv: str = "data.csv",
) -> int:
    """Remove rows from ``data.csv`` whose ``user_id`` is already a member
    of ``target_group``.

    This is the **live API filter** (vs. :func:`delete_already_filter`
    which uses ``done.csv``). It connects to Telegram, fetches the
    current members of the target group, and removes any matching
    rows from ``data.csv``.

    Args:
        session_mgr: Shared session manager (uses the first account).
        target_group: @username or chat ID of the target group.
        data_csv: Path to the data CSV file (default: ``data.csv``).

    Returns:
        Number of rows removed from ``data.csv``.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv — at least one needed to read group")
        return 0

    data_path = Path(data_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0

    from pyrogram.errors import UserAlreadyParticipant

    # Use only the first account — fetching members is a one-shot.
    phone = phones[0]
    try:
        async with session_mgr.acquire(phone) as app:
            # Join the target group first (so we can read its members).
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("Failed to join %s: %s", target_group, e)
                return 0

            try:
                chat = await app.get_chat(target_group)
            except Exception as e:
                log.error("Failed to resolve %s: %s", target_group, e)
                return 0

            # Fetch existing members (live API).
            existing_ids: set[str] = set()
            try:
                async for member in app.get_chat_members(chat_id=chat.id):
                    if hasattr(member, "user") and hasattr(member.user, "id"):
                        existing_ids.add(str(member.user.id))
            except Exception as e:
                log.error("get_chat_members failed: %s", e)
                return 0
            log.info("Found %d existing members in %s", len(existing_ids), target_group)

            # Read data.csv, filter, and rewrite.
            kept: list[dict[str, Any]] = []
            removed = 0
            fieldnames: list[str] = []
            with open(data_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames or ["user_id"]
                for row in reader:
                    uid = str(row.get("user_id", "") or "").strip()
                    if uid in existing_ids:
                        removed += 1
                    else:
                        kept.append(row)

            tmp = data_path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(kept)
            os.replace(str(tmp), str(data_path))

            log.info("Filtered %d rows from %s", removed, data_csv)
            return removed
    except Exception as e:
        log.error("%s: filter failed: %s", phone, e)
        return 0


# ---------------------------------------------------------------------------
# Single-account filter adder: add members from data.csv to a target group
# using ONE chosen account (by username).
# ---------------------------------------------------------------------------

async def single_filter_adder(
    session_mgr: SessionManager,
    target_group: str,
    account_index: int = 1,
    max_adds: int = 50,
    delay: float = 2.0,
    data_csv: str = "data.csv",
) -> int:
    """Add members from ``data.csv`` to ``target_group`` using a single account.

    The user picks which account to use by ``account_index`` (1-based).
    Members are added by **username** (not user_id) — this matches the
    behavior of the legacy ``singlefilteradderrr`` function.

    Args:
        session_mgr: Shared session manager.
        target_group: @username or link of the destination group.
        account_index: 1-based row index into ``phone.csv``.
        max_adds: Maximum members to add (default 50).
        delay: Delay between adds.
        data_csv: Path to the data CSV (default: ``data.csv``).

    Returns:
        Number of members added.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    if account_index < 1 or account_index > len(phones):
        log.error("account_index %d is out of range (1..%d)", account_index, len(phones))
        return 0

    phone = phones[account_index - 1]
    log.info("Using account %d: %s", account_index, phone)

    data_path = Path(data_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0

    # Read all members from data.csv.
    members: list[dict[str, Any]] = []
    with open(data_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            uname = (row.get("username") or "").strip().lstrip("@")
            if uname:
                members.append(
                    {
                        "username": uname,
                        "first_name": (row.get("first_name") or "").strip(),
                        "last_name": (row.get("last_name") or "").strip(),
                    }
                )
    log.info("Loaded %d members from %s", len(members), data_csv)

    from pyrogram.errors import (
        ChatAdminRequired,
        FloodWait,
        PeerFlood,
        UserAlreadyParticipant,
        UserBannedInChannel,
        UserChannelsTooMuch,
        UserPrivacyRestricted,
        RPCError,
    )

    added = 0
    flood = peer = banned = stop_count = 0
    try:
        async with session_mgr.acquire(phone) as app:
            # Join target group.
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("%s: failed to join %s: %s", phone, target_group, e)
                return 0
            try:
                chat = await app.get_chat(target_group)
            except Exception as e:
                log.error("%s: failed to resolve %s: %s", phone, target_group, e)
                return 0

            for member in members:
                if stop_count >= max_adds:
                    log.info("Reached limit: %d adds", max_adds)
                    break
                if flood >= 5 or peer >= 5 or banned >= 5:
                    log.warning("Too many errors — stopping (flood=%d, peer=%d, banned=%d)", flood, peer, banned)
                    break

                uname = member["username"]
                try:
                    await app.add_chat_members(chat.id, uname)
                    added += 1
                    stop_count += 1
                    log.info(
                        "%s: +%s added (%d/%d)",
                        phone, member["first_name"] or uname, stop_count, max_adds,
                    )
                    await smart_delay(delay, "add_member")
                except FloodWait as e:
                    flood += 1
                    log.warning("%s: FloodWait %ds", phone, e.value)
                    await asyncio.sleep(min(e.value, 60))
                except PeerFlood:
                    peer += 1
                    log.error("%s: PeerFlood", phone)
                    break
                except UserBannedInChannel:
                    banned += 1
                    log.warning("%s: UserBannedInChannel (%s)", phone, uname)
                except (UserPrivacyRestricted, UserChannelsTooMuch):
                    pass  # Skip silently — common, not an error.
                except RPCError as e:
                    log.warning("%s: %s", phone, type(e).__name__)
                except Exception as e:
                    log.error("%s: add %s failed: %s", phone, uname, e)
    except Exception as e:
        log.error("%s: account failed: %s", phone, e)

    log.info("single_filter_adder complete: %d added (stop=%d, flood=%d, peer=%d)", added, stop_count, flood, peer)
    return added


# ---------------------------------------------------------------------------
# Import VCF as contacts (addtocontactbyimp)
# ---------------------------------------------------------------------------

async def import_vcf_as_contacts(
    session_mgr: SessionManager,
    vcf_path: str,
    max_per_account: int = 50,
    delay: float = 2.0,
) -> int:
    """Import contacts from a VCF (vCard) file using all accounts.

    Reads the .vcf file, splits the contacts into chunks (one per
    account), and imports each chunk via :meth:`Client.import_contacts`.

    Requires the optional ``vobject`` dependency.

    Args:
        session_mgr: Shared session manager.
        vcf_path: Path to the .vcf file.
        max_per_account: Max contacts to import per account.
        delay: Delay between accounts.

    Returns:
        Total number of contacts imported.
    """
    try:
        import vobject  # type: ignore[import]
        from pyrogram.types import InputPhoneContact
    except ImportError:
        log.error("vobject not installed — run: pip install vobject")
        return 0

    p_path = Path(vcf_path)
    if not p_path.exists():
        log.error("VCF file not found: %s", vcf_path)
        return 0

    # Parse all vCards.
    contacts: list[dict[str, str]] = []
    try:
        with open(p_path, "r", encoding="utf-8") as f:
            data = f.read()
        for vcard in vobject.readComponents(data):
            if "tel" not in vcard.contents:
                continue
            fname = ""
            lname = ""
            if "n" in vcard.contents:
                n = vcard.contents["n"].value
                fname = getattr(n, "given", "") or ""
                lname = getattr(n, "family", "") or ""
            elif "fn" in vcard.contents:
                fname = vcard.contents["fn"].value or ""
            for tel in vcard.tel_list:
                contacts.append(
                    {
                        "phone": tel.value,
                        "first_name": fname or "Contact",
                        "last_name": lname,
                    }
                )
    except Exception as e:
        log.error("VCF parse error: %s", e)
        return 0

    if not contacts:
        log.error("No phone numbers found in %s", vcf_path)
        return 0

    log.info("Loaded %d contacts from %s", len(contacts), vcf_path)

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Chunk contacts across accounts.
    per = max(1, len(contacts) // len(phones))
    chunks = [contacts[i * per:(i + 1) * per] for i in range(len(phones))]
    remainder = contacts[len(phones) * per:]
    if chunks and remainder:
        chunks[-1].extend(remainder)

    imported_total = 0
    for idx, phone in enumerate(phones, 1):
        chunk = chunks[idx - 1] if idx - 1 < len(chunks) else []
        if not chunk:
            continue
        # Cap to max_per_account.
        chunk = chunk[:max_per_account]
        try:
            async with session_mgr.acquire(phone) as app:
                input_contacts = [
                    InputPhoneContact(
                        phone=c["phone"],
                        first_name=c["first_name"],
                        last_name=c["last_name"],
                    )
                    for c in chunk
                ]
                try:
                    result = await app.import_contacts(input_contacts)
                    n = len(result.imported) if result and result.imported else 0
                    imported_total += n
                    log.info("%s: imported %d contacts", phone, n)
                except Exception as e:
                    log.error("%s: import failed: %s", phone, e)
                await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("import_vcf_as_contacts complete: %d imported", imported_total)
    return imported_total


# ---------------------------------------------------------------------------
# Anonymous chatter (anonychatter) — send N messages to a chat from each account
# ---------------------------------------------------------------------------

async def anonymous_chatter(
    session_mgr: SessionManager,
    target_chat: str,
    message: str,
    num_per_account: int = 5,
    delay: float = 2.0,
) -> int:
    """Send ``num_per_account`` copies of ``message`` to ``target_chat``
    from each account in ``phone.csv``.

    Useful for inflating chat activity (e.g., making a new group look
    active) without revealing who sent each message.

    Args:
        session_mgr: Shared session manager.
        target_chat: Target @username or chat ID.
        message: The message text to repeat.
        num_per_account: How many messages each account should send.
        delay: Delay between sends.

    Returns:
        Total number of messages sent.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    from pyrogram.errors import UserAlreadyParticipant

    sent_total = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_chat)
                except UserAlreadyParticipant:
                    pass
                for i in range(num_per_account):
                    try:
                        await app.send_message(target_chat, message)
                        sent_total += 1
                        log.info("%s: msg %d/%d", phone, i + 1, num_per_account)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: send %d failed: %s", phone, i + 1, e)
                        break
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("anonymous_chatter complete: %d sent", sent_total)
    return sent_total
