"""Contacts-to-group adder: adds user's contacts to a target group."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones, progress_bar
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)


class ContactsToGroupAdder(BaseAdder):
    """Adds the user's contacts to a target group.

    Skips users already in the group (live API check) and users already added
    (per done.csv).
    """

    async def run(
        self,
        target_group: str,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the contacts-to-group operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport("contacts_to_group")
        result = OperationResult()
        log.info("Starting ContactsToGroupAdder: %d accounts", len(phones))

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0
            skipped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    added, skipped = await self._process_account(
                        app=app, phone=phone, target_group=target_group,
                        max_per_account=max_per_account,
                        delay=delay, counter=counter, report=report,
                    )
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.skipped += skipped
            result.add_account(phone, counter)
            log.info("%s: +%d to group, %d skipped", phone, added, skipped)

        result.report_path = str(report.path)
        log.info("ContactsToGroup complete: %d added", result.success)
        return result

    async def _process_account(
        self, app, phone, target_group, max_per_account, delay, counter, report,
    ) -> tuple[int, int]:
        """Process a single account."""
        try:
            await app.join_chat(target_group)
        except UserAlreadyParticipant:
            pass
        except Exception as e:
            log.error("%s: failed to join: %s", phone, e)
            return (0, 0)

        try:
            target_chat = await app.get_chat(target_group)
        except Exception as e:
            log.error("%s: failed to resolve: %s", phone, e)
            return (0, 0)

        # Get existing group members
        existing_members = await self._get_existing_members(app, target_chat.id)
        log.info("%s: %d members in group", phone, len(existing_members))

        # Get user's contacts
        my_contacts = await self._get_my_contacts(app)
        if not my_contacts:
            log.warning("%s: no contacts to add", phone)
            return (0, 0)
        log.info("%s: %d contacts available", phone, len(my_contacts))

        added = 0
        skipped = 0

        for i, contact in enumerate(my_contacts):
            if added >= max_per_account or counter.should_stop():
                break

            uid = contact.id
            fname = contact.first_name or ""
            lname = contact.last_name or ""
            uname = contact.username or ""

            if uid in existing_members or self.dedup.is_done(uid):
                skipped += 1
                continue

            ok, reason = await self._add_to_group_safe(app, target_chat.id, uid)
            if ok:
                added += 1
                existing_members.add(uid)
                await self.dedup.mark_done(uid, fname, lname, uname)
                await report.log(
                    account=phone, user_id=uid,
                    first=fname, last=lname, username=uname,
                    status="added",
                )
            else:
                skipped += 1
                await report.log(
                    account=phone, user_id=uid,
                    first=fname, last=lname, username=uname,
                    status="skipped", error_type=reason,
                )
                if await self._handle_error(reason, counter, phone):
                    break

            if (i % 10) == 0:
                progress_bar(i + 1, len(my_contacts), label=phone)

            await self._delay(delay)

        return (added, skipped)

    async def _get_existing_members(self, app: Client, chat_id: int) -> set[int]:
        result: set[int] = set()
        try:
            async for member in app.get_chat_members(chat_id):
                if hasattr(member, "user") and hasattr(member.user, "id"):
                    result.add(member.user.id)
        except Exception as e:
            log.warning("Failed to get chat members: %s", e)
        return result

    async def _get_my_contacts(self, app: Client) -> list[Any]:
        try:
            contacts = await app.get_contacts()
            return list(contacts) if contacts else []
        except Exception as e:
            log.error("Failed to get contacts: %s", e)
            return []
