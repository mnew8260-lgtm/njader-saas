"""Bulk adder: adds user's contacts to target group in batches."""
from __future__ import annotations

import logging
from pathlib import Path

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)


class BulkAdder(BaseAdder):
    """Adds user's contacts to target group in batches."""

    async def run(
        self,
        target_group: str,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the bulk adder operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport("bulkadder")
        result = OperationResult()

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    added = await self._process_account(
                        app=app, phone=phone, target=target_group,
                        max_per_account=max_per_account,
                        delay=delay, counter=counter, report=report,
                    )
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.add_account(phone, counter)

        result.report_path = str(report.path)
        return result

    async def _process_account(
        self, app, phone, target, max_per_account, delay, counter, report,
    ) -> int:
        """Process a single account."""
        try:
            await app.join_chat(target)
        except UserAlreadyParticipant:
            pass
        except Exception as e:
            log.error("%s: failed to join: %s", phone, e)
            return 0

        try:
            chat = await app.get_chat(target)
        except Exception as e:
            log.error("%s: failed to resolve: %s", phone, e)
            return 0

        # Get user's contacts
        try:
            contacts = await app.get_contacts()
            if not contacts:
                return 0
        except Exception as e:
            log.error("%s: get_contacts failed: %s", phone, e)
            return 0

        added = 0
        for contact in contacts:
            if counter.should_stop() or added >= max_per_account:
                break

            uid = contact.id
            if self.dedup.is_done(uid):
                continue

            ok, reason = await self._add_member_safe_v44(
                app, chat.id, uid,
                {"first_name": contact.first_name or "", "username": contact.username or ""},
            )
            if ok:
                added += 1
                await self.dedup.mark_done(
                    uid, contact.first_name or "", contact.last_name or "", contact.username or "",
                )
                await report.log(
                    account=phone, user_id=uid,
                    first=contact.first_name or "", last=contact.last_name or "",
                    username=contact.username or "", status="added",
                )
            else:
                await report.log(
                    account=phone, user_id=uid,
                    first=contact.first_name or "", last=contact.last_name or "",
                    username=contact.username or "",
                    status="skipped", error_type=reason,
                )
                if await self._handle_error(reason, counter, phone):
                    break

            await self._delay(delay)

        return added
