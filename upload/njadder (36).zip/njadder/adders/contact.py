"""Contact adder: adds members via add_contact first, then add_chat_members."""
from __future__ import annotations

import asyncio
import csv
import logging
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import (
    DedupManager,
    ErrorCounter,
    FloodTracker,
    OpReport,
    SessionManager,
    load_phones,
    progress_bar,
)
from ..core.flood import INTER_ACCOUNT_PEERFLOOD_COOLDOWN
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)

MIN_ID_DIGITS = 7


class ContactAdder(BaseAdder):
    """Adds members via add_contact first, then add_chat_members.

    3-step strategy per member (when needed):
    1. resolve_peer (force peer resolution)
    2. add_contact (make them your contact)
    3. add_chat_members (add to group)

    Note: the v44 pipeline in :class:`BaseAdder` tries
    ``add_chat_members`` first (1 API call) and only falls back to
    ``add_contact`` / ``import_contacts`` on ``PeerIdInvalid``. This
    drastically reduces the API-call count per member and lowers
    PeerFlood risk.
    """

    async def run(
        self,
        source_group: str,
        target_group: str,
        max_per_account: int = 80,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the contact adder operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        # Skip accounts that are still in PeerFlood cooldown.
        active_phones = self.flood_tracker.filter_active(phones)
        skipped_for_cooldown = len(phones) - len(active_phones)
        if skipped_for_cooldown > 0:
            log.warning(
                "Skipping %d account(s) in PeerFlood cooldown (24h)",
                skipped_for_cooldown,
            )
        if not active_phones:
            log.error("All accounts are in PeerFlood cooldown — try again later")
            return OperationResult(skipped=len(phones))

        # Read members from data.csv
        members = self._read_data_csv()
        if not members:
            log.error("No members in data.csv")
            return OperationResult()
        log.info("Loaded %d members from data.csv", len(members))

        # Filter out already-done users
        to_add = [m for m in members if not self.dedup.is_done(m["user_id"])]
        log.info("After dedup: %d members to add", len(to_add))

        if not to_add:
            log.info("Nothing new to add")
            return OperationResult(skipped=len(members))

        # Chunk members across active accounts.
        per = max(1, len(to_add) // len(active_phones))
        chunks = [to_add[i * per:(i + 1) * per] for i in range(len(active_phones))]
        remainder = to_add[len(active_phones) * per:]
        if chunks and remainder:
            chunks[-1].extend(remainder)

        report = OpReport("contactadder")
        result = OperationResult()

        for idx, phone in enumerate(active_phones):
            chunk = chunks[idx] if idx < len(chunks) else []
            if not chunk:
                continue

            log.info(
                "Account %d/%d: %s (%d members)", idx + 1, len(active_phones), phone, len(chunk)
            )
            counter = ErrorCounter()
            added = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    added = await self._process_account(
                        app=app, phone=phone, chunk=chunk,
                        target_group=target_group,
                        max_per_account=max_per_account,
                        delay=delay,
                        counter=counter, report=report,
                    )
                    # Flush any pending delete_contacts before leaving the session.
                    await self._flush_deletes(app)
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.add_account(phone, counter)
            log.info("%s: +%d added", phone, added)

            # If this account hit PeerFlood, insert a long cooldown
            # before the next account to let the API settle.
            if counter.peer > 0 and idx + 1 < len(active_phones):
                log.warning(
                    "Inserting %ds cooldown before next account (PeerFlood detected)",
                    INTER_ACCOUNT_PEERFLOOD_COOLDOWN,
                )
                result.flooded_accounts.append(phone)
                await asyncio.sleep(INTER_ACCOUNT_PEERFLOOD_COOLDOWN)
            elif counter.peer > 0:
                result.flooded_accounts.append(phone)

        result.report_path = str(report.path)
        log.info(
            "ContactAdder complete: %d added, %d account(s) flooded",
            result.success,
            len(result.flooded_accounts),
        )
        return result

    def _read_data_csv(self) -> list[dict[str, Any]]:
        """Read members from data.csv."""
        data_file = Path("data.csv")
        if not data_file.exists():
            log.error("data.csv not found")
            return []

        members: list[dict[str, Any]] = []
        try:
            with open(data_file, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    uid_str = str(row.get("user_id", "") or "").strip()
                    if not uid_str or not uid_str.isdigit():
                        continue
                    if len(uid_str) < MIN_ID_DIGITS:
                        continue
                    members.append(
                        {
                            "user_id": int(uid_str),
                            "first_name": (row.get("first_name", "") or "").strip(),
                            "last_name": (row.get("last_name", "") or "").strip(),
                            "username": (row.get("username", "") or "").strip().lstrip("@"),
                            "phone_number": (row.get("phone_number", "") or row.get("phone", "") or "").strip(),
                        }
                    )
        except Exception as e:
            log.error("Failed to read data.csv: %s", e)
        return members

    async def _process_account(
        self, app, phone, chunk, target_group, max_per_account, delay, counter, report,
    ) -> int:
        """Process a single account."""
        # Join target group
        try:
            await app.join_chat(target_group)
        except UserAlreadyParticipant:
            pass
        except Exception as e:
            log.error("%s: failed to join target: %s", phone, e)
            return 0

        try:
            tgt = await app.get_chat(target_group)
        except Exception as e:
            log.error("%s: failed to resolve target: %s", phone, e)
            return 0

        added = 0
        for i, member in enumerate(chunk):
            if counter.should_stop():
                break
            if added >= max_per_account:
                break

            uid = member["user_id"]
            if self.dedup.is_done(uid):
                continue

            ok, reason = await self._add_member_safe_v44(
                app, tgt.id, uid, member
            )
            if ok:
                added += 1
                await self.dedup.mark_done(
                    uid, member.get("first_name", ""),
                    member.get("last_name", ""), member.get("username", ""),
                )
                await report.log(
                    account=phone, user_id=uid,
                    first=member.get("first_name", ""),
                    last=member.get("last_name", ""),
                    username=member.get("username", ""),
                    status="added",
                )
            else:
                await report.log(
                    account=phone, user_id=uid,
                    first=member.get("first_name", ""),
                    last=member.get("last_name", ""),
                    username=member.get("username", ""),
                    status="skipped", error_type=reason,
                )
                if await self._handle_error(reason, counter, phone):
                    break

            # Flush batched deletes every 10 members.
            if (added % 10) == 0:
                await self._flush_deletes(app)

            if (i % 10) == 0:
                progress_bar(added, min(len(chunk), max_per_account), label=phone)

            await self._delay(delay)

        # Final flush of any pending deletes.
        await self._flush_deletes(app)
        return added
