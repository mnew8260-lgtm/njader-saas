"""Direct adder: adds members directly from source group to target."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)


class DirectAdder(BaseAdder):
    """Adds members directly from a source group to a target group."""

    async def run(
        self,
        source_group: str,
        target_group: str,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the direct add operation."""
        if phones is None:
            phones = load_phones()

        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport("directadder")
        result = OperationResult()
        log.info("Starting DirectAdder: %d accounts", len(phones))

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    added = await self._process_account(
                        app=app,
                        phone=phone,
                        source=source_group,
                        target=target_group,
                        max_per_account=max_per_account,
                        delay=delay,
                        counter=counter,
                        report=report,
                    )
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.add_account(phone, counter)
            log.info("%s: +%d added", phone, added)

        result.report_path = str(report.path)
        log.info("DirectAdder complete: %d added", result.success)
        return result

    async def _process_account(
        self,
        app: Client,
        phone: str,
        source: str,
        target: str,
        max_per_account: int,
        delay: float,
        counter: ErrorCounter,
        report: OpReport,
    ) -> int:
        """Process a single account — join groups and add members."""
        # Join both groups
        for grp in (source, target):
            try:
                await app.join_chat(grp)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("%s: failed to join %s: %s", phone, grp, e)
                return 0

        try:
            target_chat = await app.get_chat(target)
            source_chat = await app.get_chat(source)
        except Exception as e:
            log.error("%s: failed to resolve chats: %s", phone, e)
            return 0

        added = 0
        try:
            async for member in app.get_chat_members(chat_id=source_chat.id):
                if counter.should_stop():
                    log.warning("%s: stopping due to errors", phone)
                    break
                if added >= max_per_account:
                    log.info("%s: reached limit (%d)", phone, max_per_account)
                    break

                user = member.user
                if self.dedup.is_done(user.id):
                    continue

                ok, reason = await self._add_member_safe_v44(
                    app, target_chat.id, user.id,
                    {"first_name": user.first_name or "", "username": user.username or ""}
                )
                if ok:
                    added += 1
                    await self.dedup.mark_done(
                        user.id, user.first_name or "", user.last_name or "", user.username or ""
                    )
                    await report.log(
                        account=phone, user_id=user.id,
                        first=user.first_name or "", last=user.last_name or "",
                        username=user.username or "", status="added",
                    )
                    log.info("%s: +%s added", phone, user.first_name or "?")
                else:
                    await report.log(
                        account=phone, user_id=user.id,
                        first=user.first_name or "", last=user.last_name or "",
                        username=user.username or "",
                        status="skipped", error_type=reason,
                    )
                    if await self._handle_error(reason, counter, phone):
                        break

                await self._delay(delay)
        except Exception as e:
            log.error("%s: scrape failed: %s", phone, e)

        return added
