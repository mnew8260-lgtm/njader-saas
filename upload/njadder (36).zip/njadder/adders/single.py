"""Single adder: adds members one by one with strict deduplication."""
from __future__ import annotations

import logging
from pathlib import Path

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)


class SingleAdder(BaseAdder):
    """Adds members one by one (no batch processing)."""

    async def run(
        self,
        target_group: str,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the single adder operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport("singleadder")
        result = OperationResult()

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    # Use the contact adder logic for single add
                    from .contact import ContactAdder

                    contact_adder = ContactAdder(self.settings, self.session_mgr, self.dedup)
                    # Reuse the same data.csv
                    added_result = await contact_adder.run(
                        source_group="",  # not used since data.csv is the source
                        target_group=target_group,
                        max_per_account=max_per_account,
                        delay=delay,
                        phones=[phone],
                    )
                    added = added_result.success
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.add_account(phone, counter)

        result.report_path = str(report.path)
        return result
