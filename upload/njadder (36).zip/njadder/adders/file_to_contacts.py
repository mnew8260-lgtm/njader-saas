"""File-to-contacts adder: reads data.csv and adds members as contacts."""
from __future__ import annotations

import asyncio
import csv
import logging
from pathlib import Path
from typing import Any

from pyrogram import Client

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones, progress_bar
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)

MIN_ID_DIGITS = 7


class FileToContactsAdder(BaseAdder):
    """Reads members from data.csv and adds them as contacts.

    Uses three strategies per member (InputPhoneContact, add_contact, username).
    """

    async def run(
        self,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the file-to-contacts operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        members = self._read_data_csv()
        if not members:
            log.error("No members in data.csv")
            return OperationResult()
        log.info("Loaded %d members from data.csv", len(members))

        to_add = [m for m in members if not self.dedup.is_done(m["user_id"])]
        log.info("After dedup: %d members to add", len(to_add))

        if not to_add:
            log.info("Nothing new to add")
            return OperationResult(skipped=len(members))

        per = max(1, len(to_add) // len(phones))
        chunks = [to_add[i * per:(i + 1) * per] for i in range(len(phones))]
        remainder = to_add[len(phones) * per:]
        if chunks and remainder:
            chunks[-1].extend(remainder)

        report = OpReport("add_to_contacts")
        result = OperationResult()

        for idx, phone in enumerate(phones):
            chunk = chunks[idx] if idx < len(chunks) else []
            if not chunk:
                continue

            log.info("Account %d/%d: %s (%d members)", idx + 1, len(phones), phone, len(chunk))
            counter = ErrorCounter()
            added = 0
            skipped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    my_contact_ids = await self._get_existing_contacts(app)

                    for i, member in enumerate(chunk):
                        if added >= max_per_account or counter.should_stop():
                            break

                        uid = member["user_id"]
                        if uid in my_contact_ids or self.dedup.is_done(uid):
                            skipped += 1
                            continue

                        ok, reason = await self._add_to_contacts_safe(app, member)
                        if ok:
                            added += 1
                            my_contact_ids.add(uid)
                            await self.dedup.mark_done(
                                uid, member.get("first_name", ""),
                                member.get("last_name", ""), member.get("username", ""),
                            )
                            await report.log(
                                account=phone, user_id=uid,
                                first=member.get("first_name", ""),
                                last=member.get("last_name", ""),
                                username=member.get("username", ""),
                                status="added",
                            )
                        else:
                            skipped += 1
                            await report.log(
                                account=phone, user_id=uid,
                                first=member.get("first_name", ""),
                                last=member.get("last_name", ""),
                                username=member.get("username", ""),
                                status="skipped", error_type=reason,
                            )
                            if await self._handle_error(reason, counter, phone):
                                break

                        if (i % 10) == 0:
                            progress_bar(i + 1, len(chunk), label=phone)

                        await self._delay(delay)

            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.skipped += skipped
            result.add_account(phone, counter)
            log.info("%s: +%d contacts, %d skipped", phone, added, skipped)

        result.report_path = str(report.path)
        log.info("FileToContacts complete: %d added", result.success)
        return result

    def _read_data_csv(self) -> list[dict[str, Any]]:
        """Read members from data.csv."""
        data_file = Path("data.csv")
        if not data_file.exists():
            log.error("data.csv not found")
            return []

        members: list[dict[str, Any]] = []
        try:
            with open(data_file, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    uid_str = str(row.get("user_id", "") or "").strip()
                    if not uid_str or not uid_str.isdigit():
                        continue
                    if len(uid_str) < MIN_ID_DIGITS:
                        continue
                    members.append(
                        {
                            "user_id": int(uid_str),
                            "first_name": (row.get("first_name", "") or "").strip(),
                            "last_name": (row.get("last_name", "") or "").strip(),
                            "username": (row.get("username", "") or "").strip().lstrip("@"),
                            "phone_number": (row.get("phone_number", "") or row.get("phone", "") or "").strip(),
                        }
                    )
        except Exception as e:
            log.error("Failed to read data.csv: %s", e)
        return members

    async def _get_existing_contacts(self, app: Client) -> set[int]:
        """Get existing contact user IDs."""
        result: set[int] = set()
        try:
            contacts = await app.get_contacts()
            if contacts:
                for c in contacts:
                    if hasattr(c, "id"):
                        result.add(c.id)
        except Exception as e:
            log.warning("Failed to get contacts: %s", e)
        return result
