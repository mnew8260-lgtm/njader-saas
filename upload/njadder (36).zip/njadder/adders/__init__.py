"""Adder modules: add members to groups or contacts."""
from __future__ import annotations

from .base import BaseAdder, OperationResult
from .bulk import BulkAdder
from .contact import ContactAdder
from .contacts_to_group import ContactsToGroupAdder
from .direct import DirectAdder
from .file_to_contacts import FileToContactsAdder
from .ramex import RamexAdder
from .single import SingleAdder

__all__ = [
    "BaseAdder",
    "BulkAdder",
    "ContactAdder",
    "ContactsToGroupAdder",
    "DirectAdder",
    "FileToContactsAdder",
    "OperationResult",
    "RamexAdder",
    "SingleAdder",
]
