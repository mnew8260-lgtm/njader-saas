"""Color constants via colorama (with graceful fallback).

The :class:`Colors` class is a pure namespace — never instantiated. Use
``Colors.RED``, ``Colors.INFO``, etc. directly.
"""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

try:
    from colorama import Back, Fore, Style, init

    init(autoreset=True)
    _HAS_COLOR = True
except ImportError:  # pragma: no cover - colorama is a hard dep but be resilient
    log.warning("colorama not available — colors will be disabled")

    class _DummyColor:
        """Returns empty strings for any attribute access."""

        def __getattr__(self, _name: str) -> str:
            return ""

    Fore = Back = Style = _DummyColor()  # type: ignore[assignment]
    _HAS_COLOR = False


def _light(name: str) -> str:
    """Read a LIGHT*_EX attribute from colorama Fore, returning "" if missing."""
    if not _HAS_COLOR:
        return ""
    return getattr(Fore, name, "")


class Colors:
    """Pure namespace of ANSI color codes.

    All attributes are class-level strings. Never instantiated.
    """

    # Basic foreground colors.
    RED: str = Fore.RED
    GREEN: str = Fore.GREEN
    YELLOW: str = Fore.YELLOW
    BLUE: str = Fore.BLUE
    MAGENTA: str = Fore.MAGENTA
    CYAN: str = Fore.CYAN
    WHITE: str = Fore.WHITE
    BLACK: str = Fore.BLACK

    # Bright / light variants.
    BRIGHT_GREEN: str = _light("LIGHTGREEN_EX")
    BRIGHT_YELLOW: str = _light("LIGHTYELLOW_EX")
    BRIGHT_CYAN: str = _light("LIGHTCYAN_EX")
    BRIGHT_WHITE: str = _light("LIGHTWHITE_EX")
    BRIGHT_RED: str = _light("LIGHTRED_EX")
    BRIGHT_BLUE: str = _light("LIGHTBLUE_EX")
    BRIGHT_MAGENTA: str = _light("LIGHTMAGENTA_EX")
    LIGHTBLACK_EX: str = _light("LIGHTBLACK_EX")

    # Background colors.
    BG_RED: str = Back.RED
    BG_GREEN: str = Back.GREEN
    BG_CYAN: str = Back.CYAN
    BG_BLACK: str = Back.BLACK
    BG_WHITE: str = Back.WHITE
    BG_YELLOW: str = Back.YELLOW
    BG_BLUE: str = Back.BLUE
    BG_MAGENTA: str = Back.MAGENTA

    # Style.
    BRIGHT: str = Style.BRIGHT
    DIM: str = Style.DIM
    RESET: str = Style.RESET_ALL

    # Semantic prefixes.
    INFO: str = f"{Fore.CYAN}[i]{Style.RESET_ALL}" if _HAS_COLOR else "[i]"
    SUCCESS: str = f"{Fore.GREEN}[+]{Style.RESET_ALL}" if _HAS_COLOR else "[+]"
    ERROR: str = f"{Fore.RED}[!]{Style.RESET_ALL}" if _HAS_COLOR else "[!]"
    WARNING: str = f"{Fore.YELLOW}[!]{Style.RESET_ALL}" if _HAS_COLOR else "[!]"

    @classmethod
    def has_color(cls) -> bool:
        """Return True if colorama output is enabled."""
        return _HAS_COLOR
