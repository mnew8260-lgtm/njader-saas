"""Interactive CLI menu system."""
from __future__ import annotations

import asyncio
import os
import sys
import time

from ..config import get_config
from ..core import (
    DedupManager,
    FloodTracker,
    SessionManager,
    load_phones,
)
from .colors import Colors


def asyncio_run(coro):
    """Wrapper for :func:`asyncio.run` — kept here so callers can stay sync."""
    return asyncio.run(coro)


# Shared flood tracker — instantiated once per process so cooldowns
# persist across menu operations in the same session.
_flood_tracker: FloodTracker | None = None


def _get_flood_tracker() -> FloodTracker:
    global _flood_tracker
    if _flood_tracker is None:
        _flood_tracker = FloodTracker()
    return _flood_tracker


def _clear() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def _banner() -> None:
    """Print a professional, mobile-friendly banner."""
    C = Colors
    # ASCII art title — 3 rows, compact but bold
    print()
    print(f"{C.BRIGHT_CYAN}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_YELLOW}{C.BRIGHT}{'  ███╗   ██╗ █████╗  ██████╗ ██╗  ██╗███████╗██╗  ██╗':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_YELLOW}{C.BRIGHT}{'  ████╗  ██║██╔══██╗██╔════╝ ██║  ██║██╔════╝╚██╗██╔╝':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_YELLOW}{C.BRIGHT}{'  ██╔██╗ ██║███████║██║  ███╗███████║█████╗  ╚███╔╝ ':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_YELLOW}{C.BRIGHT}{'  ██║╚██╗██║██╔══██║██║   ██║╚════██║██╔══╝  ██╔██╗ ':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_YELLOW}{C.BRIGHT}{'  ██║ ╚████║██║  ██║╚██████╔╝███████║██║     ██╔╝ ██╗':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}{'─'*55}{C.BRIGHT_CYAN}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_GREEN}{C.BRIGHT}{'  v41  |  Professional Telegram Automation  ':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_MAGENTA}{'  252+ Functions | 9 Menus | Proprietary  ':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}", end="")
    print(f"{C.BRIGHT_WHITE}{'  Dev: @NMDDER_DEV  |  Support: @NMDDER_SUPPORT  ':^55}{C.RESET}", end="")
    print(f"{C.BRIGHT_CYAN}┃{C.RESET}")
    print(f"{C.BRIGHT_CYAN}┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛{C.RESET}")
    print()


def _section(title: str) -> None:
    W = 66
    pad = max(0, W - len(title) - 4)
    print(f"{Colors.BRIGHT_CYAN}┌── {Colors.BRIGHT_YELLOW}{title}{Colors.RESET}{Colors.BRIGHT_CYAN} {'─' * pad}┐{Colors.RESET}")


def _section_end() -> None:
    W = 66
    print(f"{Colors.BRIGHT_CYAN}└{'─' * (W + 1)}┘{Colors.RESET}")


def _option(num: int, text: str, color: str = Colors.GREEN) -> None:
    print(f"  {color}[{str(num).rjust(2)}]{Colors.RESET}  {Colors.BRIGHT}{text}{Colors.RESET}")


def _back() -> None:
    print(f"  {Colors.RED}[ 0]{Colors.RESET}  {Colors.RED}← Back{Colors.RESET}")


def _pause() -> None:
    try:
        input(f"\n{Colors.INFO} Press Enter to continue...")
    except EOFError:
        pass


def _get_choice() -> str:
    try:
        return input().strip()
    except (EOFError, KeyboardInterrupt):
        return "00"


def _safe_input_int(prompt: str, default: int = 0) -> int:
    try:
        v = input(prompt).strip()
        return int(v) if v else default
    except (ValueError, EOFError, KeyboardInterrupt):
        return default


def _safe_input_float(prompt: str, default: float = 0.0) -> float:
    try:
        v = input(prompt).strip()
        return float(v) if v else default
    except (ValueError, EOFError, KeyboardInterrupt):
        return default


def menu_accounts(session_mgr: SessionManager) -> None:
    """Account management menu — Login + Security + Privacy + v41 tools."""
    _clear()
    _banner()
    _section("Account Management (Complete)")
    # Login
    _option(1, "Login all (basic — same API)")
    _option(2, "SECURE LOGIN (api.csv + devices.csv + proxies.csv)")
    # Account security
    _option(3, "Ban Filter v41 (banned/frozen/restricted)")
    _option(4, "Remove specific account")
    _option(5, "OTP Viewer")
    _option(6, "Account Info v41 (flags: verified/scam/fake)")
    _option(7, "View Restricted Accounts")
    _option(8, "Recover Restricted (@SpamBot complaint)")
    _option(9, "Permanent Limit Remover (@SpamBot)")
    # Profile tools
    _option(10, "Change First/Last Name & Bio")
    _option(11, "Set Username (same for all)")
    _option(12, "Set Usernames from CSV (per-account)")
    _option(13, "Generate Random Usernames → username.csv")
    _option(14, "Set Profile Picture")
    _option(15, "Remove Profile Picture")
    _option(16, "Auto ID Cloner (clone from clone.csv)")
    _option(17, "Enable 2-Step Verification")
    # Privacy
    _option(18, "Hide Last Seen")
    _option(19, "Hide Phone Number")
    # Boost
    _option(20, "Increase Post Views")
    _option(21, "Reaction Increaser")
    _option(22, "Shares Increaser")
    # Nearby
    _option(23, "Nearby Adder by Lat/Long")
    _option(24, "Nearby Adder by City")
    # Contacts
    _option(25, "Delete All Contacts")
    _option(26, "Mass DM from data.csv")
    _option(27, "Add to Contact by Group (ResolvePhone)")
    _option(28, "Add to Contact by Import (VCF → group)")
    # Chat
    _option(29, "Anonymous Chatter Flow (@chatbot)")
    _back()
    print()
    choice = _get_choice()

    if choice == "1":
        from ..account.security import login_all
        asyncio_run(login_all(session_mgr))
    elif choice == "2":
        from ..account.security import login_using_security
        n = asyncio_run(login_using_security())
        print(f"\n{Colors.SUCCESS} Secure-logged-in {n} accounts")
    elif choice == "3":
        from ..account.security import ban_filter_v41
        use_spambot = input(f"{Colors.INFO} Check SpamBot? (y/N): ").strip().lower()
        result = asyncio_run(ban_filter_v41(session_mgr, check_spambot=use_spambot.startswith("y")))
        if result:
            print(f"\n{Colors.SUCCESS} Clean: {len(result.get('valid', []))}")
            print(f"{Colors.ERROR} Banned: {len(result.get('banned', []))}")
            print(f"{Colors.WARNING} Frozen: {len(result.get('frozen', []))}")
            print(f"{Colors.WARNING} Restricted: {len(result.get('restricted', []))}")
            print(f"{Colors.INFO} Network errors: {len(result.get('network_err', []))}")
    elif choice == "4":
        from ..utilities.csv_tools import specific_acc_remove
        specific_acc_remove()
    elif choice == "5":
        from ..account.security import otp_viewer
        otp_viewer()
    elif choice == "6":
        from ..account.security import account_info_v41
        asyncio_run(account_info_v41(session_mgr))
    elif choice == "7":
        from ..account.security import view_restricted
        view_restricted()
    elif choice == "8":
        from ..account.security import recover_restricted
        n = asyncio_run(recover_restricted(session_mgr))
        print(f"\n{Colors.SUCCESS} Recovered {n} restricted accounts")
    elif choice == "9":
        from ..account.v41_extras import permanent_limit_remover
        n = asyncio_run(permanent_limit_remover(session_mgr))
        print(f"\n{Colors.SUCCESS} Submitted complaints for {n} accounts")
    elif choice == "10":
        from ..account.profile import changer_account
        asyncio_run(changer_account(session_mgr))
    elif choice == "11":
        print(f"{Colors.WARNING} Note: same username → only 1 account can own it.")
        uname = input(f"{Colors.INFO} Username (no @, 8+ chars): ").strip()
        if uname:
            from ..account.profile import set_username
            n = asyncio_run(set_username(session_mgr, uname))
            print(f"\n{Colors.SUCCESS} Set on {n} accounts")
    elif choice == "12":
        from ..account.profile import set_usernames_from_csv
        n = asyncio_run(set_usernames_from_csv(session_mgr))
        print(f"\n{Colors.SUCCESS} Set on {n} accounts")
    elif choice == "13":
        n = _safe_input_int(f"{Colors.INFO} How many? ", 10)
        length = _safe_input_int(f"{Colors.INFO} Length [10]: ", 10)
        from ..account.profile import generate_usernames_file
        generate_usernames_file(n, length=length)
        print(f"\n{Colors.SUCCESS} Wrote {n} usernames")
    elif choice == "14":
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        if photo:
            from ..account.profile import set_profile_pic
            asyncio_run(set_profile_pic(session_mgr, photo))
    elif choice == "15":
        from ..account.profile import remove_profile_pic
        n = asyncio_run(remove_profile_pic(session_mgr))
        print(f"\n{Colors.SUCCESS} Removed from {n} accounts")
    elif choice == "16":
        from ..account.profile import auto_id_cloner
        n = asyncio_run(auto_id_cloner(session_mgr))
        print(f"\n{Colors.SUCCESS} Cloned {n} accounts")
    elif choice == "17":
        print(f"{Colors.WARNING} Note: 2FA password must be 8+ chars.")
        pwd = input(f"{Colors.INFO} New 2FA password (8+): ").strip()
        cur = input(f"{Colors.INFO} Current password (or empty): ").strip()
        if len(pwd) >= 8:
            from ..account.security import set_2fa_password
            n = asyncio_run(set_2fa_password(session_mgr, pwd, cur))
            print(f"\n{Colors.SUCCESS} 2FA set on {n} accounts")
        else:
            print(f"{Colors.ERROR} Too short (< 8)")
    elif choice == "18":
        from ..account.v41_extras import hide_last_seen
        n = asyncio_run(hide_last_seen(session_mgr))
        print(f"\n{Colors.SUCCESS} Hidden last seen on {n} accounts")
    elif choice == "19":
        from ..account.v41_extras import hide_phone_number
        n = asyncio_run(hide_phone_number(session_mgr))
        print(f"\n{Colors.SUCCESS} Hidden phone number on {n} accounts")
    elif choice == "20":
        from ..account.v41_extras import views_increaser
        chat = input(f"{Colors.INFO} Channel: ").strip()
        msg_id = _safe_input_int(f"{Colors.INFO} Message ID: ", 0)
        if chat and msg_id:
            n = asyncio_run(views_increaser(session_mgr, chat, [msg_id]))
            print(f"\n{Colors.SUCCESS} {n} accounts incremented views")
    elif choice == "21":
        from ..account.profile import reaction_increaser
        chat = input(f"{Colors.INFO} Channel: ").strip()
        msg_id = _safe_input_int(f"{Colors.INFO} Message ID: ", 0)
        reaction = input(f"{Colors.INFO} Emoji [👍]: ").strip() or "👍"
        if chat and msg_id:
            n = asyncio_run(reaction_increaser(session_mgr, chat, msg_id, reaction))
            print(f"\n{Colors.SUCCESS} {n} accounts reacted")
    elif choice == "22":
        from ..account.profile import shares_increaser
        chat = input(f"{Colors.INFO} Channel: ").strip()
        msg_id = _safe_input_int(f"{Colors.INFO} Message ID: ", 0)
        if chat and msg_id:
            n = asyncio_run(shares_increaser(session_mgr, chat, msg_id))
            print(f"\n{Colors.SUCCESS} {n} accounts forwarded")
    elif choice == "23":
        from ..account.profile import nearby_adder_latlong
        target = input(f"{Colors.INFO} Target group: ").strip()
        lat = _safe_input_float(f"{Colors.INFO} Latitude: ", 0)
        long = _safe_input_float(f"{Colors.INFO} Longitude: ", 0)
        per = _safe_input_int(f"{Colors.INFO} Max [50]: ", 50)
        if target:
            n = asyncio_run(nearby_adder_latlong(session_mgr, target, lat, long, per))
            print(f"\n{Colors.SUCCESS} Added {n} nearby members")
    elif choice == "24":
        from ..account.profile import nearby_adder_city
        target = input(f"{Colors.INFO} Target group: ").strip()
        city = input(f"{Colors.INFO} City: ").strip()
        per = _safe_input_int(f"{Colors.INFO} Max [50]: ", 50)
        if target and city:
            n = asyncio_run(nearby_adder_city(session_mgr, target, city, per))
            print(f"\n{Colors.SUCCESS} Added {n} nearby members")
    elif choice == "25":
        from ..account.v41_extras import contact_deleter
        n = asyncio_run(contact_deleter(session_mgr))
        total = sum(n.values())
        print(f"\n{Colors.SUCCESS} Deleted {total} contacts across {len(n)} accounts")
    elif choice == "26":
        from ..account.v41_extras import mass_dm
        msg = input(f"{Colors.INFO} Message: ").strip()
        per = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [5.0]: ", 5.0)
        if msg:
            n = asyncio_run(mass_dm(session_mgr, msg, per, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs")
    elif choice == "27":
        from ..account.v41_extras import add_to_contact_by_group
        per = _safe_input_int(f"{Colors.INFO} Max [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        n = asyncio_run(add_to_contact_by_group(session_mgr, "", per, delay))
        print(f"\n{Colors.SUCCESS} Resolved {n} contacts")
    elif choice == "28":
        from ..account.v41_extras import add_to_contact_by_imp
        vcf = input(f"{Colors.INFO} VCF file: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        per = _safe_input_int(f"{Colors.INFO} Max [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if vcf and target:
            n = asyncio_run(add_to_contact_by_imp(session_mgr, target, vcf, per, delay))
            print(f"\n{Colors.SUCCESS} Added {n} members")
    elif choice == "29":
        from ..account.profile import anonymous_chatter_flow
        target = input(f"{Colors.INFO} Chat bot [@chatbot]: ").strip() or "@chatbot"
        custom = input(f"{Colors.INFO} Custom message: ").strip()
        runs = _safe_input_int(f"{Colors.INFO} Runs [5]: ", 5)
        n = asyncio_run(anonymous_chatter_flow(session_mgr, target, custom, runs))
        print(f"\n{Colors.SUCCESS} Completed {n} runs")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_scrapers(session_mgr: SessionManager) -> None:
    """Scrapers menu."""
    _clear()
    _banner()
    _section("Scrapers (Data Collection)")
    _option(1, "Public Scraper (group members)")
    _option(2, "Private Scraper (private groups)")
    _option(3, "Hidden Scraper (from chat history)")
    _option(4, "Full Scraper (A-Z distribution)")
    _option(5, "Premium Scraper (premium only)")
    _option(6, "Private Hidden Scraper (private + history)")
    _option(7, "Filter members → CSV (all/daily/weekly/online/...)")
    _option(8, "Scrape + add as contacts (no group)")
    _option(9, "Scrape + add as contacts AND target group")
    _back()
    print()
    choice = _get_choice()

    if choice in ("1", "2", "3", "4", "5", "6"):
        source = input(f"{Colors.INFO} Source group (@username or link): ").strip()
        if not source:
            return
        max_per = _safe_input_int(f"{Colors.INFO} Max per account (default 50): ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay (default 1.0): ", 1.0)
        modes = {
            "1": "public", "2": "private", "3": "hidden",
            "4": "full", "5": "premium", "6": "pvt_hidden",
        }
        from ..scrapers import run_scraper

        result = asyncio_run(run_scraper(modes[choice], source, None, max_per, delay))
        print(f"\n{Colors.SUCCESS} Scraped {result.scraped} members")
    elif choice == "7":
        source = input(f"{Colors.INFO} Source group: ").strip()
        mode = input(f"{Colors.INFO} Mode [all/daily/weekly/monthly/online/nonactive/hidden] [all]: ").strip().lower() or "all"
        limit = _safe_input_int(f"{Colors.INFO} Max members [5000]: ", 5000)
        out = input(f"{Colors.INFO} Output CSV [filtered.csv]: ").strip() or "filtered.csv"
        if source:
            from ..scrapers import filter_members_to_csv
            n = asyncio_run(filter_members_to_csv(session_mgr, source, mode, out, limit))
            print(f"\n{Colors.SUCCESS} Wrote {n} members → {out}")
    elif choice == "8":
        source = input(f"{Colors.INFO} Source group: ").strip()
        max_per = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if source:
            from ..scrapers import scrape_to_contacts
            n = asyncio_run(scrape_to_contacts(session_mgr, source, max_per, delay))
            print(f"\n{Colors.SUCCESS} Added {n} contacts")
    elif choice == "9":
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        max_per = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if source and target:
            from ..scrapers import scrape_to_contacts_and_group
            from ..core import DedupManager, FloodTracker
            n = asyncio_run(scrape_to_contacts_and_group(
                session_mgr, source, target, max_per, delay,
                dedup=DedupManager(), flood_tracker=_get_flood_tracker(),
            ))
            print(f"\n{Colors.SUCCESS} Added {n} members to target")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_adders(session_mgr: SessionManager, dedup: DedupManager) -> None:
    """Outreach adders menu."""
    _clear()
    _banner()
    _section("Outreach Adders (Complete)")
    _option(1, "Direct Adder (source → target group)")
    _option(2, "Contact Adder (with add_contact first)")
    _option(3, "Bulk Adder (batch contacts → target)")
    _option(4, "File→Contacts (data.csv → contacts)")
    _option(5, "Contacts→Target Group")
    _option(6, "Ramex Adder (scrape + add, 7 modes)")
    _option(7, "Single Adder (one-by-one with v44 pipeline)")
    _option(8, "Scrape + Add as Contacts (no group)")
    _option(9, "Scrape + Add to Contacts AND Group")
    _back()
    print()
    choice = _get_choice()

    max_per = _safe_input_int(f"{Colors.INFO} Max per account (default 50): ", 50)
    delay = _safe_input_float(f"{Colors.INFO} Delay (default 2.0): ", 2.0)

    flood = _get_flood_tracker()
    extra = ""
    if choice == "1":
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        if source and target:
            from ..adders.direct import DirectAdder
            adder = DirectAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(source, target, max_per, delay))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "2":
        target = input(f"{Colors.INFO} Target group: ").strip()
        source = input(f"{Colors.INFO} Source group: ").strip()
        if target and source:
            from ..adders.contact import ContactAdder
            adder = ContactAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(source, target, max_per, delay))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "3":
        target = input(f"{Colors.INFO} Target group: ").strip()
        if target:
            from ..adders.bulk import BulkAdder
            adder = BulkAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(target, max_per, delay))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "4":
        from ..adders.file_to_contacts import FileToContactsAdder
        adder = FileToContactsAdder(get_config(), session_mgr, dedup, flood)
        result = asyncio_run(adder.run(max_per, delay))
        print(f"\n{Colors.SUCCESS} Added {result.success} contacts")
    elif choice == "5":
        target = input(f"{Colors.INFO} Target group: ").strip()
        if target:
            from ..adders.contacts_to_group import ContactsToGroupAdder
            adder = ContactsToGroupAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(target, max_per, delay))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "6":
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        if source and target:
            from ..adders.ramex import RamexAdder
            adder = RamexAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(source, target, max_per, delay))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "7":
        target = input(f"{Colors.INFO} Target group: ").strip()
        source = input(f"{Colors.INFO} Source group (for data): ").strip()
        if target and source:
            from ..adders.single import SingleAdder
            adder = SingleAdder(get_config(), session_mgr, dedup, flood)
            result = asyncio_run(adder.run(target, max_per, delay))
            print(f"\n{Colors.SUCCESS} Added {result.success} members")
    elif choice == "8":
        source = input(f"{Colors.INFO} Source group: ").strip()
        if source:
            from ..scrapers import scrape_to_contacts
            n = asyncio_run(scrape_to_contacts(session_mgr, source, max_per, delay))
            print(f"\n{Colors.SUCCESS} Added {n} contacts")
    elif choice == "9":
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        if source and target:
            from ..scrapers import scrape_to_contacts_and_group
            from ..core import DedupManager, FloodTracker
            n = asyncio_run(scrape_to_contacts_and_group(
                session_mgr, source, target, max_per, delay,
                dedup=DedupManager(), flood_tracker=_get_flood_tracker(),
            ))
            print(f"\n{Colors.SUCCESS} Added {n} members to target")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_filters(session_mgr: SessionManager, dedup: DedupManager) -> None:
    """Filters menu (from ramexfour)."""
    _clear()
    _banner()
    _section("Filter Adders (from ramexfour)")
    _option(1, "Daily Active Adder")
    _option(2, "Weekly Active Adder")
    _option(3, "Monthly Active Adder")
    _option(4, "Online Member Adder")
    _option(5, "Non-Active Member Adder")
    _option(6, "Hidden Member Adder")
    _option(7, "Single-account Filter Adder (pick one account, add by username)")
    _option(8, "Live Group Filter (remove data.csv rows already in target)")
    _back()
    print()
    choice = _get_choice()

    modes = {"1": "daily", "2": "weekly", "3": "monthly", "4": "online", "5": "nonactive", "6": "hidden"}
    if choice in modes:
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        if source and target:
            max_per = _safe_input_int(f"{Colors.INFO} Max per account (default 50): ", 50)
            delay = _safe_input_float(f"{Colors.INFO} Delay (default 2.0): ", 2.0)
            from ..adders.ramex import RamexAdder

            adder = RamexAdder(get_config(), session_mgr, dedup, _get_flood_tracker())
            result = asyncio_run(adder.run(source, target, max_per, delay, mode=modes[choice]))
            extra = f", {len(result.flooded_accounts)} flooded"
            print(f"\n{Colors.SUCCESS} Added {result.success} members{extra}")
    elif choice == "7":
        # Single-account filter adder
        target = input(f"{Colors.INFO} Target group: ").strip()
        acct_idx = _safe_input_int(f"{Colors.INFO} Account # in phone.csv (1-based) [1]: ", 1)
        max_adds = _safe_input_int(f"{Colors.INFO} Max adds (default 50): ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay (default 2.0): ", 2.0)
        if target:
            from ..utilities.csv_tools import single_filter_adder
            n = asyncio_run(single_filter_adder(session_mgr, target, acct_idx, max_adds, delay))
            print(f"\n{Colors.SUCCESS} Added {n} members from data.csv")
    elif choice == "8":
        # Live group filter
        target = input(f"{Colors.INFO} Target group: ").strip()
        if target:
            from ..utilities.csv_tools import filter_data_csv_against_group
            n = asyncio_run(filter_data_csv_against_group(session_mgr, target))
            print(f"\n{Colors.SUCCESS} Removed {n} rows from data.csv (already in target)")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_nearby(session_mgr: SessionManager, dedup: DedupManager) -> None:
    """Nearby adder menu (from ramexfour)."""
    _clear()
    _banner()
    _section("Nearby Adder (by country)")
    _option(1, "Auto-detect (20 countries)")
    _option(2, "By Lat/Long")
    _option(3, "By City")
    _back()
    print()
    choice = _get_choice()

    if choice == "1":
        target = input(f"{Colors.INFO} Target group: ").strip()
        if target:
            from ..nearby.countries import NearbyAdder

            adder = NearbyAdder(get_config(), session_mgr, dedup, _get_flood_tracker())
            result = asyncio_run(adder.run(target, max_per=50, delay=2.0))
            print(f"\n{Colors.SUCCESS} Added {result.success} members")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_messaging(session_mgr: SessionManager) -> None:
    """Messaging menu (from ts.py)."""
    _clear()
    _banner()
    _section("Messaging (from ts.py)")
    _option(1, "Send Message to Group")
    _option(2, "Send Message + Photo to Group")
    _option(3, "Multi-Message → One Group (from message.csv)")
    _option(4, "Forward to Channels (with tag)")
    _option(5, "Forward without Tag (anonymous copy)")
    _option(6, "Send DM (PM spam) to @username")
    _option(7, "Send DM + Photo")
    _option(8, "Multi-Message → Multi-Groups")
    _option(9, "Single Message → Multi-Groups")
    _option(10, "DM all usernames in data.csv")
    _option(11, "DM + photo all usernames in data.csv")
    _option(12, "Ramex sender (scrape group + DM each)")
    _option(13, "Single-account: msg → 1 group (N copies)")
    _option(14, "Single-account: photo → 1 group (N copies)")
    _option(15, "Single-account: photo → multi groups")
    _option(16, "Multi-msg + photo → 1 group")
    _option(17, "Multi-msg + photo → multi groups")
    _back()
    print()
    choice = _get_choice()

    if choice == "1":
        from ..messaging.group import send_to_group
        target = input(f"{Colors.INFO} Target group: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        if target and msg:
            n = asyncio_run(send_to_group(session_mgr, target, msg))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "2":
        from ..messaging.group import send_to_group_with_photo
        target = input(f"{Colors.INFO} Target group: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        if target and msg and photo:
            n = asyncio_run(send_to_group_with_photo(session_mgr, target, msg, photo))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "3":
        from ..messaging.group import send_multi_msg_single_group, load_messages_csv
        target = input(f"{Colors.INFO} Target group: ").strip()
        msgs = load_messages_csv()
        per_acct = _safe_input_int(f"{Colors.INFO} Sends per account [10]: ", 10)
        if target and msgs:
            n = asyncio_run(send_multi_msg_single_group(session_mgr, target, msgs, per_acct))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "4":
        from ..messaging.forward import forward_to_channels
        source = input(f"{Colors.INFO} Source channel: ").strip()
        targets = input(f"{Colors.INFO} Target channels (comma-sep): ").strip().split(",")
        targets = [t.strip() for t in targets if t.strip()]
        if source and targets:
            n = asyncio_run(forward_to_channels(session_mgr, source, targets))
            print(f"\n{Colors.SUCCESS} Forwarded {n} messages")
    elif choice == "5":
        from ..messaging.forward import forward_without_tag
        source = input(f"{Colors.INFO} Source channel: ").strip()
        targets = input(f"{Colors.INFO} Target channels (comma-sep): ").strip().split(",")
        targets = [t.strip() for t in targets if t.strip()]
        if source and targets:
            n = asyncio_run(forward_without_tag(session_mgr, source, targets))
            print(f"\n{Colors.SUCCESS} Copied {n} messages (no tag)")
    elif choice == "6":
        from ..messaging.group import send_dm
        uname = input(f"{Colors.INFO} Target @username: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        if uname and msg:
            n = asyncio_run(send_dm(session_mgr, uname, msg))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs")
    elif choice == "7":
        from ..messaging.group import send_dm_with_photo
        uname = input(f"{Colors.INFO} Target @username: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        if uname and msg and photo:
            n = asyncio_run(send_dm_with_photo(session_mgr, uname, msg, photo))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs+photo")
    elif choice == "8":
        from ..messaging.group import (
            send_multi_msg_multi_groups,
            load_messages_csv,
            load_groups_csv,
        )
        groups = load_groups_csv()
        msgs = load_messages_csv()
        per_acct = _safe_input_int(f"{Colors.INFO} Sends per account [10]: ", 10)
        if groups and msgs:
            n = asyncio_run(send_multi_msg_multi_groups(session_mgr, groups, msgs, per_acct))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "9":
        from ..messaging.group import send_single_msg_multi_groups, load_groups_csv
        groups = load_groups_csv()
        msg = input(f"{Colors.INFO} Message: ").strip()
        if groups and msg:
            n = asyncio_run(send_single_msg_multi_groups(session_mgr, groups, msg))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "10":
        from ..messaging.group import send_dm_from_data_csv
        msg = input(f"{Colors.INFO} Message: ").strip()
        per_acct = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if msg:
            n = asyncio_run(send_dm_from_data_csv(session_mgr, msg, per_acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs")
    elif choice == "11":
        from ..messaging.group import send_dm_with_photo_from_data_csv
        msg = input(f"{Colors.INFO} Message: ").strip()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        per_acct = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if msg and photo:
            n = asyncio_run(send_dm_with_photo_from_data_csv(session_mgr, msg, photo, per_acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs+photo")
    elif choice == "12":
        from ..messaging.group import ramex_sender
        source = input(f"{Colors.INFO} Source group: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        per_acct = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if source and msg:
            n = asyncio_run(ramex_sender(session_mgr, source, msg, per_acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} DMs")
    elif choice == "13":
        from ..messaging.group import send_message_single_account
        target = input(f"{Colors.INFO} Target group: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        acct = _safe_input_int(f"{Colors.INFO} Account # [1]: ", 1)
        n_sends = _safe_input_int(f"{Colors.INFO} Num sends [5]: ", 5)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if target and msg:
            n = asyncio_run(send_message_single_account(session_mgr, target, msg, acct, n_sends, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice == "14":
        from ..messaging.group import send_photo_single_account
        target = input(f"{Colors.INFO} Target group: ").strip()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        caption = input(f"{Colors.INFO} Caption: ").strip()
        acct = _safe_input_int(f"{Colors.INFO} Account # [1]: ", 1)
        n_sends = _safe_input_int(f"{Colors.INFO} Num sends [5]: ", 5)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if target and photo:
            n = asyncio_run(send_photo_single_account(session_mgr, target, photo, caption, acct, n_sends, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} photos")
    elif choice == "15":
        from ..messaging.group import send_photo_to_multi_groups_single_account, load_groups_csv
        groups = load_groups_csv()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        caption = input(f"{Colors.INFO} Caption: ").strip()
        acct = _safe_input_int(f"{Colors.INFO} Account # [1]: ", 1)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if groups and photo:
            n = asyncio_run(send_photo_to_multi_groups_single_account(session_mgr, groups, photo, caption, acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} photos")
    elif choice == "16":
        from ..messaging.group import send_multi_msg_with_photo_single_group, load_messages_csv
        target = input(f"{Colors.INFO} Target group: ").strip()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        msgs = load_messages_csv()
        per_acct = _safe_input_int(f"{Colors.INFO} Sends per account [10]: ", 10)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if target and photo and msgs:
            n = asyncio_run(send_multi_msg_with_photo_single_group(session_mgr, target, msgs, photo, per_acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} messages+photo")
    elif choice == "17":
        from ..messaging.group import (
            send_multi_msg_with_photo_multi_groups,
            load_messages_csv,
            load_groups_csv,
        )
        groups = load_groups_csv()
        photo = input(f"{Colors.INFO} Photo path: ").strip()
        msgs = load_messages_csv()
        per_acct = _safe_input_int(f"{Colors.INFO} Sends per account [10]: ", 10)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if groups and photo and msgs:
            n = asyncio_run(send_multi_msg_with_photo_multi_groups(session_mgr, groups, msgs, photo, per_acct, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} messages+photo")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_reports(session_mgr: SessionManager) -> None:
    """Reports menu (from opthree)."""
    _clear()
    _banner()
    _section("Reports (from opthree.py)")
    _option(1, "Report: Fake")
    _option(2, "Report: Spam")
    _option(3, "Report: Violence")
    _option(4, "Report: Child Abuse")
    _option(5, "Report: Copyright")
    _option(6, "Report: Geo Irrelevant")
    _option(7, "Report: Personal Details")
    _option(8, "Report: Illegal Drugs")
    _option(9, "Report: Pornography")
    _option(10, "Report: Others")
    _option(11, "Report USER (by @username)")
    _option(12, "Send Scam Report → @notoscam")
    _back()
    print()
    choice = _get_choice()

    reasons = {
        "1": "fake", "2": "spam", "3": "violence", "4": "childabuse",
        "5": "copyright", "6": "geoirrelevant", "7": "personaldetails",
        "8": "illegaldrugs", "9": "pornography", "10": "others",
    }
    if choice in reasons:
        channel = input(f"{Colors.INFO} Channel (@username): ").strip()
        post_id = _safe_input_int(f"{Colors.INFO} Post ID: ", 0)
        if channel:
            from ..reports.reasons import run_report

            result = asyncio_run(run_report(session_mgr, reasons[choice], channel, post_id, 5, 2.0))
            print(f"\n{Colors.SUCCESS} Sent {result.success} reports")
    elif choice == "11":
        username = input(f"{Colors.INFO} Target user @username: ").strip()
        reason_input = input(
            f"{Colors.INFO} Reason (fake/spam/violence/.../others) [spam]: "
        ).strip().lower() or "spam"
        msg = input(f"{Colors.INFO} Optional message: ").strip()
        if username:
            from ..reports.reasons import report_user

            result = asyncio_run(report_user(session_mgr, username, reason_input, msg))
            print(f"\n{Colors.SUCCESS} Sent {result.success} user reports")
    elif choice == "12":
        msg = input(f"{Colors.INFO} Scam report message: ").strip()
        if msg:
            from ..reports.reasons import send_scam_report
            n = asyncio_run(send_scam_report(session_mgr, msg))
            print(f"\n{Colors.SUCCESS} Sent {n} scam reports")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_utilities() -> None:
    """Utilities menu."""
    _clear()
    _banner()
    _section("Utilities")
    _option(1, "CSV Blank Remover")
    _option(2, "Auto-Remove Banned Numbers")
    _option(3, "Limit Checker/Remover (@spambot)")
    _option(4, "Group Chat Cloner")
    _option(5, "Auto Group Maker")
    _option(6, "VCF → numbers.csv (extract only)")
    _option(7, "Status (files + dedup)")
    _option(8, "Delete already-done from data.csv")
    _option(9, "Check numbers (Telegram registration)")
    _option(10, "Import VCF as contacts (addtocontactbyimp)")
    _option(11, "Anonymous Chatter (N msgs/chat from all accounts)")
    _back()
    print()
    choice = _get_choice()

    if choice == "1":
        from ..utilities.csv_tools import csv_blank_remover
        csv_blank_remover()
    elif choice == "2":
        from ..utilities.csv_tools import auto_remove
        auto_remove()
    elif choice == "3":
        from ..utilities.csv_tools import limit_check_and_remove
        from ..core import SessionManager
        n = asyncio_run(limit_check_and_remove(SessionManager()))
        print(f"\n{Colors.SUCCESS} Processed {n} accounts")
    elif choice == "4":
        source = input(f"{Colors.INFO} Source group: ").strip()
        target = input(f"{Colors.INFO} Target group: ").strip()
        n_msgs = _safe_input_int(f"{Colors.INFO} Num messages: ", 100)
        if source and target:
            from ..utilities.csv_tools import group_chat_cloner
            from ..core import SessionManager
            n = asyncio_run(group_chat_cloner(SessionManager(), source, target, n_msgs))
            print(f"\n{Colors.SUCCESS} Copied {n} messages")
    elif choice == "5":
        per = _safe_input_int(f"{Colors.INFO} Groups per account: ", 5)
        from ..utilities.csv_tools import auto_group_maker
        from ..core import SessionManager
        n = asyncio_run(auto_group_maker(SessionManager(), per_account=per))
        print(f"\n{Colors.SUCCESS} Created {n} groups")
    elif choice == "6":
        vcf = input(f"{Colors.INFO} VCF file path: ").strip()
        if vcf:
            from ..utilities.csv_tools import extract_vcf_to_numbers
            n = extract_vcf_to_numbers(vcf)
            print(f"\n{Colors.SUCCESS} Extracted {n} numbers → numbers.csv")
    elif choice == "7":
        _show_status()
    elif choice == "8":
        from ..utilities.csv_tools import delete_already_filter
        n = delete_already_filter()
        print(f"\n{Colors.SUCCESS} Removed {n} rows from data.csv")
    elif choice == "9":
        from ..utilities.csv_tools import check_numbers
        from ..core import SessionManager
        n = asyncio_run(check_numbers(SessionManager()))
        print(f"\n{Colors.SUCCESS} Found {n} valid numbers")
    elif choice == "10":
        vcf = input(f"{Colors.INFO} VCF file path: ").strip()
        per = _safe_input_int(f"{Colors.INFO} Max per account [50]: ", 50)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if vcf:
            from ..utilities.csv_tools import import_vcf_as_contacts
            from ..core import SessionManager
            n = asyncio_run(import_vcf_as_contacts(SessionManager(), vcf, per, delay))
            print(f"\n{Colors.SUCCESS} Imported {n} contacts")
    elif choice == "11":
        target = input(f"{Colors.INFO} Target chat/group: ").strip()
        msg = input(f"{Colors.INFO} Message: ").strip()
        n_per = _safe_input_int(f"{Colors.INFO} Messages per account [5]: ", 5)
        delay = _safe_input_float(f"{Colors.INFO} Delay [2.0]: ", 2.0)
        if target and msg:
            from ..utilities.csv_tools import anonymous_chatter
            from ..core import SessionManager
            n = asyncio_run(anonymous_chatter(SessionManager(), target, msg, n_per, delay))
            print(f"\n{Colors.SUCCESS} Sent {n} messages")
    elif choice in ("0", "00"):
        return
    _pause()


def menu_groups(session_mgr: SessionManager) -> None:
    """Groups menu: mass join / leave groups."""
    _clear()
    _banner()
    _section("Group Management")
    _option(1, "Join one group (all accounts)")
    _option(2, "Join groups from CSV (groups.csv)")
    _option(3, "Leave one group (all accounts)")
    _option(4, "Leave groups from CSV (groups.csv)")
    _back()
    print()
    choice = _get_choice()

    if choice == "1":
        grp = input(f"{Colors.INFO} Group @username/link: ").strip()
        if grp:
            from ..groups import join_groups
            n = asyncio_run(join_groups(session_mgr, [grp]))
            print(f"\n{Colors.SUCCESS} {n} joins")
    elif choice == "2":
        from ..groups import join_from_csv
        n = asyncio_run(join_from_csv(session_mgr))
        print(f"\n{Colors.SUCCESS} {n} joins")
    elif choice == "3":
        grp = input(f"{Colors.INFO} Group @username/link: ").strip()
        if grp:
            from ..groups import leave_groups
            n = asyncio_run(leave_groups(session_mgr, [grp]))
            print(f"\n{Colors.SUCCESS} {n} leaves")
    elif choice == "4":
        # Reuse the loader from messaging.group (simpler).
        from ..groups import leave_groups
        from ..messaging.group import load_groups_csv
        groups = load_groups_csv("groups.csv")
        if groups:
            n = asyncio_run(leave_groups(session_mgr, groups))
            print(f"\n{Colors.SUCCESS} {n} leaves")
        else:
            print(f"{Colors.WARNING} groups.csv empty or missing")
    elif choice in ("0", "00"):
        return
    _pause()


def _show_status() -> None:
    """Show status of files and dedup state."""
    from pathlib import Path

    _clear()
    _banner()
    _section("Status")
    print()

    data_file = Path("data.csv")
    if data_file.exists():
        import csv as csv_mod

        with open(data_file, "r", encoding="utf-8") as f:
            count = sum(1 for _ in csv_mod.DictReader(f))
        print(f"  data.csv: {Colors.GREEN}{count} members{Colors.RESET}")
    else:
        print(f"  data.csv: {Colors.RED}not found{Colors.RESET}")

    phones = load_phones()
    print(f"  phone.csv: {Colors.GREEN}{len(phones)} accounts{Colors.RESET}")

    sessions = list(Path("sessions").glob("*.session")) if Path("sessions").exists() else []
    print(f"  sessions: {Colors.GREEN}{len(sessions)} files{Colors.RESET}")

    # PeerFlood cooldown status.
    flood = _get_flood_tracker()
    flood_summary = flood.summary()
    in_cd = flood_summary["in_cooldown"]
    total = flood_summary["total"]
    if in_cd > 0:
        print(
            f"  flooded.csv: {Colors.RED}{in_cd} account(s) in 24h cooldown{Colors.RESET} "
            f"({total} total tracked)"
        )
    elif total > 0:
        print(
            f"  flooded.csv: {Colors.GREEN}0 in cooldown{Colors.RESET} "
            f"({total} previously flooded)"
        )
    else:
        print(f"  flooded.csv: {Colors.GREEN}no PeerFlood events recorded{Colors.RESET}")

    # Dedup state.
    dedup = DedupManager()
    print(f"  done.csv: {Colors.GREEN}{dedup.count()} done{Colors.RESET}")

    print()
    _pause()


def main_menu() -> None:
    """Main menu loop."""
    cfg = get_config()
    ok, msg = cfg.validate()
    if not ok:
        print(f"{Colors.ERROR} Configuration invalid: {msg}")
        print(f"{Colors.INFO} Edit config.ini with API_ID and API_HASH")
        print(f"{Colors.INFO} Get them from https://my.telegram.org")
        sys.exit(1)

    session_mgr = SessionManager()
    dedup = DedupManager()

    while True:
        _clear()
        _banner()
        print(f"  {Colors.BG_CYAN}{Colors.BLACK}{Colors.BRIGHT}{' ╔══ Main Menu ══╗ ':^66}{Colors.RESET}")
        print()
        _option(1, "Accounts — Login + Security + Profile + Privacy")
        _option(2, "Scrapers — Public / Private / Hidden / Full / Premium")
        _option(3, "Adders — Direct / Contact / Bulk / Ramex / Single")
        _option(4, "Filters — Daily / Weekly / Monthly / Online / Hidden")
        _option(5, "Nearby — 20 Countries + Lat/Long + City")
        _option(6, "Messaging — Send / DM / Forward / Multi-msg+Photo")
        _option(7, "Reports — 10 Reasons + User Report + Scam")
        _option(8, "Utilities — CSV / VCF / SpamBot / Status / Anonymous")
        _option(9, "Groups — Mass Join / Leave + From CSV")
        print()
        _option(0, "Exit", Colors.RED)
        print()
        choice = _get_choice()

        if choice == "1":
            menu_accounts(session_mgr)
        elif choice == "2":
            menu_scrapers(session_mgr)
        elif choice == "3":
            menu_adders(session_mgr, dedup)
        elif choice == "4":
            menu_filters(session_mgr, dedup)
        elif choice == "5":
            menu_nearby(session_mgr, dedup)
        elif choice == "6":
            menu_messaging(session_mgr)
        elif choice == "7":
            menu_reports(session_mgr)
        elif choice == "8":
            menu_utilities()
        elif choice == "9":
            menu_groups(session_mgr)
        elif choice in ("0", "00", "exit", "quit"):
            print(f"{Colors.INFO} Goodbye!")
            sys.exit(0)
        else:
            print(f"{Colors.ERROR} Invalid option")
            time.sleep(1)
