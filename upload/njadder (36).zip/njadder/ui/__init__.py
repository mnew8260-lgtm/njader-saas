"""UI components."""
from __future__ import annotations

from .colors import Colors
from .menu import main_menu

__all__ = ["Colors", "main_menu"]
