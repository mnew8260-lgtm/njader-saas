"""Group management: join/leave groups across all accounts."""
from __future__ import annotations

import asyncio
import logging
from typing import Iterable

from pyrogram.errors import UserAlreadyParticipant, UserNotParticipant

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)

# Internal "do not leave" list — protects developer's support channels.
_RESTRICTED_LEAVE_TARGETS = frozenset(
    {
        "nmdder_support",
        "@nmdder_support",
        "njadder_pro",
        "@njadder_pro",
        "nmdder_ch",
        "@nmdder_ch",
        "https://t.me/nmdder_support",
        "https://t.me/njadder_pro",
        "https://t.me/nmdder_ch",
    }
)


def _is_restricted(target: str) -> bool:
    """Return True if ``target`` is in the protected leave-list."""
    return target.lower() in _RESTRICTED_LEAVE_TARGETS


async def join_groups(
    session_mgr: SessionManager,
    targets: Iterable[str],
    delay: float = 1.0,
) -> int:
    """Have every account in ``phone.csv`` join each group in ``targets``.

    Args:
        session_mgr: Shared session manager.
        targets: Iterable of @usernames or t.me/... links.
        delay: Delay between consecutive joins per account.

    Returns:
        Number of successful join operations across all accounts.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    targets = [t.strip() for t in targets if t and t.strip()]
    if not targets:
        log.error("No groups to join")
        return 0

    joined_total = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                for grp in targets:
                    if not grp:
                        continue
                    try:
                        await app.join_chat(grp)
                        joined_total += 1
                        log.info("%s: joined %s", phone, grp)
                        await smart_delay(delay, "join_chat")
                    except UserAlreadyParticipant:
                        log.debug("%s: already in %s", phone, grp)
                    except Exception as e:
                        log.warning("%s: join %s failed: %s", phone, grp, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("join_groups complete: %d joins", joined_total)
    return joined_total


async def leave_groups(
    session_mgr: SessionManager,
    targets: Iterable[str],
    delay: float = 1.0,
) -> int:
    """Have every account leave each group in ``targets``.

    Protected targets (developer support channels) are silently
    skipped to prevent accidental mass-leave of the support group.

    Args:
        session_mgr: Shared session manager.
        targets: Iterable of @usernames or chat IDs.
        delay: Delay between consecutive leaves per account.

    Returns:
        Number of successful leave operations across all accounts.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    targets = [t.strip() for t in targets if t and t.strip()]
    if not targets:
        log.error("No groups to leave")
        return 0

    left_total = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                for grp in targets:
                    if not grp:
                        continue
                    if _is_restricted(grp):
                        log.warning("%s: skipping protected %s", phone, grp)
                        continue
                    try:
                        await app.leave_chat(grp)
                        left_total += 1
                        log.info("%s: left %s", phone, grp)
                        await smart_delay(delay, "fast")
                    except UserNotParticipant:
                        log.debug("%s: not in %s", phone, grp)
                    except Exception as e:
                        log.warning("%s: leave %s failed: %s", phone, grp, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("leave_groups complete: %d leaves", left_total)
    return left_total


async def join_from_csv(
    session_mgr: SessionManager,
    csv_path: str = "groups.csv",
    delay: float = 1.0,
) -> int:
    """Join all groups listed in a CSV file (one per line, first column)."""
    from pathlib import Path
    import csv as _csv

    p = Path(csv_path)
    if not p.exists():
        log.error("%s not found", csv_path)
        return 0

    groups: list[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in _csv.reader(f):
            if row and row[0].strip():
                groups.append(row[0].strip())

    return await join_groups(session_mgr, groups, delay=delay)
