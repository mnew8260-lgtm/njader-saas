"""Hidden scraper: collects members from chat history."""
from __future__ import annotations

import logging
from pathlib import Path

from pyrogram import Client
from pyrogram.errors import FloodWait

from ..config import Config
from ..core import SessionManager, load_phones, progress_bar, smart_delay
from .base import BaseScraper, ScrapeResult

log = logging.getLogger(__name__)


class HiddenScraper(BaseScraper):
    """Collects members from a group's chat history.

    Useful for groups where members' privacy settings hide them
    from get_chat_members. Reads message senders instead.
    """

    def __init__(self, settings: Config, session_mgr: SessionManager) -> None:
        super().__init__(settings, session_mgr)

    async def run(
        self,
        source: str,
        max_per_account: int = 1000,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute the hidden scrape operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return ScrapeResult()

        self._ensure_data_header()
        result = ScrapeResult(data_file=str(self.data_file))
        log.info("Starting HiddenScraper: %d accounts", len(phones))

        # Offset tracking for distributed scraping
        offset = 0

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            scraped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    if not await self._join_group(app, source):
                        continue

                    try:
                        chat = await app.get_chat(source)
                    except Exception as e:
                        log.error("%s: failed to resolve group: %s", phone, e)
                        continue

                    try:
                        async for msg in app.get_chat_history(
                            chat_id=chat.id,
                            limit=max_per_account,
                            offset_id=offset,
                        ):
                            if not msg.from_user:
                                continue
                            user = msg.from_user
                            self._append_member(
                                {
                                    "user_id": user.id,
                                    "first_name": user.first_name or "",
                                    "last_name": user.last_name or "",
                                    "username": user.username or "",
                                    "is_premium": bool(getattr(user, "is_premium", False)),
                                    "phone_number": getattr(user, "phone_number", "") or "",
                                }
                            )
                            scraped += 1
                            offset = msg.id
                            if (scraped % 50) == 0:
                                progress_bar(scraped, max_per_account, label=phone)
                            if scraped >= max_per_account:
                                break
                    except FloodWait as e:
                        log.warning("%s: FloodWait %ds", phone, e.value)
                        await smart_delay(delay, "fast")
                    except Exception as e:
                        log.error("%s: scrape failed: %s", phone, e)

            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.scraped += scraped
            result.per_account[phone] = scraped
            log.info("%s: +%d scraped (offset=%d)", phone, scraped, offset)

        log.info("HiddenScraper complete: %d scraped", result.scraped)
        return result


class PrivateHiddenScraper(HiddenScraper):
    """Hidden scraper for **private** groups (via invite link).

    Same logic as :class:`HiddenScraper` but expects ``source`` to be
    a private invite link (``https://t.me/+abcd`` or
    ``t.me/joinchat/...``). The account must join the chat first
    before scraping history.
    """

    def __init__(self, settings: Config, session_mgr: SessionManager) -> None:
        super().__init__(settings, session_mgr)

    async def run(
        self,
        source: str,
        max_per_account: int = 1000,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute the private hidden scrape operation."""
        log.info("PrivateHiddenScraper: source=%s", source)
        return await super().run(source, max_per_account, delay, phones)
