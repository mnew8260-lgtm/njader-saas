"""Public scraper: collects members from a public group."""
from __future__ import annotations

import logging

from pyrogram.errors import FloodWait

from ..config import Config
from ..core import SessionManager, load_phones, smart_delay
from .base import BaseScraper, ScrapeResult

log = logging.getLogger(__name__)

# Build the canonical filter list: empty (no filter) + a-z + 0-9.
# An empty filter is required to capture members whose names start with
# non-ASCII characters (e.g. Arabic, Cyrillic, Chinese).
_ALL_FILTERS: list[str] = [""] + list("abcdefghijklmnopqrstuvwxyz") + list("0123456789")


def _distribute_filters(
    filters: list[str], n_accounts: int
) -> list[list[str]]:
    """Distribute ``filters`` across ``n_accounts`` accounts.

    Guarantees that every account receives a non-empty slice when possible.
    If there are more accounts than filters, the extra accounts receive a
    single empty filter (i.e. "no filter") so they can still contribute.
    """
    if n_accounts <= 0:
        return [list(filters)]
    if not filters:
        return [[] for _ in range(n_accounts)]

    n_filters = len(filters)
    if n_filters >= n_accounts:
        # Even split: each account gets ceil(n_filters / n_accounts) filters.
        per = max(1, -(-n_filters // n_accounts))  # ceiling division
        chunks: list[list[str]] = [
            filters[i * per:(i + 1) * per] for i in range(n_accounts)
        ]
        # Last chunk absorbs any remainder.
        remainder = filters[n_accounts * per:]
        if remainder and chunks:
            chunks[-1].extend(remainder)
        return chunks

    # Fewer filters than accounts: assign one filter per account, the extra
    # accounts fall back to "no filter" so they can still scrape.
    result: list[list[str]] = [[f] for f in filters]
    while len(result) < n_accounts:
        result.append([""])
    return result


class PublicScraper(BaseScraper):
    """Collects members from a public group via ``get_chat_members``.

    Uses A-Z filter distribution across accounts for better coverage.
    """

    def __init__(self, settings: Config, session_mgr: SessionManager) -> None:
        super().__init__(settings, session_mgr)

    async def run(
        self,
        source: str,
        max_per_account: int = 50,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute the public scrape operation."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return ScrapeResult()

        self._ensure_data_header()
        result = ScrapeResult(data_file=str(self.data_file))
        log.info("Starting PublicScraper: %d accounts", len(phones))

        # A-Z filter distribution — balanced and non-empty per account.
        per_account_filters = _distribute_filters(_ALL_FILTERS, len(phones))

        for idx, phone in enumerate(phones):
            my_filters = per_account_filters[idx]
            log.info("Account %d/%d: %s filters=%s", idx + 1, len(phones), phone, my_filters)
            scraped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    if not await self._join_group(app, source):
                        continue

                    try:
                        chat = await app.get_chat(source)
                    except Exception as e:
                        log.error("%s: failed to resolve group: %s", phone, e)
                        continue

                    for flt in my_filters:
                        try:
                            async for member in app.get_chat_members(
                                chat_id=chat.id,
                                filter=flt if flt else None,
                            ):
                                user = member.user
                                self._append_member(
                                    {
                                        "user_id": user.id,
                                        "first_name": user.first_name or "",
                                        "last_name": user.last_name or "",
                                        "username": user.username or "",
                                        "is_premium": bool(getattr(user, "is_premium", False)),
                                        "phone_number": getattr(user, "phone_number", "") or "",
                                    }
                                )
                                scraped += 1
                                if scraped >= max_per_account:
                                    break
                        except FloodWait as e:
                            log.warning("%s: FloodWait %ds", phone, e.value)
                            await smart_delay(delay, "fast")
                        except Exception as e:
                            log.error("%s: filter %r failed: %s", phone, flt, e)

                        if scraped >= max_per_account:
                            break

            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.scraped += scraped
            result.per_account[phone] = scraped
            log.info("%s: +%d scraped", phone, scraped)

        log.info("PublicScraper complete: %d scraped", result.scraped)
        return result


class PrivateScraper(PublicScraper):
    """Collects members from a private group (via invite link).

    Same logic as :class:`PublicScraper` but expects ``source`` to be a
    private invite link (``https://t.me/+abcd`` or ``t.me/joinchat/...``).
    """
    pass
