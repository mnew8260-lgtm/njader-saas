"""Premium scraper: collects only premium members."""
from __future__ import annotations

import logging

from pyrogram.errors import FloodWait

from ..config import Config
from ..core import SessionManager, load_phones, smart_delay
from .base import ScrapeResult
from .public import PublicScraper, _distribute_filters, _ALL_FILTERS

log = logging.getLogger(__name__)


class PremiumScraper(PublicScraper):
    """Collects only Telegram Premium members from a group.

    Overrides the member-acceptance logic of :class:`PublicScraper` so
    non-premium members are skipped entirely (never written to data.csv).
    """

    def __init__(self, settings: Config, session_mgr: SessionManager) -> None:
        super().__init__(settings, session_mgr)

    async def run(
        self,
        source: str,
        max_per_account: int = 100,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute premium-only scrape."""
        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return ScrapeResult()

        self._ensure_data_header()
        result = ScrapeResult(data_file=str(self.data_file))
        log.info("Starting PremiumScraper: %d accounts", len(phones))

        per_account_filters = _distribute_filters(_ALL_FILTERS, len(phones))

        for idx, phone in enumerate(phones):
            my_filters = per_account_filters[idx]
            log.info("Account %d/%d: %s (premium-only)", idx + 1, len(phones), phone)
            scraped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    if not await self._join_group(app, source):
                        continue

                    try:
                        chat = await app.get_chat(source)
                    except Exception as e:
                        log.error("%s: failed to resolve group: %s", phone, e)
                        continue

                    for flt in my_filters:
                        try:
                            async for member in app.get_chat_members(
                                chat_id=chat.id,
                                filter=flt if flt else None,
                            ):
                                user = member.user
                                if not getattr(user, "is_premium", False):
                                    continue  # non-premium — skip
                                self._append_member(
                                    {
                                        "user_id": user.id,
                                        "first_name": user.first_name or "",
                                        "last_name": user.last_name or "",
                                        "username": user.username or "",
                                        "is_premium": True,
                                        "phone_number": getattr(user, "phone_number", "") or "",
                                    }
                                )
                                scraped += 1
                                if scraped >= max_per_account:
                                    break
                        except FloodWait as e:
                            log.warning("%s: FloodWait %ds", phone, e.value)
                            await smart_delay(delay, "fast")
                        except Exception as e:
                            log.error("%s: filter %r failed: %s", phone, flt, e)

                        if scraped >= max_per_account:
                            break

            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.scraped += scraped
            result.per_account[phone] = scraped
            log.info("%s: +%d premium members", phone, scraped)

        log.info("PremiumScraper complete: %d scraped", result.scraped)
        return result
