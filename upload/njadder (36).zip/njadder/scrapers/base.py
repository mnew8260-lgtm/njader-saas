"""Abstract base for scrapers."""
from __future__ import annotations

import csv
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import SessionManager, load_phones, progress_bar, smart_delay

log = logging.getLogger(__name__)

DATA_HEADER = ["user_id", "first_name", "last_name", "username", "is_premium", "phone_number"]


@dataclass
class ScrapeResult:
    """Result of a scrape operation."""

    scraped: int = 0
    errors: int = 0
    data_file: str = ""
    per_account: dict[str, int] = field(default_factory=dict)


class BaseScraper(ABC):
    """Abstract base for all scrapers."""

    def __init__(
        self,
        settings: Config,
        session_mgr: SessionManager,
    ) -> None:
        self.settings = settings
        self.session_mgr = session_mgr
        self.data_file = Path("data.csv")

    @abstractmethod
    async def run(
        self,
        source: str,
        max_per_account: int = 50,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute the scraper operation."""
        ...

    async def _join_group(self, app: Client, group: str) -> bool:
        """Join a group, returning True on success or already-member."""
        try:
            await app.join_chat(group)
            return True
        except UserAlreadyParticipant:
            return True
        except Exception as e:
            log.error("Failed to join %s: %s", group, e)
            return False

    def _append_member(self, member: dict[str, Any]) -> None:
        """Append a member to data.csv."""
        try:
            with open(self.data_file, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=DATA_HEADER)
                safe = {k: member.get(k, "") for k in DATA_HEADER}
                writer.writerow(safe)
        except Exception as e:
            log.error("Failed to append to data.csv: %s", e)

    def _ensure_data_header(self) -> None:
        """Create data.csv with header if it doesn't exist."""
        if not self.data_file.exists():
            self.data_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.data_file, "w", encoding="utf-8", newline="") as f:
                csv.DictWriter(f, fieldnames=DATA_HEADER).writeheader()
