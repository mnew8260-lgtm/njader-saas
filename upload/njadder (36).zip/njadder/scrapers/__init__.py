"""Scraper modules: collect members from groups.

Public API:
    :func:`run_scraper` — dispatch a scraper by mode name.
"""
from __future__ import annotations

from .base import BaseScraper, ScrapeResult
from .combined import (
    filter_members_to_csv,
    scrape_to_contacts,
    scrape_to_contacts_and_group,
)
from .full import FullScraper
from .hidden import HiddenScraper, PrivateHiddenScraper
from .premium import PremiumScraper
from .public import PrivateScraper, PublicScraper

__all__ = [
    "BaseScraper",
    "FullScraper",
    "HiddenScraper",
    "PremiumScraper",
    "PrivateHiddenScraper",
    "PrivateScraper",
    "PublicScraper",
    "ScrapeResult",
    "filter_members_to_csv",
    "run_scraper",
    "scrape_to_contacts",
    "scrape_to_contacts_and_group",
]


async def run_scraper(
    mode: str,
    source: str,
    phones: list[str] | None = None,
    max_per_account: int = 50,
    delay: float = 1.0,
) -> ScrapeResult:
    """Run a scraper by mode name.

    Args:
        mode: One of ``'public'``, ``'private'``, ``'hidden'``,
            ``'full'``, ``'premium'``, ``'pvt_hidden'``.
            Unknown modes fall back to ``'public'``.
        source: Target group @username or invite link.
        phones: Optional list of phone numbers; loaded from
            ``phone.csv`` if ``None``.
        max_per_account: Maximum members to scrape per account.
        delay: Delay between batches.

    Returns:
        A :class:`ScrapeResult` summarizing the operation.
    """
    # Late imports to avoid a circular dependency on the Config singleton.
    from ..config import get_config
    from ..core import SessionManager

    cfg = get_config()
    session_mgr = SessionManager()

    scraper_map = {
        "public": PublicScraper,
        "private": PrivateScraper,
        "hidden": HiddenScraper,
        "full": FullScraper,
        "premium": PremiumScraper,
        "pvt_hidden": PrivateHiddenScraper,
    }
    scraper_cls = scraper_map.get(mode, PublicScraper)
    scraper = scraper_cls(cfg, session_mgr)
    return await scraper.run(source, max_per_account, delay, phones)
