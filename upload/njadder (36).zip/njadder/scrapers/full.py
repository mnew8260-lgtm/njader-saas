"""Full scraper: A-Z distribution across multiple accounts."""
from __future__ import annotations

import logging
from pathlib import Path

from .public import PublicScraper
from .base import ScrapeResult

log = logging.getLogger(__name__)


class FullScraper(PublicScraper):
    """Full scraper distributes A-Z filters across all accounts.

    Each account handles a different letter range for maximum coverage.
    """

    def __init__(self, settings, session_mgr) -> None:
        super().__init__(settings, session_mgr)

    async def run(
        self,
        source: str,
        max_per_account: int = 1000,
        delay: float = 1.0,
        phones: list[str] | None = None,
    ) -> ScrapeResult:
        """Execute full scrape with A-Z distribution."""
        log.info("FullScraper: A-Z distribution across accounts")
        return await super().run(source, max_per_account, delay, phones)
