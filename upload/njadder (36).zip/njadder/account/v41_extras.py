"""v41 functions ported from unified_tool.py.

This module contains the truly unique functions from the legacy
codebase that don't fit neatly into the existing modular structure.

All functions are async and use the njadder SessionManager.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from pyrogram.errors import (
    FloodWait, PeerFlood, UserPrivacyRestricted,
    UserChannelsTooMuch, UserBannedInChannel, RPCError,
)

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


# ===========================================================================
# Views Increaser — increment post view count
# ===========================================================================

async def views_increaser(
    session_mgr: SessionManager,
    target_chat: str,
    message_ids: list[int],
    delay: float = 2.0,
) -> int:
    """Increment the view count on specific posts.

    Uses ``functions.messages.GetMessagesViews`` with ``increment=True``
    to boost view counts. Each account calls this once per post.

    Args:
        session_mgr: Shared session manager.
        target_chat: Channel/group @username.
        message_ids: List of post IDs to increment views on.
        delay: Delay between accounts.

    Returns:
        Number of accounts that successfully incremented views.
    """
    from pyrogram.raw import functions

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    incremented = 0
    for phone in phones:
        log.info("%s: incrementing views on %s (msgs=%s)", phone, target_chat, message_ids)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    peer = await app.resolve_peer(target_chat)
                    await app.invoke(
                        functions.messages.GetMessagesViews(
                            peer=peer,
                            id=message_ids,
                            increment=True,
                        )
                    )
                    incremented += 1
                    log.info("%s: views incremented ✓", phone)
                except Exception as e:
                    log.error("%s: GetMessagesViews failed: %s", phone, e)
            await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("views_increaser complete: %d/%d", incremented, len(phones))
    return incremented


# ===========================================================================
# Contact Deleter — delete all contacts from each account
# ===========================================================================

async def contact_deleter(
    session_mgr: SessionManager,
    delay: float = 1.0,
    max_per_account: int = 0,
) -> dict[str, int]:
    """Delete all contacts from each account.

    Useful for cleaning up after bulk operations that added temporary
    contacts.

    Args:
        session_mgr: Shared session manager.
        delay: Delay between deletions.
        max_per_account: Max contacts to delete per account (0 = all).

    Returns:
        dict mapping phone → number of contacts deleted.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return {}

    result: dict[str, int] = {}
    for phone in phones:
        log.info("%s: deleting contacts", phone)
        deleted = 0
        flood = peer = banned = 0
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    contacts = await app.get_contacts()
                except Exception as e:
                    log.error("%s: get_contacts failed: %s", phone, e)
                    continue

                for contact in contacts:
                    if max_per_account and deleted >= max_per_account:
                        break
                    if flood >= 5 or peer >= 5 or banned >= 5:
                        log.warning("%s: too many errors — stopping", phone)
                        break
                    try:
                        await app.delete_contacts([contact.id])
                        deleted += 1
                        log.info("%s: deleted %d (%s)", phone, deleted, contact.first_name or "?")
                        await smart_delay(delay, "micro")
                    except UserPrivacyRestricted:
                        pass
                    except PeerFlood:
                        peer += 1
                        log.error("%s: PeerFlood", phone)
                        break
                    except FloodWait as e:
                        flood += 1
                        log.warning("%s: FloodWait %ds", phone, e.value)
                        await asyncio.sleep(min(e.value, 30))
                    except UserBannedInChannel:
                        banned += 1
                    except (UserChannelsTooMuch, RPCError):
                        pass
                    except Exception as e:
                        log.debug("%s: delete failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

        result[phone] = deleted
        log.info("%s: %d contacts deleted", phone, deleted)

    total = sum(result.values())
    log.info("contact_deleter complete: %d total across %d accounts", total, len(phones))
    return result


# ===========================================================================
# Privacy Settings — hide last seen / phone number
# ===========================================================================

async def hide_last_seen(session_mgr: SessionManager) -> int:
    """Hide "last seen" timestamp for all accounts.

    Uses ``functions.account.SetPrivacy`` with
    ``InputPrivacyKeyStatusTimestamp`` and ``DisallowAll`` rule.
    """
    from pyrogram.raw import functions, types

    return await _set_privacy(
        session_mgr,
        key=types.InputPrivacyKeyStatusTimestamp(),
        rules=[types.InputPrivacyValueDisallowAll()],
        label="last_seen",
    )


async def hide_phone_number(session_mgr: SessionManager) -> int:
    """Hide phone number from non-contacts for all accounts.

    Sets:
    - ``InputPrivacyKeyPhoneNumber`` → DisallowAll
    - ``InputPrivacyKeyAddedByPhone`` → AllowContacts
    """
    from pyrogram.raw import functions, types

    count = await _set_privacy(
        session_mgr,
        key=types.InputPrivacyKeyPhoneNumber(),
        rules=[types.InputPrivacyValueDisallowAll()],
        label="phone_number",
    )
    count += await _set_privacy(
        session_mgr,
        key=types.InputPrivacyKeyAddedByPhone(),
        rules=[types.InputPrivacyValueAllowContacts()],
        label="added_by_phone",
    )
    return count


async def _set_privacy(
    session_mgr: SessionManager,
    key: Any,
    rules: list,
    label: str = "",
) -> int:
    """Internal helper: set a privacy key for all accounts."""
    from pyrogram.raw import functions

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    changed = 0
    for phone in phones:
        log.info("%s: setting privacy %s", phone, label)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.invoke(
                        functions.account.SetPrivacy(key=key, rules=rules)
                    )
                    changed += 1
                    log.info("%s: %s hidden ✓", phone, label)
                except Exception as e:
                    log.error("%s: SetPrivacy failed: %s", phone, e)
            await smart_delay(1.0, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("privacy %s: %d/%d done", label, changed, len(phones))
    return changed


# ===========================================================================
# Mass DM — send DM to all users in data.csv (with dedup tracking)
# ===========================================================================

async def mass_dm(
    session_mgr: SessionManager,
    message: str,
    max_per_account: int = 50,
    delay: float = 5.0,
    data_csv: str = "data.csv",
) -> int:
    """Send DM to all usernames in data.csv with cross-account dedup.

    Similar to :func:`send_dm_from_data_csv` but with per-account
    error thresholds (flood=5, peer=5) and done.csv tracking.

    Args:
        session_mgr: Shared session manager.
        message: The message to send.
        max_per_account: Max DMs per account.
        delay: Delay between DMs.
        data_csv: Path to data.csv.

    Returns:
        Total DMs sent.
    """
    import csv as _csv
    from pathlib import Path as _P

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Read usernames from data.csv
    data_path = _P(data_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0

    usernames: list[str] = []
    with open(data_path, "r", encoding="utf-8") as f:
        for row in _csv.DictReader(f):
            uname = (row.get("username") or "").strip().lstrip("@")
            if uname:
                usernames.append(uname)

    if not usernames:
        log.error("No usernames in %s", data_csv)
        return 0

    log.info("Loaded %d usernames from %s", len(usernames), data_csv)

    sent_total = 0
    dmed: set[str] = set()  # Cross-account dedup
    idx = 0

    for phone in phones:
        if idx >= len(usernames):
            break
        log.info("%s: mass DM (%d/%d sent)", phone, sent_total, len(usernames))
        sent = 0
        flood = peer = 0
        try:
            async with session_mgr.acquire(phone) as app:
                while idx < len(usernames) and sent < max_per_account:
                    if flood >= 5 or peer >= 5:
                        log.warning("%s: too many errors — stopping", phone)
                        break

                    uname = usernames[idx]
                    if uname in dmed:
                        idx += 1
                        continue
                    try:
                        await app.send_message(uname, message)
                        dmed.add(uname)
                        sent += 1
                        sent_total += 1
                        idx += 1
                        log.info("%s: DM → @%s (%d/%d)", phone, uname, sent_total, len(usernames))
                        await smart_delay(delay, "send_message")
                    except FloodWait as e:
                        flood += 1
                        log.warning("%s: FloodWait %ds", phone, e.value)
                        await asyncio.sleep(min(e.value, 60))
                    except PeerFlood:
                        peer += 1
                        log.error("%s: PeerFlood — stopping", phone)
                        break
                    except Exception as e:
                        log.debug("%s: DM to @%s failed: %s", phone, uname, e)
                        idx += 1  # Skip and continue
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("mass_dm complete: %d/%d sent", sent_total, len(usernames))
    return sent_total


# ===========================================================================
# Scrape group → add as contacts via phone numbers (addtocontactbygroup)
# ===========================================================================

async def add_to_contact_by_group(
    session_mgr: SessionManager,
    source_group: str,
    max_per_account: int = 50,
    delay: float = 2.0,
) -> int:
    """Scrape a group and add members as contacts via phone numbers.

    Uses ``functions.contacts.ResolvePhone`` to check if a phone
    number is registered on Telegram, then adds them as contacts.

    Reads phone numbers from ``numbers.csv`` (one per line).
    """
    import csv as _csv
    from pathlib import Path as _P
    from pyrogram.raw import functions

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Read phone numbers from numbers.csv
    numbers_path = _P("numbers.csv")
    if not numbers_path.exists():
        log.error("numbers.csv not found")
        return 0

    numbers: list[str] = []
    with open(numbers_path, "r", encoding="utf-8") as f:
        rows = list(_csv.reader(f))
        # Skip header if non-numeric
        if rows and rows[0] and rows[0][0].strip():
            try:
                int(rows[0][0].replace("+", "").replace("-", "").replace(" ", ""))
            except ValueError:
                rows = rows[1:]
        for row in rows:
            if row and row[0].strip():
                numbers.append(row[0].strip())

    if not numbers:
        log.error("No numbers in numbers.csv")
        return 0

    log.info("Loaded %d numbers from numbers.csv", len(numbers))

    resolved: set[str] = set()
    added_total = 0

    for phone in phones:
        log.info("%s: resolving phone numbers", phone)
        added = 0
        try:
            async with session_mgr.acquire(phone) as app:
                for num in numbers:
                    if num in resolved:
                        continue
                    if added >= max_per_account:
                        break
                    try:
                        # Check if number is registered
                        result = await app.invoke(
                            functions.contacts.ResolvePhone(phone=num)
                        )
                        if result and result.users:
                            uid = result.users[0].id
                            resolved.add(num)
                            # Add as contact
                            try:
                                await app.add_contact(int(uid), "Contact", last_name="")
                                added += 1
                                log.info("%s: +resolved %s (uid=%d)", phone, num, uid)
                                await smart_delay(delay, "add_member")
                            except Exception as e:
                                log.debug("%s: add_contact failed: %s", phone, e)
                    except Exception as e:
                        kind = type(e).__name__
                        if "PhoneNumberBanned" in kind:
                            log.warning("%s: %s is banned", phone, num)
                        elif "PhoneNumberUnoccupied" in kind:
                            log.debug("%s: %s not registered", phone, num)
                        elif "FloodWait" in kind:
                            log.warning("%s: FloodWait", phone)
                            break
                        else:
                            log.debug("%s: resolve %s failed: %s", phone, num, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

        added_total += added
        log.info("%s: +%d contacts", phone, added)

    log.info("add_to_contact_by_group complete: %d added", added_total)
    return added_total


# ===========================================================================
# Import contacts from file → add to group (addtocontactbyimp)
# ===========================================================================

async def add_to_contact_by_imp(
    session_mgr: SessionManager,
    target_group: str,
    vcf_path: str,
    max_per_account: int = 50,
    delay: float = 2.0,
) -> int:
    """Import contacts from VCF file, then add them to a target group.

    Combines :func:`import_vcf_as_contacts` with group addition.
    """
    from ..utilities.csv_tools import import_vcf_as_contacts

    # Step 1: Import VCF as contacts
    imported = await import_vcf_as_contacts(
        session_mgr, vcf_path, max_per_account, delay
    )
    log.info("Imported %d contacts from VCF", imported)

    # Step 2: Add contacts to target group
    phones = load_phones()
    if not phones:
        return imported

    from pyrogram.errors import UserAlreadyParticipant

    added_total = 0
    for phone in phones:
        log.info("%s: adding contacts to %s", phone, target_group)
        added = 0
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    tgt = await app.get_chat(target_group)
                except Exception as e:
                    log.error("%s: resolve target failed: %s", phone, e)
                    continue

                # Get contacts
                try:
                    contacts = await app.get_contacts()
                except Exception as e:
                    log.error("%s: get_contacts failed: %s", phone, e)
                    continue

                for contact in contacts:
                    if added >= max_per_account:
                        break
                    try:
                        await app.add_chat_members(tgt.id, contact.id)
                        added += 1
                        log.info("%s: +%s added", phone, contact.first_name or "?")
                        await smart_delay(delay, "add_member")
                    except Exception as e:
                        kind = type(e).__name__
                        if "PeerFlood" in kind:
                            log.error("%s: PeerFlood — stopping", phone)
                            break
                        log.debug("%s: add failed: %s", phone, e)

                # Clean up: delete the imported contacts
                try:
                    await app.delete_contacts([c.id for c in contacts])
                except Exception:
                    pass
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

        added_total += added
        log.info("%s: +%d to group", phone, added)

    log.info("add_to_contact_by_imp complete: %d added to group", added_total)
    return added_total
