"""Account profile tools: change name, set profile pic, etc."""
from __future__ import annotations

import asyncio
import logging
import random
import string
from pathlib import Path

from pyrogram import Client

from ..config import Config, get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


async def changer_account(session_mgr: SessionManager) -> int:
    """Change first name, last name, and bio for all accounts."""
    phones = load_phones()
    if not phones:
        return 0

    first_name = input("Enter first name: ").strip()
    last_name = input("Enter last name (or empty): ").strip()
    bio = input("Enter bio (or empty): ").strip()

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                from pyrogram.raw import functions

                await app.invoke(
                    functions.account.UpdateProfile(
                        first_name=first_name,
                        last_name=last_name or "",
                        about=bio or "",
                    )
                )
                changed += 1
                log.info("%s: profile changed", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return changed


async def set_username(session_mgr: SessionManager, username: str) -> int:
    """Set the same username on all accounts.

    Note: Telegram usernames are globally unique — only the first
    account will succeed; subsequent accounts will get a
    ``UsernameOccupied`` error. For per-account unique usernames
    use :func:`set_usernames_from_csv`.

    Performs pre-validation and gives actionable error messages for
    common Telegram rejections:
    - ``USERNAME_PURCHASE_AVAILABLE`` → reserved for Telegram Premium.
    - ``USERNAME_OCCUPIED``            → taken by another user.
    - ``USERNAME_INVALID``            → bad format (5-32 chars, a-zA-Z0-9_).
    - ``USERNAME_NOT_MODIFIED``       → already set to that value.
    """
    username = (username or "").strip().lstrip("@")
    if not username:
        log.error("Empty username — nothing to set")
        return 0

    # Pre-validate format (cheap, no API call).
    issues = _validate_username_format(username)
    if issues:
        log.error("Username @%s fails validation: %s", username, "; ".join(issues))
        log.error(
            "Tips: use 5-32 chars, start with a letter, "
            "alphanumeric + underscores only. Avoid short/dictionary words."
        )
        return 0

    phones = load_phones()
    if not phones:
        return 0

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                await app.set_username(username)
                changed += 1
                log.info("%s: username set to @%s", phone, username)
                await smart_delay(2.0, "fast")
        except Exception as e:
            reason = _classify_username_error(e)
            log.error("%s: failed — %s", phone, reason)
            # Stop early if the username is unusable globally.
            if reason.startswith(("PURCHASE_AVAILABLE", "OCCUPIED")):
                log.error(
                    "Stopping — username @%s cannot be used on ANY account: %s",
                    username, reason,
                )
                break

    if changed == 0:
        log.error(
            "FAILED on all accounts. Username @%s is not usable. "
            "Try: (1) a longer username (8+ chars), "
            "(2) add digits/underscores, (3) use set_usernames_from_csv.",
            username,
        )
    else:
        log.info("set_username complete: %d/%d accounts now @%s", changed, len(phones), username)
    return changed


def _validate_username_format(username: str) -> list[str]:
    """Return a list of validation issues for ``username`` (empty if OK).

    Telegram rules:
    - 5-32 chars
    - alphanumeric + underscores
    - must start with a letter
    - cannot end with underscore
    - cannot have consecutive underscores
    """
    issues: list[str] = []
    if len(username) < 5:
        issues.append(f"too short ({len(username)} < 5)")
    if len(username) > 32:
        issues.append(f"too long ({len(username)} > 32)")
    if username and not username[0].isalpha():
        issues.append("must start with a letter")
    if username and username.endswith("_"):
        issues.append("cannot end with underscore")
    if "__" in username:
        issues.append("cannot have consecutive underscores")
    allowed = set(string.ascii_lowercase + string.ascii_uppercase + string.digits + "_")
    bad_chars = [c for c in username if c not in allowed]
    if bad_chars:
        issues.append(f"invalid chars: {''.join(bad_chars)}")
    return issues


def _classify_username_error(e: Exception) -> str:
    """Map a Pyrogram exception to a short, actionable reason string.

    Telegram returns several username-specific errors that pyrogram
    does not all wrap in named exception classes — we detect them
    via the message text.
    """
    msg = str(e).upper()
    # Check for the literal RPC error name in the message.
    if "USERNAME_PURCHASE_AVAILABLE" in msg:
        return ("PURCHASE_AVAILABLE — username reserved for Telegram Premium "
                "users. Use a longer/different name (e.g., add 3+ digits).")
    if "USERNAME_OCCUPIED" in msg:
        return "OCCUPIED — username is already taken by another user."
    if "USERNAME_INVALID" in msg:
        return "INVALID — bad format (5-32 chars, starts with letter, a-zA-Z0-9_)."
    if "USERNAME_NOT_MODIFIED" in msg:
        return "NOT_MODIFIED — same as current username (skip)."
    if "USERNAME_NOT_OCCUPIED" in msg:
        return "NOT_OCCUPIED — username not assigned to anyone (unexpected)."
    if "USERNAME_PURCHASE_AVAILABLE" in msg:
        return "PURCHASE_AVAILABLE"
    # Fall back to the exception type name.
    return type(e).__name__


async def set_usernames_from_csv(
    session_mgr: SessionManager,
    phone_csv: str = "phone.csv",
    username_csv: str = "username.csv",
) -> int:
    """Set per-account usernames from a CSV file.

    ``phone.csv`` and ``username.csv`` must have the same number of
    rows; row ``i`` of ``phone.csv`` is paired with row ``i`` of
    ``username.csv``. Each row gets its own unique username.

    Skips rows with invalid format and reports the per-row reason
    if Telegram rejects the username.
    """
    phone_path = Path(phone_csv)
    uname_path = Path(username_csv)
    if not phone_path.exists() or not uname_path.exists():
        log.error("Both %s and %s must exist", phone_csv, username_csv)
        return 0

    phones = _read_first_column(phone_path)
    usernames = _read_first_column(uname_path)
    if len(phones) != len(usernames):
        log.error(
            "Row count mismatch: %s has %d, %s has %d",
            phone_csv, len(phones), username_csv, len(usernames),
        )
        return 0

    changed = 0
    for phone, username in zip(phones, usernames):
        username = (username or "").strip().lstrip("@")
        if not username:
            log.warning("%s: empty username in CSV — skipped", phone)
            continue

        # Pre-validate format.
        issues = _validate_username_format(username)
        if issues:
            log.error(
                "%s: @%s fails validation — %s",
                phone, username, "; ".join(issues),
            )
            continue

        try:
            async with session_mgr.acquire(phone) as app:
                await app.set_username(username)
                changed += 1
                log.info("%s: username set to @%s", phone, username)
                await smart_delay(2.0, "fast")
        except Exception as e:
            reason = _classify_username_error(e)
            log.error("%s: @%s failed — %s", phone, username, reason)

    log.info(
        "set_usernames_from_csv complete: %d/%d succeeded",
        changed, len(phones),
    )
    return changed


async def set_profile_pic(session_mgr: SessionManager, photo_path: str) -> int:
    """Set profile picture for all accounts."""
    phones = load_phones()
    if not phones:
        return 0

    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                from pyrogram.raw.functions.photos import UploadProfilePhotoRequest

                file = await app.upload_file(photo_path)
                await app.invoke(UploadProfilePhotoRequest(file=file))
                changed += 1
                log.info("%s: profile pic set", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return changed


async def remove_profile_pic(session_mgr: SessionManager) -> int:
    """Remove all profile pictures from each account."""
    phones = load_phones()
    if not phones:
        return 0

    removed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                # Collect chat photos (sync iterator — wrap in list).
                photos = []
                async for photo in app.get_chat_photos("me"):
                    photos.append(photo)
                if photos:
                    file_ids = [p.file_id for p in photos]
                    await app.delete_profile_photos(file_ids)
                    removed += 1
                    log.info("%s: removed %d profile photo(s)", phone, len(photos))
                else:
                    log.info("%s: no profile photos to remove", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return removed


def random_username(length: int = 10, prefix: str = "") -> str:
    """Generate a random valid Telegram username.

    Telegram usernames:
    - Must be 5-32 characters.
    - Alphanumeric + underscores.
    - Must start with a letter.

    Default length is 10 (not 5) because short usernames are often
    reserved for Telegram Premium and trigger
    ``USERNAME_PURCHASE_AVAILABLE`` errors. 10+ chars rarely have
    that problem.
    """
    if length < 5:
        length = 5
    if length > 32:
        length = 32
    # First char must be a letter.
    first = random.choice(string.ascii_lowercase)
    rest = "".join(
        random.choice(string.ascii_lowercase + string.digits + "_")
        for _ in range(length - 1)
    )
    return f"{prefix}{first}{rest}"


def generate_usernames_file(
    n: int,
    out_path: str = "username.csv",
    length: int = 10,
) -> int:
    """Generate ``n`` random usernames and write them to ``out_path``.

    Useful for preparing ``username.csv`` before calling
    :func:`set_usernames_from_csv`.
    """
    out = Path(out_path)
    seen: set[str] = set()
    usernames: list[str] = []
    while len(usernames) < n:
        u = random_username(length=length)
        if u in seen:
            continue
        seen.add(u)
        usernames.append(u)
    with open(out, "w", encoding="utf-8", newline="") as f:
        import csv as _csv

        w = _csv.writer(f)
        for u in usernames:
            w.writerow([u])
    log.info("Generated %d usernames → %s", len(usernames), out_path)
    return len(usernames)


async def account_info_getter() -> None:
    """Get account info for all accounts."""
    cfg = get_config()
    session_mgr = SessionManager()
    phones = load_phones()
    if not phones:
        return

    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                print(f"\n{phone}:")
                print(f"  Name: {me.first_name or ''} {me.last_name or ''}")
                print(f"  Username: @{me.username}" if me.username else "  Username: -")
                print(f"  ID: {me.id}")
                print(f"  Phone: +{me.phone_number}" if getattr(me, "phone_number", None) else "  Phone: -")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_first_column(path: Path) -> list[str]:
    """Read the first column of a CSV into a list of strings."""
    result: list[str] = []
    import csv as _csv

    with open(path, "r", encoding="utf-8") as f:
        for row in _csv.reader(f):
            if row and row[0].strip():
                result.append(row[0].strip())
    return result


# ===========================================================================
# v41: Auto ID Cloner — clone profile from another user
# ===========================================================================

async def auto_id_cloner(
    session_mgr: SessionManager,
    phone_csv: str = "phone.csv",
    clones_csv: str = "clone.csv",
    delay: float = 2.0,
) -> int:
    """Clone profile (name + bio) from target users.

    Reads ``clone.csv`` with columns ``phone,clone_target`` where
    ``clone_target`` is a user ID or @username. For each row, the
    account's first_name, last_name, and bio are set to match the
    target user's profile.

    Args:
        session_mgr: Shared session manager.
        phone_csv: Path to phone.csv (for phone validation).
        clones_csv: Path to clone.csv (phone,clone_target pairs).
        delay: Delay between accounts.

    Returns:
        Number of accounts successfully cloned.
    """
    import csv as _csv

    clone_path = Path(clones_csv)
    if not clone_path.exists():
        log.error("%s not found — create it with columns: phone,clone_target", clones_csv)
        return 0

    # Read clone pairs
    clones: list[tuple[str, str]] = []
    try:
        with open(clone_path, "r", encoding="utf-8") as f:
            for row in _csv.reader(f):
                if len(row) >= 2 and row[0].strip() and row[1].strip():
                    clones.append((row[0].strip(), row[1].strip()))
    except Exception as e:
        log.error("Failed to read %s: %s", clones_csv, e)
        return 0

    if not clones:
        log.error("No clone pairs in %s", clones_csv)
        return 0

    log.info("Cloning %d accounts...", len(clones))
    cloned = 0

    for phone, target in clones:
        log.info("Cloning %s → %s", phone, target)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    # Get target user's profile
                    user = await app.get_users(target)
                    chat = await app.get_chat(target)
                    bio = getattr(chat, "bio", "") or ""

                    # Update our profile to match
                    await app.update_profile(
                        first_name=user.first_name or "",
                        last_name=user.last_name or "",
                        bio=bio,
                    )
                    cloned += 1
                    log.info("%s: cloned ✓ (name=%s %s, bio=%d chars)",
                             phone, user.first_name or "", user.last_name or "", len(bio))
                except Exception as e:
                    log.error("%s: clone failed: %s", phone, e)
            await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("auto_id_cloner complete: %d/%d cloned", cloned, len(clones))
    return cloned


# ===========================================================================
# v41: Anonymous Chatter — conversation flow with /next switching
# ===========================================================================

# Default conversation flow (mimics a real person chatting on an
# anonymous chat platform like @chatbot).
_DEFAULT_CONVERSATION = [
    ("Hii", 3),
    ("How are you ?", 4),
    ("I am Girl & You?", 5),
    ("Can you help me", 6),
    ("Please", 3),
]


async def anonymous_chatter_flow(
    session_mgr: SessionManager,
    target_chat: str = "@chatbot",
    custom_message: str = "",
    num_runs: int = 5,
    delay_between_msgs: float = 3.0,
    phones: list[str] | None = None,
) -> int:
    """Run an anonymous conversation flow on @chatbot (or similar).

    For each account, sends ``/next`` to switch chat partner, then
    runs through a 5-message conversation flow + custom message.
    Repeats ``num_runs`` times per account.

    Conversation flow:
    1. ``/next`` (switch partner)
    2. ``Hii``
    3. ``How are you ?``
    4. ``I am Girl & You?``
    5. ``Can you help me``
    6. ``Please``
    7. ``custom_message``

    Args:
        session_mgr: Shared session manager.
        target_chat: The anonymous chat bot @username (default @chatbot).
        custom_message: A custom message to send at the end of each run.
        num_runs: How many conversation runs per account.
        delay_between_msgs: Base delay between messages (seconds).

    Returns:
        Total number of completed runs across all accounts.
    """
    if phones is None:
        phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    total_runs = 0

    for phone in phones:
        log.info("%s: anonymous chatter (%d runs)", phone, num_runs)
        try:
            async with session_mgr.acquire(phone) as app:
                run_count = 0
                while run_count < num_runs:
                    try:
                        # /next to switch chat partner
                        await app.send_message(target_chat, "/next")
                        await asyncio.sleep(delay_between_msgs)

                        # Run through conversation flow
                        for msg_text, wait_secs in _DEFAULT_CONVERSATION:
                            await app.send_message(target_chat, msg_text)
                            await asyncio.sleep(wait_secs)

                        # Send custom message
                        if custom_message:
                            await app.send_message(target_chat, custom_message)
                            await asyncio.sleep(2)

                        run_count += 1
                        total_runs += 1
                        log.info("%s: run %d/%d done", phone, run_count, num_runs)
                    except Exception as e:
                        log.error("%s: run failed: %s", phone, e)
                        break
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("anonymous_chatter_flow complete: %d runs across %d accounts",
             total_runs, len(phones))
    return total_runs


# ===========================================================================
# v41: Reaction Increaser — send reactions to a post from all accounts
# ===========================================================================

async def reaction_increaser(
    session_mgr: SessionManager,
    target_chat: str,
    message_id: int,
    reaction: str = "👍",
    delay: float = 2.0,
) -> int:
    """Send a reaction to a specific post from every account.

    Useful for boosting the reaction count on a channel post.

    Args:
        session_mgr: Shared session manager.
        target_chat: Group/channel @username or link.
        message_id: The post/message ID to react to.
        reaction: Emoji string (default ``"👍"``).
        delay: Delay between accounts.

    Returns:
        Number of accounts that successfully reacted.
    """
    from pyrogram.errors import UserAlreadyParticipant

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    sent = 0
    for phone in phones:
        log.info("%s: sending reaction %s to %s/%d", phone, reaction, target_chat, message_id)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_chat)
                except UserAlreadyParticipant:
                    pass
                try:
                    await app.send_reaction(target_chat, message_id, reaction)
                    sent += 1
                    log.info("%s: reaction sent ✓", phone)
                except Exception as e:
                    log.error("%s: send_reaction failed: %s", phone, e)
            await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("reaction_increaser complete: %d/%d reacted", sent, len(phones))
    return sent


# ===========================================================================
# v41: Shares Increaser — forward a post to "me" from all accounts
# ===========================================================================

async def shares_increaser(
    session_mgr: SessionManager,
    target_chat: str,
    message_id: int,
    delay: float = 2.0,
) -> int:
    """Forward a post to the account's own "Saved Messages" to boost share count.

    Each account forwards the specified message to ``"me"`` (Saved Messages),
    which counts as a "share" on the original post.

    Args:
        session_mgr: Shared session manager.
        target_chat: Group/channel @username or link.
        message_id: The post ID to forward.
        delay: Delay between accounts.

    Returns:
        Number of accounts that successfully forwarded.
    """
    from pyrogram.errors import UserAlreadyParticipant

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    forwarded = 0
    for phone in phones:
        log.info("%s: forwarding %s/%d → Saved Messages", phone, target_chat, message_id)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_chat)
                except UserAlreadyParticipant:
                    pass
                try:
                    chat = await app.get_chat(target_chat)
                    await app.forward_messages(
                        chat_id="me",
                        from_chat_id=chat.id,
                        message_ids=message_id,
                    )
                    forwarded += 1
                    log.info("%s: forwarded ✓", phone)
                except Exception as e:
                    log.error("%s: forward failed: %s", phone, e)
            await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("shares_increaser complete: %d/%d forwarded", forwarded, len(phones))
    return forwarded


# ===========================================================================
# v41: Nearby Adder by Lat/Long — geolocation-based nearby member adder
# ===========================================================================

async def nearby_adder_latlong(
    session_mgr: SessionManager,
    target_group: str,
    latitude: float,
    longitude: float,
    max_per_account: int = 50,
    delay: float = 2.0,
    phones: list[str] | None = None,
) -> int:
    """Add nearby users found via Telegram's GetLocated API.

    Uses ``functions.contacts.GetLocated`` with a specific lat/long
    to find users near that geographic point, then adds them to
    ``target_group``.

    Args:
        session_mgr: Shared session manager.
        target_group: Target group @username or link.
        latitude: Geographic latitude.
        longitude: Geographic longitude.
        max_per_account: Max members to add per account.
        delay: Delay between adds.

    Returns:
        Total members added.
    """
    from pyrogram.raw import functions, types
    from pyrogram.errors import UserAlreadyParticipant

    if phones is None:
        phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Get existing members of the target group (using first account).
    existing: set[int] = set()
    try:
        async with session_mgr.acquire(phones[0]) as app:
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            chat = await app.get_chat(target_group)
            async for m in app.get_chat_members(chat_id=chat.id):
                if hasattr(m, "user") and hasattr(m.user, "id"):
                    existing.add(m.user.id)
            target_id = chat.id
    except Exception as e:
        log.error("Failed to get existing members: %s", e)
        return 0

    added_total = 0
    for phone in phones:
        log.info("%s: nearby adder (lat=%s, long=%s)", phone, latitude, longitude)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    tgt = await app.get_chat(target_group)
                except Exception as e:
                    log.error("%s: resolve target failed: %s", phone, e)
                    continue

                # Get nearby users via raw API.
                try:
                    result = await app.invoke(
                        functions.contacts.GetLocated(
                            geo_point=types.InputGeoPoint(
                                lat=float(latitude),
                                long=float(longitude),
                            )
                        )
                    )
                except Exception as e:
                    log.error("%s: GetLocated failed: %s", phone, e)
                    continue

                added = 0
                for user in getattr(result, "users", []):
                    uid = getattr(user, "id", 0)
                    if not uid or uid in existing:
                        continue
                    if added >= max_per_account:
                        break
                    try:
                        await app.add_chat_members(tgt.id, int(uid))
                        added += 1
                        existing.add(uid)
                        log.info("%s: +%d added (uid=%d)", phone, added, uid)
                        await smart_delay(delay, "add_member")
                    except Exception as e:
                        kind = type(e).__name__
                        if "PeerFlood" in kind:
                            log.error("%s: PeerFlood — stopping", phone)
                            break
                        log.debug("%s: add %d failed: %s", phone, uid, e)

                added_total += added
                log.info("%s: +%d nearby members", phone, added)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("nearby_adder_latlong complete: %d added", added_total)
    return added_total


# ===========================================================================
# v41: Nearby Adder by City — geocode city name → lat/long → GetLocated
# ===========================================================================

async def nearby_adder_city(
    session_mgr: SessionManager,
    target_group: str,
    city_name: str,
    max_per_account: int = 50,
    delay: float = 2.0,
    phones: list[str] | None = None,
) -> int:
    """Add nearby users by city name (geocoded to lat/long).

    Uses ``geopy.Nominatim`` to convert a city name to geographic
    coordinates, then calls :func:`nearby_adder_latlong`.

    Args:
        session_mgr: Shared session manager.
        target_group: Target group @username or link.
        city_name: City name (e.g., "Riyadh", "Dubai", "Cairo").
        max_per_account: Max members per account.
        delay: Delay between adds.
        phones: Phone list override.

    Returns:
        Total members added.
    """
    try:
        from geopy.geocoders import Nominatim
    except ImportError:
        log.error("geopy not installed — run: pip install geopy")
        return 0

    geolocator = Nominatim(user_agent="njadder")
    location = geolocator.geocode(city_name)
    if not location:
        log.error("Could not geocode city: %s", city_name)
        return 0

    log.info("Geocoded %s → lat=%s, long=%s", city_name, location.latitude, location.longitude)
    return await nearby_adder_latlong(
        session_mgr, target_group, location.latitude, location.longitude,
        max_per_account, delay, phones,
    )


# ===========================================================================
# v41: Permanent Limit Remover — aggressive SpamBot complaint
# ===========================================================================

async def permanent_limit_remover(
    session_mgr: SessionManager,
    complaint_url: str = "https://pastebin.com/raw/YKbeUazQ",
    delay: float = 2.0,
) -> int:
    """Aggressively submit SpamBot complaints to remove account limits.

    Downloads a complaint template from a URL, then for each account:
    1. Sends /start to @SpamBot
    2. Sends "Submit a complaint"
    3. Sends "No, I'll never do any of this!"
    4. Sends the complaint template text

    This is more aggressive than :func:`recover_restricted` because it
    doesn't check the account's status first — it just sends the
    complaint to every account.

    Args:
        session_mgr: Shared session manager.
        complaint_url: URL to fetch the complaint template from.
        delay: Delay between accounts.

    Returns:
        Number of accounts that received the complaint.
    """
    import urllib.request

    # Fetch complaint template
    try:
        with urllib.request.urlopen(complaint_url, timeout=10) as resp:
            complaint_text = resp.read().decode("utf-8").strip()
        if not complaint_text:
            log.error("Empty complaint template from %s", complaint_url)
            return 0
        log.info("Loaded complaint template (%d chars)", len(complaint_text))
    except Exception as e:
        log.error("Failed to fetch complaint template: %s", e)
        return 0

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    submitted = 0
    for phone in phones:
        log.info("%s: permanent limit remover", phone)
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.send_message("SpamBot", "/start")
                    await asyncio.sleep(0.5)
                    await app.send_message("SpamBot", "Submit a complaint")
                    await asyncio.sleep(0.5)
                    await app.send_message("SpamBot", "No, I'll never do any of this!")
                    await asyncio.sleep(0.5)
                    await app.send_message("SpamBot", complaint_text)
                    submitted += 1
                    log.info("%s: complaint submitted ✓", phone)
                except Exception as e:
                    log.error("%s: SpamBot interaction failed: %s", phone, e)
            await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("permanent_limit_remover complete: %d/%d submitted", submitted, len(phones))
    return submitted
