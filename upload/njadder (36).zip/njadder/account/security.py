"""Account security tools: login, OTP viewer, 2FA setup."""
from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING

from pyrogram.errors import UserAlreadyParticipant

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

if TYPE_CHECKING:
    from pyrogram import Client

log = logging.getLogger(__name__)

# Telegram's official OTP sender chat id (the "Telegram" service account).
OTP_SENDER_ID = 777000


async def login_all(session_mgr: SessionManager) -> int:
    """Login all accounts from phone.csv and join support channels.

    The support groups come from ``config.ini`` (``support_group`` key) plus
    a small built-in fallback list. A random 20-40 s human-like delay is
    inserted between consecutive joins to reduce ban-risk.

    Returns:
        Number of accounts successfully authenticated.
    """
    cfg = get_config()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Build support-group list: explicit config + default fallbacks.
    support_groups: list[str] = []
    configured = cfg.support_group
    if configured:
        support_groups.append(configured)
    for grp in ("@NMDDER_ch", "@NMDDER_SUPPORT"):
        if grp not in support_groups:
            support_groups.append(grp)

    log.info("Starting login for %d accounts", len(phones))
    logged_in = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] Login %s", idx, len(phones), phone)
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                log.info("%s: logged in as %s", phone, me.first_name or "?")

                for grp in support_groups:
                    if not grp:
                        continue
                    try:
                        await app.join_chat(grp)
                        log.debug("%s: joined %s", phone, grp)
                        # Human-like delay between joins.
                        delay = random.randint(20, 40)
                        await asyncio.sleep(delay)
                    except UserAlreadyParticipant:
                        pass
                    except Exception as e:
                        log.warning("%s: join %s failed: %s", phone, grp, e)

                logged_in += 1
        except Exception as e:
            log.error("%s: login failed: %s", phone, e)

    log.info("Login complete: %d/%d", logged_in, len(phones))
    return logged_in


async def otp_viewer() -> None:
    """View latest OTP codes received from Telegram (chat 777000).

    Iterates every account in ``phone.csv`` and prints the most recent
    service message from the official Telegram OTP sender.
    """
    session_mgr = SessionManager()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return

    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                await _print_latest_otp(app, phone)
        except Exception as e:
            log.error("%s: failed: %s", phone, e)


async def _print_latest_otp(app: "Client", phone: str) -> None:
    """Fetch and print the latest OTP message for a single session."""
    log.info("%s: fetching latest OTP", phone)
    try:
        async for msg in app.get_chat_history(OTP_SENDER_ID, limit=1):
            text = msg.text or msg.caption or "(no text)"
            print(f"\n{phone}:")
            print(f"  {text}")
            return
        # No messages returned at all.
        print(f"\n{phone}: no OTP messages")
    except Exception as e:
        log.error("%s: get_chat_history failed: %s", phone, e)


# ---------------------------------------------------------------------------
# 2-Step Verification
# ---------------------------------------------------------------------------

async def set_2fa_password(
    session_mgr: SessionManager,
    password: str,
    current_password: str = "",
    delay: float = 2.0,
    per_account_passwords_csv: str | None = None,
) -> int:
    """Enable (or reset) Telegram 2-Step Verification for all accounts.

    Args:
        session_mgr: Shared session manager.
        password: New 2FA password to set on every account.
        current_password: Existing 2FA password used by all accounts
            (only needed if the accounts already have 2FA enabled).
            If accounts have **different** 2FA passwords, use
            ``per_account_passwords_csv`` instead.
        delay: Delay between accounts.
        per_account_passwords_csv: Optional CSV with columns
            ``phone,current_password``. When provided, each account's
            current password is loaded from this file (overriding
            ``current_password``). Useful when different accounts
            have different 2FA passwords.

    Returns:
        Number of accounts successfully updated.

    Error messages:
        - ``PASSWORD_HASH_INVALID`` → wrong current password.
        - ``PASSWORD_REQUIRED``     → account has 2FA but no password given.
        - ``FRESH_RESET_AUTHORISATION_FORBIDDEN`` → cannot reset within 7 days.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Load per-account current passwords if a CSV was provided.
    per_account_pw: dict[str, str] = {}
    if per_account_passwords_csv:
        per_account_pw = _load_2fa_passwords_csv(per_account_passwords_csv)
        if not per_account_pw:
            log.warning(
                "%s is empty or unreadable — using global current_password",
                per_account_passwords_csv,
            )

    changed = 0
    wrong_pw_count = 0
    skipped_no_current = 0
    errors_other = 0

    for phone in phones:
        # Per-account password overrides the global one.
        acct_pw = per_account_pw.get(phone, current_password)

        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    # Try direct enable (works if no 2FA is set yet).
                    await app.enable_cloud_password(password)
                    changed += 1
                    log.info("%s: 2FA enabled (new)", phone)
                except Exception as e:
                    err_name = type(e).__name__
                    err_msg = str(e).upper()
                    # Account already has 2FA → must remove first.
                    if not acct_pw:
                        log.warning(
                            "%s: 2FA already enabled; needs current_password to reset",
                            phone,
                        )
                        skipped_no_current += 1
                        continue
                    try:
                        await app.remove_cloud_password(acct_pw)
                        await app.enable_cloud_password(password)
                        changed += 1
                        log.info("%s: 2FA reset", phone)
                    except Exception as e2:
                        reason = _classify_2fa_error(e2)
                        log.error("%s: 2FA reset failed — %s", phone, reason)
                        if reason.startswith("PASSWORD_HASH_INVALID"):
                            wrong_pw_count += 1
                        else:
                            errors_other += 1
                await smart_delay(delay, "fast")
        except Exception as e:
            reason = _classify_2fa_error(e)
            log.error("%s: failed — %s", phone, reason)
            errors_other += 1

    # Final summary.
    log.info(
        "2FA summary: %d set / %d wrong-pw / %d need-current / %d other-errors / %d total",
        changed, wrong_pw_count, skipped_no_current, errors_other, len(phones),
    )
    if wrong_pw_count > 0:
        log.error(
            "%d account(s) had WRONG current password. "
            "Use per_account_passwords_csv with columns 'phone,current_password'.",
            wrong_pw_count,
        )
    if skipped_no_current > 0:
        log.error(
            "%d account(s) already have 2FA but no current_password was provided.",
            skipped_no_current,
        )
    return changed


def _classify_2fa_error(e: Exception) -> str:
    """Map a 2FA-related exception to a short, actionable reason string."""
    msg = str(e).upper()
    if "PASSWORD_HASH_INVALID" in msg:
        return ("PASSWORD_HASH_INVALID — current password is wrong for this account. "
                "If accounts have different passwords, use per_account_passwords_csv.")
    if "PASSWORD_REQUIRED" in msg:
        return ("PASSWORD_REQUIRED — account has 2FA but no current password was "
                "supplied.")
    if "FRESH_RESET_AUTHORISATION_FORBIDDEN" in msg or "FRESH_RESET" in msg:
        return ("FRESH_RESET_FORBIDDEN — Telegram requires a 7-day wait before "
                "fully removing the old password. Try again later.")
    if "PASSWORD_TOO_SHORT" in msg or "NEW_PASSWORD_TOO_SHORT" in msg:
        return "PASSWORD_TOO_SHORT — new password must be at least 8 chars (Telegram rule)."
    if "NEW_SALT_INVALID" in msg:
        return "NEW_SALT_INVALID — internal error, retry needed."
    return f"{type(e).__name__} — {e}"


def _load_2fa_passwords_csv(csv_path: str) -> dict[str, str]:
    """Load ``phone,current_password`` pairs from a CSV.

    Used by :func:`set_2fa_password` when accounts have different
    existing 2FA passwords. Returns a dict mapping phone → password.
    """
    import csv as _csv
    from pathlib import Path

    p = Path(csv_path)
    if not p.exists():
        return {}

    result: dict[str, str] = {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            reader = _csv.DictReader(f)
            for row in reader:
                phone = (row.get("phone") or "").strip()
                pw = (row.get("current_password") or row.get("password") or "").strip()
                if phone and pw:
                    result.setdefault(phone, pw)
    except Exception as e:
        log.error("Failed to read %s: %s", csv_path, e)
    return result


# ---------------------------------------------------------------------------
# Secure login (per-account API + device + proxy rotation)
# ---------------------------------------------------------------------------

async def login_using_security(
    delay: float = 2.0,
    skip_proxy_check: bool = False,
) -> int:
    """Login all accounts with **unique** API + device + proxy per account.

    Reads ``api.csv``, ``devices.csv``, ``proxies.csv`` (any that exist)
    and rotates them so every saved session has a different fingerprint.
    This is the recommended login method for multi-account setups.

    Falls back to ``config.ini`` API values if ``api.csv`` is missing,
    and to the built-in device pool if ``devices.csv`` is missing.

    Args:
        delay: Delay between accounts (seconds).
        skip_proxy_check: If True, skip the pre-flight proxy liveness
            check (faster but riskier).

    Returns:
        Number of accounts that successfully authenticated.
    """
    from pyrogram import Client
    from pyrogram.errors import UserAlreadyParticipant

    from ..core.secure_login import (
        build_secure_client_kwargs,
        check_all_proxies_before_start,
        print_resource_summary,
    )

    cfg = get_config()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    total = len(phones)
    print_resource_summary(total)

    if not skip_proxy_check and not check_all_proxies_before_start(total):
        log.error("Aborting: proxy pre-flight check failed")
        return 0

    # Build the support-group list.
    support_groups: list[str] = []
    configured = cfg.support_group
    if configured:
        support_groups.append(configured)
    for grp in ("@NMDDER_ch", "@NMDDER_SUPPORT"):
        if grp not in support_groups:
            support_groups.append(grp)

    logged_in = 0
    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] Secure-login %s", idx, total, phone)
        try:
            kwargs = build_secure_client_kwargs(
                phone=phone,
                account_index=idx - 1,
                total_accounts=total,
            )
            app = Client(**kwargs)
            await app.start()
            me = await app.get_me()
            log.info(
                "%s: logged in as %s (api=%s, device=%s)",
                phone,
                me.first_name or "?",
                kwargs["api_id"],
                kwargs.get("device_model", "?"),
            )
            for grp in support_groups:
                if not grp:
                    continue
                try:
                    await app.join_chat(grp)
                    log.debug("%s: joined %s", phone, grp)
                    await asyncio.sleep(15)  # Shorter than login_all since proxy is already rotating
                except UserAlreadyParticipant:
                    pass
                except Exception as e:
                    log.warning("%s: join %s failed: %s", phone, grp, e)
            await app.stop()
            logged_in += 1
        except Exception as e:
            log.error("%s: secure login failed: %s", phone, e)
        await smart_delay(delay, "fast")

    log.info("Secure login complete: %d/%d", logged_in, total)
    return logged_in


# ===========================================================================
# v41: SpamBot status check + complaint submission
# (adapted from unified_tool.py — async, modular)
# ===========================================================================

SPAMBOT_USERNAME = "SpamBot"


async def check_spambot_status(app) -> str:
    """Check the account's limit status via ``@SpamBot``.

    Sends ``/start`` then reads the latest reply and classifies it:
    - ``'clean'``       → no limits ("Good news, no limits...").
    - ``'restricted'``  → "harsh response" / "limited" / "restricted".
    - ``'banned'``      → "banned" + "phone"/"number".
    - ``'unknown'``     → couldn't determine.

    This replaces the old ``_spambot_walk`` with a cleaner, more
    reliable state machine.
    """
    import asyncio as _aio

    try:
        try:
            await app.send_message(SPAMBOT_USERNAME, "/start")
        except Exception as e:
            log.warning("SpamBot send /start: %s", e)
            return "unknown"

        await _aio.sleep(2.5)

        # Read latest reply
        text = ""
        try:
            async for m in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                text = (m.text or "").lower()
                break
        except Exception as e:
            log.warning("SpamBot read: %s", e)
            return "unknown"

        if not text:
            return "unknown"

        if "good news" in text or "free as a bird" in text:
            return "clean"
        if "harsh" in text:
            return "restricted"
        if "limited" in text or "restricted" in text:
            return "restricted"
        if "banned" in text and ("phone" in text or "number" in text):
            return "banned"
        return "unknown"
    except Exception as e:
        log.warning("check_spambot_status: %s", e)
        return "unknown"


async def submit_spambot_complaint(app) -> bool:
    """Submit an automatic complaint to ``@SpamBot`` to lift restrictions.

    Walks the bot menu: /start → "Submit a complaint" →
    "No, I'll never do any of this!" → checks confirmation.

    Returns ``True`` if the complaint was submitted (or already
    submitted recently).
    """
    import asyncio as _aio

    try:
        try:
            await app.send_message(SPAMBOT_USERNAME, "/start")
            await _aio.sleep(2.0)
        except Exception:
            pass
        try:
            await app.send_message(SPAMBOT_USERNAME, "Submit a complaint")
            await _aio.sleep(2.0)
        except Exception:
            pass
        try:
            await app.send_message(
                SPAMBOT_USERNAME, "No, I'll never do any of this!"
            )
            await _aio.sleep(1.5)
        except Exception:
            pass

        await _aio.sleep(1.0)

        # Check the reply
        try:
            async for m in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                if m and m.text:
                    txt = m.text.lower()
                    if "complaint" in txt and "submitted" in txt:
                        return True
                    if "patience" in txt:
                        return True
                    if "supervisor" in txt or "review" in txt:
                        return True
                break
            return True  # Assume success if we can't read
        except Exception:
            return True
    except Exception as e:
        log.error("submit_spambot_complaint: %s", e)
        return False


# ===========================================================================
# v41: Restricted account management
# ===========================================================================

RESTRICTED_FILE = "RestrictedNumbers.csv"
FROZEN_FILE = "FrozenNumbers.csv"


def _log_to_csv(filepath: str, phone: str) -> None:
    """Append a phone number to a CSV file (for banned/frozen/restricted)."""
    import csv as _csv
    from pathlib import Path as _P

    p = _P(filepath)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(p, "a", encoding="utf-8", newline="") as f:
            _csv.writer(f).writerow([phone])
    except Exception as e:
        log.error("Failed to write %s: %s", filepath, e)


def log_banned(phone: str) -> None:
    """Log a banned phone to BanNumbers.csv."""
    _log_to_csv("BanNumbers.csv", phone)


def log_frozen(phone: str) -> None:
    """Log a frozen phone to FrozenNumbers.csv."""
    _log_to_csv(FROZEN_FILE, phone)


def log_restricted(phone: str) -> None:
    """Log a restricted phone to RestrictedNumbers.csv."""
    _log_to_csv(RESTRICTED_FILE, phone)


def _read_phone_csv(path: str) -> list[str]:
    """Read a one-phone-per-line CSV."""
    import csv as _csv
    from pathlib import Path as _P

    p = _P(path)
    if not p.exists():
        return []
    result: list[str] = []
    try:
        with open(p, "r", encoding="utf-8") as f:
            for row in _csv.reader(f):
                if row and row[0].strip():
                    result.append(row[0].strip())
    except Exception:
        pass
    return result


def view_restricted() -> None:
    """Display all restricted accounts from RestrictedNumbers.csv."""
    from pathlib import Path as _P

    p = _P(RESTRICTED_FILE)
    if not p.exists():
        print("[i] لا يوجد ملف RestrictedNumbers.csv")
        return

    restricted = _read_phone_csv(RESTRICTED_FILE)
    if not restricted:
        print("[+] لا توجد حسابات مقيّدة ✓")
    else:
        print(f"\nعدد المقيّدين: {len(restricted)}\n")
        for i, phone in enumerate(restricted, 1):
            print(f"  {i}. {phone}")
    print()


async def recover_restricted(session_mgr: SessionManager) -> int:
    """Recover restricted accounts by submitting SpamBot complaints.

    Reads ``RestrictedNumbers.csv``, sends a complaint for each
    restricted account, and removes successfully recovered ones.

    Returns:
        Number of accounts for which complaints were submitted.
    """
    from pathlib import Path as _P

    p = _P(RESTRICTED_FILE)
    if not p.exists():
        log.error("لا يوجد ملف %s — شغّل Ban Filter أولاً", RESTRICTED_FILE)
        return 0

    restricted = _read_phone_csv(RESTRICTED_FILE)
    if not restricted:
        log.info("لا توجد حسابات مقيّدة")
        return 0

    log.info("عدد المقيّدين: %d — سيتم إرسال شكوى لكل حساب", len(restricted))

    cfg = get_config()
    recovered: list[str] = []
    failed: list[str] = []

    for i, pphone in enumerate(restricted, 1):
        log.info("[%d/%d] %s — جارٍ الإرسال...", i, len(restricted), pphone)
        try:
            async with session_mgr.acquire(pphone) as app:
                success = await submit_spambot_complaint(app)
                if success:
                    log.info("%s: تم الإرسال ✓", pphone)
                    recovered.append(pphone)
                else:
                    log.error("%s: فشل", pphone)
                    failed.append(pphone)
            await smart_delay(1.5, "fast")
        except Exception as e:
            log.error("%s: %s", pphone, e)
            failed.append(pphone)

    log.info(
        "Recovery summary: %d sent / %d failed / %d total",
        len(recovered), len(failed), len(restricted),
    )

    # Remove recovered accounts from the restricted file.
    if recovered:
        try:
            import csv as _csv
            with open(RESTRICTED_FILE, "w", encoding="utf-8", newline="") as f:
                writer = _csv.writer(f)
                for p in failed:
                    writer.writerow([p])
            log.info("تم حذف %d من القائمة — راجع بعد 24-48 ساعة", len(recovered))
        except Exception as e:
            log.error("Failed to update %s: %s", RESTRICTED_FILE, e)

    return len(recovered)


# ===========================================================================
# v41: Enhanced BanFilter with SpamBot check + restricted/frozen detection
# ===========================================================================

async def ban_filter_v41(
    session_mgr: SessionManager,
    check_spambot: bool = False,
) -> dict[str, list[str]]:
    """Smart account checker — classifies each account as:
    - ``valid``       → clean, can be used.
    - ``banned``      → banned by Telegram (logged to BanNumbers.csv).
    - ``frozen``      → frozen/deactivated (logged to FrozenNumbers.csv).
    - ``restricted``  → limited by SpamBot (logged to RestrictedNumbers.csv).
    - ``network_err`` → couldn't connect (kept in phone.csv).

    If ``check_spambot`` is True, also sends /start to @SpamBot for
    each account (~3 seconds per account) to detect restrictions
    that login alone can't catch.

    Returns:
        dict with keys: valid, banned, frozen, restricted, network_err.
    """
    phones = load_phones()
    if not phones:
        log.error("phone.csv is empty")
        return {}

    log.info("Total accounts: %d (SpamBot check: %s)", len(phones), check_spambot)

    result: dict[str, list[str]] = {
        "valid": [],
        "banned": [],
        "frozen": [],
        "restricted": [],
        "network_err": [],
    }

    for i, phone in enumerate(phones, 1):
        log.info("[%d/%d] Testing %s", i, len(phones), phone)
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                # Account is alive → check SpamBot if requested.
                if check_spambot:
                    status = await check_spambot_status(app)
                    log.info("%s: SpamBot status = %s", phone, status)
                    if status == "restricted":
                        result["restricted"].append(phone)
                        log_restricted(phone)
                        continue
                    elif status == "banned":
                        result["banned"].append(phone)
                        log_banned(phone)
                        continue
                result["valid"].append(phone)
                log.info("%s: OK ✓", phone)
        except Exception as e:
            err_msg = str(e).lower()
            if "banned" in err_msg or "deactivated" in err_msg:
                result["banned"].append(phone)
                log_banned(phone)
                log.error("%s: BANNED", phone)
            elif "frozen" in err_msg or "freeze" in err_msg:
                result["frozen"].append(phone)
                log_frozen(phone)
                log.warning("%s: FROZEN (kept)", phone)
            else:
                result["network_err"].append(phone)
                log.warning("%s: network error (kept): %s", phone, e)

    log.info(
        "BanFilter summary: %d clean, %d banned, %d frozen, %d restricted, %d network_err",
        len(result["valid"]), len(result["banned"]),
        len(result["frozen"]), len(result["restricted"]),
        len(result["network_err"]),
    )
    return result


# ===========================================================================
# v41: Enhanced account info getter with verification flags
# ===========================================================================

def _get_verification_flags(me) -> dict[str, bool]:
    """Extract verification flags from a pyrogram User object."""
    return {
        "is_verified": bool(getattr(me, "is_verified", False)),
        "is_scam": bool(getattr(me, "is_scam", False)),
        "is_fake": bool(getattr(me, "is_fake", False)),
        "is_premium": bool(getattr(me, "is_premium", False)),
        "is_support": bool(getattr(me, "is_support", False)),
        "is_self": bool(getattr(me, "is_self", False)),
        "is_contact": bool(getattr(me, "is_contact", False)),
        "is_mutual_contact": bool(getattr(me, "is_mutual_contact", False)),
        "is_deleted": bool(getattr(me, "is_deleted", False)),
    }


async def account_info_v41(session_mgr: SessionManager) -> None:
    """Enhanced account info getter — prints all flags + status.

    Replaces the old ``accountinfogetter`` with a more detailed
    version that shows verification flags, scam/fake status, etc.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return

    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                flags = _get_verification_flags(me)

                print(f"\n{'─' * 50}")
                print(f"  Phone: {phone}")
                print(f"{'─' * 50}")
                print(f"  ID:             {me.id}")
                print(f"  Self:           {flags['is_self']}")
                print(f"  Contact:        {flags['is_contact']}")
                print(f"  Mutual Contact: {flags['is_mutual_contact']}")
                print(f"  Deleted:        {flags['is_deleted']}")
                print(f"  Verified:       {flags['is_verified']}")
                print(f"  Scam:           {flags['is_scam']}")
                print(f"  Fake:           {flags['is_fake']}")
                print(f"  Support:        {flags['is_support']}")
                print(f"  Premium:        {flags['is_premium']}")
                print(f"  First Name:     {me.first_name or '(none)'}")
                print(f"  Last Name:      {me.last_name or '(none)'}")
                print(f"  Username:       @{me.username}" if me.username else "  Username:      (none)")
                print(f"  Status:         {me.status}")
                if getattr(me, "last_online_date", None):
                    print(f"  Last Online:    {me.last_online_date}")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    print(f"\n{'─' * 50}")
    print(f"  All account info displayed ({len(phones)} accounts)")
