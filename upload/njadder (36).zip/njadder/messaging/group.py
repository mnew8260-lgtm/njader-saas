"""Send messages to groups (from ts.py).

Public API:
    :func:`send_to_group`                — single message, single group.
    :func:`send_to_group_with_photo`     — single message + photo, single group.
    :func:`send_dm`                      — DM (private message) to a username.
    :func:`send_dm_with_photo`           — DM with photo.
    :func:`send_multi_msg_single_group`  — multiple messages (from CSV), single group.
    :func:`send_multi_msg_multi_groups`  — multiple messages, multiple groups.
    :func:`send_single_msg_multi_groups` — single message, multiple groups.
"""
from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Iterable

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config, get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Single message, single group
# ---------------------------------------------------------------------------

async def send_to_group(
    session_mgr: SessionManager,
    target_group: str,
    message: str,
    delay: float = 2.0,
) -> int:
    """Send a message to a target group from all accounts."""
    phones = load_phones()
    if not phones:
        log.error("No phones available")
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass

                try:
                    await app.send_message(target_group, message)
                    sent += 1
                    log.info("%s: message sent to %s", phone, target_group)
                except Exception as e:
                    log.error("%s: send failed: %s", phone, e)

                await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    return sent


async def send_to_group_with_photo(
    session_mgr: SessionManager,
    target_group: str,
    message: str,
    photo_path: str,
    delay: float = 2.0,
) -> int:
    """Send a message + photo to a target group."""
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass

                try:
                    await app.send_photo(target_group, photo_path, caption=message)
                    sent += 1
                    log.info("%s: photo+msg sent", phone)
                except Exception as e:
                    log.error("%s: send failed: %s", phone, e)

                await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    return sent


# ---------------------------------------------------------------------------
# DM (private messages)
# ---------------------------------------------------------------------------

async def send_dm(
    session_mgr: SessionManager,
    target_username: str,
    message: str,
    delay: float = 2.0,
) -> int:
    """Send a DM to a single username from all accounts (PM spam)."""
    phones = load_phones()
    if not phones:
        return 0

    target_username = target_username.lstrip("@")
    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.send_message(target_username, message)
                    sent += 1
                    log.info("%s: DM sent to @%s", phone, target_username)
                except Exception as e:
                    log.error("%s: send failed: %s", phone, e)
                await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


async def send_dm_with_photo(
    session_mgr: SessionManager,
    target_username: str,
    message: str,
    photo_path: str,
    delay: float = 2.0,
) -> int:
    """Send a DM with photo to a single username from all accounts."""
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0

    target_username = target_username.lstrip("@")
    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.send_photo(target_username, photo_path, caption=message)
                    sent += 1
                    log.info("%s: DM+photo sent to @%s", phone, target_username)
                except Exception as e:
                    log.error("%s: send failed: %s", phone, e)
                await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


# ---------------------------------------------------------------------------
# Multi-message senders
# ---------------------------------------------------------------------------

async def send_multi_msg_single_group(
    session_mgr: SessionManager,
    target_group: str,
    messages: list[str],
    num_sends_per_account: int = 10,
    delay: float = 2.0,
) -> int:
    """Send multiple messages (round-robin from ``messages``) to one group.

    Each account sends ``num_sends_per_account`` messages, cycling
    through ``messages``.
    """
    phones = load_phones()
    if not phones:
        return 0
    if not messages:
        log.error("No messages to send")
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    chat = await app.get_chat(target_group)
                except Exception as e:
                    log.error("%s: resolve chat failed: %s", phone, e)
                    continue

                for i in range(num_sends_per_account):
                    msg = messages[i % len(messages)]
                    try:
                        await app.send_message(chat.id, msg)
                        sent += 1
                        log.info("%s: sent msg %d/%d", phone, i + 1, num_sends_per_account)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: send failed: %s", phone, e)
                        break
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


async def send_single_msg_multi_groups(
    session_mgr: SessionManager,
    target_groups: Iterable[str],
    message: str,
    delay: float = 2.0,
) -> int:
    """Send the same message to multiple groups from all accounts."""
    phones = load_phones()
    if not phones:
        return 0

    target_groups = [g.strip() for g in target_groups if g and g.strip()]
    if not target_groups:
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                # Join all groups first.
                for grp in target_groups:
                    try:
                        await app.join_chat(grp)
                    except UserAlreadyParticipant:
                        pass
                    except Exception as e:
                        log.warning("%s: join %s failed: %s", phone, grp, e)

                # Send message to each group.
                for grp in target_groups:
                    try:
                        await app.send_message(grp, message)
                        sent += 1
                        log.info("%s: sent to %s", phone, grp)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: send to %s failed: %s", phone, grp, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


async def send_multi_msg_multi_groups(
    session_mgr: SessionManager,
    target_groups: Iterable[str],
    messages: list[str],
    num_sends_per_account: int = 10,
    delay: float = 2.0,
) -> int:
    """Send multiple messages (round-robin) to multiple groups."""
    phones = load_phones()
    if not phones:
        return 0
    if not messages:
        log.error("No messages to send")
        return 0
    target_groups = [g.strip() for g in target_groups if g and g.strip()]
    if not target_groups:
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                # Join all groups.
                for grp in target_groups:
                    try:
                        await app.join_chat(grp)
                    except UserAlreadyParticipant:
                        pass

                for i in range(num_sends_per_account):
                    msg = messages[i % len(messages)]
                    for grp in target_groups:
                        try:
                            await app.send_message(grp, msg)
                            sent += 1
                            log.info("%s: sent to %s", phone, grp)
                        except Exception as e:
                            log.error("%s: send to %s failed: %s", phone, grp, e)
                    await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


# ---------------------------------------------------------------------------
# CSV loaders
# ---------------------------------------------------------------------------

def load_messages_csv(path: str = "message.csv") -> list[str]:
    """Load messages from a single-column CSV (first column)."""
    p = Path(path)
    if not p.exists():
        log.error("%s not found", path)
        return []
    result: list[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if row and row[0].strip():
                result.append(row[0].strip())
    return result


def load_multi_messages_csv(path: str = "multimessages.csv") -> list[list[str]]:
    """Load multi-message rows from a CSV — each row is one account's messages."""
    p = Path(path)
    if not p.exists():
        log.error("%s not found", path)
        return []
    result: list[list[str]] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if any(cell.strip() for cell in row):
                result.append([cell.strip() for cell in row if cell.strip()])
    return result


def load_groups_csv(path: str = "multigroups.csv") -> list[str]:
    """Load group @usernames/links from a single-column CSV."""
    p = Path(path)
    if not p.exists():
        log.error("%s not found", path)
        return []
    result: list[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if row and row[0].strip():
                result.append(row[0].strip())
    return result


# ---------------------------------------------------------------------------
# DM spam from data.csv (read usernames, send DM to each)
# ---------------------------------------------------------------------------

async def send_dm_from_data_csv(
    session_mgr: SessionManager,
    message: str,
    max_per_account: int = 50,
    delay: float = 2.0,
    data_csv: str = "data.csv",
) -> int:
    """Send a DM to every username in ``data.csv`` from all accounts.

    Reads the ``username`` column from ``data.csv`` and sends the
    same private message to each. Each account handles a chunk of
    usernames. Skips users with no username.
    """
    phones = load_phones()
    if not phones:
        return 0
    members = _read_data_csv_usernames(data_csv)
    if not members:
        log.error("No usernames in %s", data_csv)
        return 0

    sent = 0
    for idx, phone in enumerate(phones, 1):
        chunk = members[(idx - 1) * max_per_account: idx * max_per_account]
        if not chunk:
            break
        try:
            async with session_mgr.acquire(phone) as app:
                for uname in chunk:
                    try:
                        await app.send_message(uname, message)
                        sent += 1
                        log.info("%s: DM → @%s", phone, uname)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: DM to @%s failed: %s", phone, uname, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    log.info("send_dm_from_data_csv complete: %d sent", sent)
    return sent


async def send_dm_with_photo_from_data_csv(
    session_mgr: SessionManager,
    message: str,
    photo_path: str,
    max_per_account: int = 50,
    delay: float = 2.0,
    data_csv: str = "data.csv",
) -> int:
    """Same as :func:`send_dm_from_data_csv` but with a photo attachment."""
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0
    members = _read_data_csv_usernames(data_csv)
    if not members:
        log.error("No usernames in %s", data_csv)
        return 0

    sent = 0
    for idx, phone in enumerate(phones, 1):
        chunk = members[(idx - 1) * max_per_account: idx * max_per_account]
        if not chunk:
            break
        try:
            async with session_mgr.acquire(phone) as app:
                for uname in chunk:
                    try:
                        await app.send_photo(uname, photo_path, caption=message)
                        sent += 1
                        log.info("%s: DM+photo → @%s", phone, uname)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: DM+photo to @%s failed: %s", phone, uname, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    log.info("send_dm_with_photo_from_data_csv complete: %d sent", sent)
    return sent


# ---------------------------------------------------------------------------
# Ramex sender: scrape a source group, DM each scraped member
# ---------------------------------------------------------------------------

async def ramex_sender(
    session_mgr: SessionManager,
    source_group: str,
    message: str,
    max_per_account: int = 50,
    delay: float = 2.0,
) -> int:
    """Scrape members from a source group and DM each one.

    For each account: scrape ``max_per_account`` members from
    ``source_group``, then send ``message`` as a private DM to each.
    Users already DM'd are tracked via a per-account set to avoid
    duplicates within the same run.
    """
    phones = load_phones()
    if not phones:
        return 0

    sent_total = 0
    dmed: set[int] = set()  # Cross-account dedup.

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] %s — ramex_sender", idx, len(phones), phone)
        sent = 0
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(source_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    chat = await app.get_chat(source_group)
                except Exception as e:
                    log.error("%s: resolve source failed: %s", phone, e)
                    continue
                try:
                    async for member in app.get_chat_members(chat_id=chat.id):
                        if sent >= max_per_account:
                            break
                        user = member.user
                        if user.id in dmed:
                            continue
                        try:
                            await app.send_message(user.id, message)
                            dmed.add(user.id)
                            sent += 1
                            log.info("%s: DM → %s", phone, user.first_name or user.id)
                            await smart_delay(delay, "send_message")
                        except Exception as e:
                            kind = type(e).__name__
                            if "PeerFlood" in kind:
                                log.error("%s: PeerFlood — stopping", phone)
                                break
                            log.debug("%s: DM to %d failed: %s", phone, user.id, e)
                except Exception as e:
                    log.error("%s: scrape failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
        sent_total += sent
        log.info("%s: +%d DMs", phone, sent)

    log.info("ramex_sender complete: %d sent", sent_total)
    return sent_total


# ---------------------------------------------------------------------------
# Single-account senders (variants of multi-account senders)
# ---------------------------------------------------------------------------

async def send_message_single_account(
    session_mgr: SessionManager,
    target_group: str,
    message: str,
    account_index: int = 1,
    num_sends: int = 5,
    delay: float = 2.0,
) -> int:
    """Send ``num_sends`` copies of ``message`` to ``target_group``
    from ONE account (chosen by 1-based ``account_index``).
    """
    phones = load_phones()
    if not phones:
        return 0
    if account_index < 1 or account_index > len(phones):
        log.error("account_index out of range (1..%d)", len(phones))
        return 0
    phone = phones[account_index - 1]

    sent = 0
    try:
        async with session_mgr.acquire(phone) as app:
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            for i in range(num_sends):
                try:
                    await app.send_message(target_group, message)
                    sent += 1
                    log.info("%s: msg %d/%d sent", phone, i + 1, num_sends)
                    await smart_delay(delay, "send_message")
                except Exception as e:
                    log.error("%s: send %d failed: %s", phone, i + 1, e)
                    break
    except Exception as e:
        log.error("%s: account failed: %s", phone, e)
    return sent


async def send_photo_single_account(
    session_mgr: SessionManager,
    target_group: str,
    photo_path: str,
    caption: str = "",
    account_index: int = 1,
    num_sends: int = 5,
    delay: float = 2.0,
) -> int:
    """Send ``num_sends`` copies of ``photo_path`` to ``target_group``
    from ONE account. Optionally attach a ``caption``.
    """
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0
    if account_index < 1 or account_index > len(phones):
        log.error("account_index out of range (1..%d)", len(phones))
        return 0
    phone = phones[account_index - 1]

    sent = 0
    try:
        async with session_mgr.acquire(phone) as app:
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            for i in range(num_sends):
                try:
                    await app.send_photo(target_group, photo_path, caption=caption)
                    sent += 1
                    log.info("%s: photo %d/%d sent", phone, i + 1, num_sends)
                    await smart_delay(delay, "send_message")
                except Exception as e:
                    log.error("%s: photo send %d failed: %s", phone, i + 1, e)
                    break
    except Exception as e:
        log.error("%s: account failed: %s", phone, e)
    return sent


async def send_photo_to_multi_groups_single_account(
    session_mgr: SessionManager,
    target_groups: Iterable[str],
    photo_path: str,
    caption: str = "",
    account_index: int = 1,
    delay: float = 2.0,
) -> int:
    """Send one photo + caption to multiple groups from ONE account."""
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0
    target_groups = [g.strip() for g in target_groups if g and g.strip()]
    if not target_groups:
        return 0
    if account_index < 1 or account_index > len(phones):
        log.error("account_index out of range (1..%d)", len(phones))
        return 0
    phone = phones[account_index - 1]

    sent = 0
    try:
        async with session_mgr.acquire(phone) as app:
            for grp in target_groups:
                try:
                    await app.join_chat(grp)
                except UserAlreadyParticipant:
                    pass
            for grp in target_groups:
                try:
                    await app.send_photo(grp, photo_path, caption=caption)
                    sent += 1
                    log.info("%s: photo → %s", phone, grp)
                    await smart_delay(delay, "send_message")
                except Exception as e:
                    log.error("%s: photo to %s failed: %s", phone, grp, e)
    except Exception as e:
        log.error("%s: account failed: %s", phone, e)
    return sent


# ---------------------------------------------------------------------------
# Multi-message + photo senders (variants of multi-msg senders)
# ---------------------------------------------------------------------------

async def send_multi_msg_with_photo_single_group(
    session_mgr: SessionManager,
    target_group: str,
    messages: list[str],
    photo_path: str,
    num_sends_per_account: int = 10,
    delay: float = 2.0,
) -> int:
    """Multi-message + photo, single group, multi-account.

    Each account sends ``num_sends_per_account`` messages
    (round-robin from ``messages``) WITH the same photo attached.
    """
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0
    if not messages:
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    chat = await app.get_chat(target_group)
                except Exception as e:
                    log.error("%s: resolve failed: %s", phone, e)
                    continue
                for i in range(num_sends_per_account):
                    msg = messages[i % len(messages)]
                    try:
                        await app.send_photo(chat.id, photo_path, caption=msg)
                        sent += 1
                        log.info("%s: photo+msg %d/%d", phone, i + 1, num_sends_per_account)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: send failed: %s", phone, e)
                        break
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


async def send_multi_msg_with_photo_multi_groups(
    session_mgr: SessionManager,
    target_groups: Iterable[str],
    messages: list[str],
    photo_path: str,
    num_sends_per_account: int = 10,
    delay: float = 2.0,
) -> int:
    """Multi-message + photo, multi groups, multi-account."""
    phones = load_phones()
    if not phones:
        return 0
    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0
    if not messages:
        return 0
    target_groups = [g.strip() for g in target_groups if g and g.strip()]
    if not target_groups:
        return 0

    sent = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                for grp in target_groups:
                    try:
                        await app.join_chat(grp)
                    except UserAlreadyParticipant:
                        pass
                for i in range(num_sends_per_account):
                    msg = messages[i % len(messages)]
                    for grp in target_groups:
                        try:
                            await app.send_photo(grp, photo_path, caption=msg)
                            sent += 1
                            log.info("%s: photo+msg → %s", phone, grp)
                        except Exception as e:
                            log.error("%s: send to %s failed: %s", phone, grp, e)
                    await smart_delay(delay, "send_message")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)
    return sent


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_data_csv_usernames(data_csv: str) -> list[str]:
    """Read the ``username`` column from data.csv (returns cleaned @-less names)."""
    p = Path(data_csv)
    if not p.exists():
        return []
    result: list[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            uname = (row.get("username") or "").strip().lstrip("@")
            if uname:
                result.append(uname)
    return result
