"""Forward messages to channels (from ts.py).

Two variants:
- :func:`forward_to_channels`     — uses ``forward_message`` (keeps the
  "forwarded from" tag).
- :func:`forward_without_tag`     — uses ``copy_message`` (anonymous
  re-send, no attribution).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config, get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


async def forward_to_channels(
    session_mgr: SessionManager,
    source_channel: str,
    target_channels: list[str],
    delay: float = 2.0,
    limit: int = 10,
) -> int:
    """Forward recent messages from a source channel to multiple targets.

    Uses :meth:`Client.forward_message` — the messages retain their
    "forwarded from" attribution.
    """
    phones = load_phones()
    if not phones:
        return 0

    target_channels = [t.strip() for t in target_channels if t and t.strip()]
    if not target_channels:
        log.error("No target channels")
        return 0

    forwarded = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                # Join source + targets.
                try:
                    await app.join_chat(source_channel)
                except UserAlreadyParticipant:
                    pass
                for target in target_channels:
                    try:
                        await app.join_chat(target)
                    except UserAlreadyParticipant:
                        pass

                # Forward recent messages.
                try:
                    src = await app.get_chat(source_channel)
                    async for msg in app.get_chat_history(src.id, limit=limit):
                        for target in target_channels:
                            try:
                                await app.forward_message(target, source_channel, msg.id)
                                forwarded += 1
                                log.info("%s: forwarded msg %d → %s", phone, msg.id, target)
                                await smart_delay(delay, "send_message")
                            except Exception as e:
                                log.error("%s: forward to %s failed: %s", phone, target, e)
                except Exception as e:
                    log.error("%s: get_chat_history failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    return forwarded


async def forward_without_tag(
    session_mgr: SessionManager,
    source_channel: str,
    target_channels: list[str],
    delay: float = 2.0,
    limit: int = 10,
) -> int:
    """Copy recent messages from source to targets WITHOUT the forwarded tag.

    Uses :meth:`Client.copy_message` — the destination messages appear
    as if sent by the copying account directly.
    """
    phones = load_phones()
    if not phones:
        return 0

    target_channels = [t.strip() for t in target_channels if t and t.strip()]
    if not target_channels:
        log.error("No target channels")
        return 0

    copied = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(source_channel)
                except UserAlreadyParticipant:
                    pass
                for target in target_channels:
                    try:
                        await app.join_chat(target)
                    except UserAlreadyParticipant:
                        pass

                try:
                    src = await app.get_chat(source_channel)
                    async for msg in app.get_chat_history(src.id, limit=limit):
                        for target in target_channels:
                            try:
                                await app.copy_message(target, src.id, msg.id)
                                copied += 1
                                log.info("%s: copied msg %d → %s", phone, msg.id, target)
                                await smart_delay(delay, "send_message")
                            except Exception as e:
                                log.error("%s: copy to %s failed: %s", phone, target, e)
                except Exception as e:
                    log.error("%s: get_chat_history failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    return copied


async def forward_from_csv(
    session_mgr: SessionManager,
    target_channel: str,
    csv_path: str = "multichannels.csv",
    delay: float = 2.0,
    anonymous: bool = False,
    limit: int = 10,
) -> int:
    """Forward/copy from each source channel (CSV) to ``target_channel``.

    Args:
        anonymous: If True, use :func:`forward_without_tag` (no
            "forwarded from" tag); else use :func:`forward_to_channels`.
    """
    import csv as _csv

    p = Path(csv_path)
    if not p.exists():
        log.error("%s not found", csv_path)
        return 0

    sources: list[str] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in _csv.reader(f):
            if row and row[0].strip():
                sources.append(row[0].strip())

    if not sources:
        log.error("No source channels in %s", csv_path)
        return 0

    fn = forward_without_tag if anonymous else forward_to_channels
    total = 0
    for src in sources:
        n = await fn(session_mgr, src, [target_channel], delay=delay, limit=limit)
        total += n
    return total
