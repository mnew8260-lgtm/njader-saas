"""Secure login with per-account API / device / proxy rotation.

Loads three optional CSV files:
- ``api.csv``      — columns: ``api_id,api_hash`` (one API per row)
- ``devices.csv``  — columns: ``device_model,system_version,app_version``
- ``proxies.csv``  — columns: ``type,host,port,username,password``

Each account in ``phone.csv`` is assigned a unique combination of
API + device + proxy via round-robin. Dead proxies are auto-skipped
(failover). If a file is missing, the corresponding config.ini value
(or built-in default) is used.

This dramatically reduces Telegram's "device fingerprint" risk:
every session is saved with a unique identity, so a single ban does
not cascade across all your accounts.
"""
from __future__ import annotations

import csv
import logging
import socket
from pathlib import Path
from typing import Any

from ..config import get_config

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Built-in device pool (used when devices.csv is missing)
# ---------------------------------------------------------------------------

DEVICE_POOL: list[dict[str, str]] = [
    {"device_model": "iPhone 14 Pro",     "system_version": "iOS 17.2.1",  "app_version": "10.4.1"},
    {"device_model": "Samsung S23 Ultra",  "system_version": "Android 14",  "app_version": "10.4.1"},
    {"device_model": "Xiaomi 13 Pro",      "system_version": "Android 13",  "app_version": "10.4.1"},
    {"device_model": "iPhone 13",          "system_version": "iOS 16.6",    "app_version": "10.4.1"},
    {"device_model": "Google Pixel 7",     "system_version": "Android 14",  "app_version": "10.4.1"},
    {"device_model": "OnePlus 11",         "system_version": "Android 13",  "app_version": "10.4.1"},
    {"device_model": "iPhone 12 Pro Max",  "system_version": "iOS 15.7",    "app_version": "10.4.1"},
    {"device_model": "Huawei P60 Pro",     "system_version": "Android 12",  "app_version": "10.4.1"},
    {"device_model": "Samsung A54",        "system_version": "Android 14",  "app_version": "10.4.1"},
    {"device_model": "iPhone SE 3",        "system_version": "iOS 16.5",    "app_version": "10.4.1"},
]


# ---------------------------------------------------------------------------
# CSV loaders
# ---------------------------------------------------------------------------

def load_apis(path: str = "api.csv") -> list[dict[str, Any]]:
    """Load API credentials from ``api.csv`` (columns: api_id,api_hash).

    Returns an empty list if the file is missing or malformed.
    """
    p = Path(path)
    if not p.exists():
        return []
    apis: list[dict[str, Any]] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row or len(row) < 2:
                continue
            api_id_str = row[0].strip()
            api_hash = row[1].strip()
            if not api_id_str or not api_hash:
                continue
            try:
                apis.append({"api_id": int(api_id_str), "api_hash": api_hash})
            except ValueError:
                continue
    return apis


def load_devices(path: str = "devices.csv") -> list[dict[str, str]]:
    """Load device list from ``devices.csv``.

    Columns: ``device_model,system_version,app_version``.
    Falls back to :data:`DEVICE_POOL` if the file is missing.
    """
    p = Path(path)
    if not p.exists():
        return list(DEVICE_POOL)
    devices: list[dict[str, str]] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row or not row[0].strip():
                continue
            devices.append(
                {
                    "device_model": row[0].strip(),
                    "system_version": row[1].strip() if len(row) > 1 and row[1].strip() else "Android 14",
                    "app_version": row[2].strip() if len(row) > 2 and row[2].strip() else "10.4.1",
                }
            )
    return devices if devices else list(DEVICE_POOL)


def load_proxies(path: str = "proxies.csv") -> list[dict[str, Any]]:
    """Load proxy list from ``proxies.csv``.

    Columns: ``type,host,port,username,password`` (last two optional).
    """
    p = Path(path)
    if not p.exists():
        return []
    proxies: list[dict[str, Any]] = []
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row or not row[0].strip():
                continue
            if len(row) < 3:
                continue
            try:
                proxy: dict[str, Any] = {
                    "scheme": row[0].strip().lower(),
                    "hostname": row[1].strip(),
                    "port": int(row[2].strip()),
                }
                if len(row) > 3 and row[3].strip():
                    proxy["username"] = row[3].strip()
                if len(row) > 4 and row[4].strip():
                    proxy["password"] = row[4].strip()
                proxies.append(proxy)
            except (ValueError, IndexError):
                continue
    return proxies


# ---------------------------------------------------------------------------
# Per-account assignment (round-robin + failover)
# ---------------------------------------------------------------------------

def get_api_for_account(
    account_index: int,
    fallback_api_id: int | None = None,
    fallback_api_hash: str | None = None,
) -> dict[str, Any] | None:
    """Return the API credentials for the ``account_index``-th account.

    Falls back to ``config.ini`` values if no ``api.csv`` is configured.
    """
    apis = load_apis()
    if apis:
        return apis[account_index % len(apis)]
    if fallback_api_id is not None and fallback_api_hash:
        return {"api_id": fallback_api_id, "api_hash": fallback_api_hash}
    return None


def get_device_for_account(account_index: int) -> dict[str, str]:
    """Return device info for the ``account_index``-th account (round-robin)."""
    devices = load_devices()
    return devices[account_index % len(devices)]


def get_proxy_for_account_balanced(
    account_index: int,
    total_accounts: int,
) -> dict[str, Any] | None:
    """Return a balanced proxy assignment for the account.

    - If ``len(proxies) >= total_accounts``: one unique proxy per account.
    - Otherwise: round-robin (every proxy gets ~equal load).
    """
    proxies = load_proxies()
    if not proxies:
        return None
    return proxies[account_index % len(proxies)]


def is_proxy_alive(proxy: dict[str, Any], timeout: float = 5.0) -> bool:
    """Quick TCP-connect probe — returns True if the proxy port is open."""
    if not proxy:
        return False
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((proxy["hostname"], int(proxy["port"])))
        sock.close()
        return result == 0
    except Exception:
        return False


def get_working_proxy_for_account(
    account_index: int,
    total_accounts: int,
    test_alive: bool = True,
) -> dict[str, Any] | None:
    """Return a *working* proxy for the account (with failover).

    If the primary assignment is dead, try the next available proxy.
    If all proxies are dead, returns ``None`` and warns.
    """
    proxies = load_proxies()
    if not proxies:
        return None

    primary = get_proxy_for_account_balanced(account_index, total_accounts)
    if primary and (not test_alive or is_proxy_alive(primary)):
        return primary

    # Failover: try every other proxy.
    for proxy in proxies:
        if proxy == primary:
            continue
        if is_proxy_alive(proxy):
            log.warning(
                "Failover: account %d using %s:%d instead of dead %s",
                account_index,
                proxy["hostname"],
                proxy["port"],
                primary["hostname"] if primary else "(none)",
            )
            return proxy

    log.error("All proxies are dead — proceeding without proxy")
    return None


def check_all_proxies_before_start(total_accounts: int) -> bool:
    """Pre-flight check: report dead/alive proxies before any operation.

    Returns True if at least one proxy is alive (or no proxies configured).
    Returns False if all proxies are dead and the user chooses to abort.
    """
    proxies = load_proxies()
    if not proxies:
        log.info("No proxies.csv — proceeding without proxy (HIGH RISK)")
        return True

    alive = 0
    dead = 0
    for i, proxy in enumerate(proxies, 1):
        if is_proxy_alive(proxy):
            alive += 1
            log.info("Proxy %d: %s:%d — alive", i, proxy["hostname"], proxy["port"])
        else:
            dead += 1
            log.warning("Proxy %d: %s:%d — DEAD", i, proxy["hostname"], proxy["port"])

    log.info("Proxy summary: %d alive, %d dead", alive, dead)
    if alive == 0:
        log.error("All %d proxies are dead — aborting", dead)
        return False
    return True


# ---------------------------------------------------------------------------
# Build Pyrogram Client kwargs with per-account uniqueness
# ---------------------------------------------------------------------------

def build_secure_client_kwargs(
    phone: str,
    account_index: int,
    total_accounts: int,
    sessions_dir: str = "sessions",
) -> dict[str, Any]:
    """Build a Pyrogram ``Client(...)`` kwargs dict with unique identity.

    Combines:
    - Per-account API (from ``api.csv`` or config.ini fallback)
    - Per-account device (from ``devices.csv`` or default pool)
    - Per-account proxy (from ``proxies.csv``, with failover)

    Returns a dict ready to splat into ``Client(**kwargs)``.
    """
    cfg = get_config()

    api_creds = get_api_for_account(
        account_index,
        fallback_api_id=cfg.api_id,
        fallback_api_hash=cfg.api_hash,
    )
    if not api_creds:
        # Final fallback — config.ini values directly.
        api_id = cfg.api_id
        api_hash = cfg.api_hash
    else:
        api_id = api_creds["api_id"]
        api_hash = api_creds["api_hash"]

    device = get_device_for_account(account_index)
    proxy = get_working_proxy_for_account(account_index, total_accounts)

    kwargs: dict[str, Any] = {
        "name": f"{sessions_dir}/{phone.lstrip('+')}",
        "api_id": api_id,
        "api_hash": api_hash,
        "phone_number": phone,
        "device_model": device["device_model"],
        "system_version": device["system_version"],
        "app_version": device["app_version"],
        "lang_code": "en",
        "workdir": ".",
    }
    if proxy:
        kwargs["proxy"] = proxy
    return kwargs


# ---------------------------------------------------------------------------
# Resource summary (pretty-print)
# ---------------------------------------------------------------------------

def print_resource_summary(phone_count: int) -> None:
    """Print a human-readable summary of the resources that will be used."""
    apis = load_apis()
    proxies = load_proxies()
    custom_devices = load_devices()
    devices_count = len(custom_devices) if Path("devices.csv").exists() else len(DEVICE_POOL)
    devices_source = "custom (devices.csv)" if Path("devices.csv").exists() else "default pool"

    print()
    print("═══ Resource Summary ═══")
    print(f"  Accounts : {phone_count}")
    print(f"  APIs     : {len(apis)} available" + (
        f" (round-robin)" if apis and phone_count > len(apis) else ""))
    print(f"  Proxies  : {len(proxies)} available" + (
        f" (round-robin)" if proxies and phone_count > len(proxies) else ""))
    print(f"  Devices  : {devices_count} available ({devices_source})" + (
        f" (round-robin)" if devices_count and phone_count > devices_count else ""))

    if not proxies:
        print("  [!] No proxies.csv → all accounts use same IP (HIGH RISK)")
    elif phone_count > len(proxies):
        per_proxy = phone_count / len(proxies)
        print(f"  [*] Distribution: ~{per_proxy:.1f} accounts per proxy (balanced)")
        print(f"  [*] Failover: enabled (auto-switch dead proxies)")
    else:
        print(f"  [*] Distribution: 1 proxy per account (unique IP)")

    if not apis:
        print("  [!] No api.csv → all accounts use config.ini API")
    elif phone_count > len(apis):
        shared = phone_count - len(apis)
        print(f"  [!] {shared} account(s) will share APIs (round-robin)")

    if apis and proxies:
        unique = min(len(apis), len(proxies), devices_count)
        print(f"  [*] Unique combos: {unique} (API × Proxy × Device)")
    print("═══════════════════════════")
    print()
