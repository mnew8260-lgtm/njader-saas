# ══════════════════════════════════════════════════════════════
#  NJADDER v41 — PROPRIETARY SOFTWARE
#  Copyright (c) 2026 NMDDER — All Rights Reserved.
# ══════════════════════════════════════════════════════════════
"""Core utilities and managers (v41).

Includes: SessionManager, DedupManager, ErrorCounter, FloodTracker,
Fatigue System (Anti-Ban Shield), Secure Login, OpReport, helpers.
"""
from __future__ import annotations

from .dedup import DedupManager
from .errors import (
    ConfigError, DataFileError, ErrorCounter, NjadderError, SessionError,
)
from .fatigue import (
    is_resting, mark_tired, rest_remaining, filter_active, summary,
)
from .flood import FloodTracker
from .helpers import (
    chunk_list, classify_error, extract_flood_seconds,
    load_phones, progress_bar, smart_delay,
)
from .report import OpReport
from .secure_login import (
    build_secure_client_kwargs, check_all_proxies_before_start,
    get_api_for_account, get_device_for_account,
    get_working_proxy_for_account, print_resource_summary,
)
from .session import SessionManager

__all__ = [
    "ConfigError", "DataFileError", "DedupManager", "ErrorCounter",
    "FloodTracker", "NjadderError", "OpReport", "SessionError",
    "SessionManager", "build_secure_client_kwargs",
    "check_all_proxies_before_start", "chunk_list", "classify_error",
    "extract_flood_seconds", "get_api_for_account",
    "get_device_for_account", "get_working_proxy_for_account",
    "is_resting", "load_phones", "mark_tired", "print_resource_summary",
    "progress_bar", "rest_remaining", "filter_active", "smart_delay",
    "summary",
]
