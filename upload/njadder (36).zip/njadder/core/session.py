"""Session management with per-phone locking.

Each phone number gets its own :class:`asyncio.Lock` so that two
coroutines never log in to the same session simultaneously (which would
corrupt the .session file).
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING, AsyncIterator

from pyrogram import Client
from pyrogram.errors import FloodWait

from ..config import get_config

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)

# Default sessions directory (relative to CWD; can be overridden by callers).
DEFAULT_SESSIONS_DIR = Path("sessions")

# How long to wait after app.stop() for pyrogram's background update
# handlers to drain. Without this pause, pyrogram may try to write to
# a closed SQLite database and emit a "Task exception was never
# retrieved" warning at WARNING/ERROR level — purely cosmetic, but
# noisy in the log.
_POST_STOP_DRAIN_SECONDS = 1.0


class SessionManager:
    """Manages Pyrogram :class:`Client` instances per phone number.

    The same manager can be reused across scrapers and adders — each
    phone is guarded by an :class:`asyncio.Lock` so concurrent access
    is serialized.
    """

    def __init__(
        self,
        api_id: int | None = None,
        api_hash: str | None = None,
        sessions_dir: Path | str = DEFAULT_SESSIONS_DIR,
    ) -> None:
        cfg = get_config()
        self.api_id = api_id if api_id is not None else cfg.api_id
        self.api_hash = api_hash if api_hash is not None else cfg.api_hash
        self.sessions_dir = Path(sessions_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self._locks: dict[str, asyncio.Lock] = {}

    def _get_lock(self, phone: str) -> asyncio.Lock:
        """Get (or create) the per-phone lock."""
        if phone not in self._locks:
            self._locks[phone] = asyncio.Lock()
        return self._locks[phone]

    @asynccontextmanager
    async def acquire(self, phone: str) -> AsyncIterator[Client]:
        """Acquire a started Pyrogram client for ``phone``.

        The client is started on entry and stopped on exit. If a
        :class:`FloodWait` is raised while starting, we sleep for the
        wait (capped at 60 s) before re-raising so the caller can skip
        this account.

        After ``app.stop()``, a short drain pause is inserted so that
        pyrogram's background update-handling tasks can finish writing
        to the SQLite database before it is closed — this avoids the
        noisy (but harmless) ``Cannot operate on a closed database``
        warnings in the log.
        """
        lock = self._get_lock(phone)
        async with lock:
            cfg = get_config()
            session_name = phone.lstrip("+")
            client_kwargs: dict[str, object] = {
                "name": session_name,
                "api_id": self.api_id,
                "api_hash": self.api_hash,
                "phone_number": phone,
                "workdir": str(self.sessions_dir),
            }
            proxy = cfg.proxy_dict()
            if proxy:
                client_kwargs["proxy"] = proxy

            app = Client(**client_kwargs)
            try:
                await app.start()
                yield app
            except FloodWait as e:
                wait = min(e.value, 60)
                log.warning("FloodWait %ds for %s", e.value, phone)
                await asyncio.sleep(wait)
                raise
            finally:
                # Stop the client gracefully and wait for pyrogram's
                # background update handlers to drain — otherwise they
                # may try to write to a closed SQLite database and emit
                # "Task exception was never retrieved" warnings.
                await self._safe_stop(app, phone)

    async def _safe_stop(self, app: Client, phone: str) -> None:
        """Stop a pyrogram client and wait for its background tasks to drain."""
        try:
            if not app.is_initialized:
                return
            await app.stop()
        except Exception as e:
            log.debug("Error stopping session %s: %s", phone, e)
            return
        # Give pyrogram's pending update handlers time to finish.
        try:
            await asyncio.sleep(_POST_STOP_DRAIN_SECONDS)
            # If the dispatcher is still alive, yield once more so its
            # pending tasks can complete (or be cancelled cleanly).
            dispatcher = getattr(app, "dispatcher", None)
            if dispatcher is not None:
                # Stop the dispatcher if it has a stop() coroutine.
                stop_fn = getattr(dispatcher, "stop", None)
                if callable(stop_fn):
                    try:
                        result = stop_fn()
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        log.debug("dispatcher.stop() for %s failed: %s", phone, e)
        except Exception as e:
            log.debug("Drain wait for %s failed: %s", phone, e)
