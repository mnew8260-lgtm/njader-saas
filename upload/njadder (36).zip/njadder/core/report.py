"""CSV report generator for operations."""
from __future__ import annotations

import asyncio
import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

FIELDS = [
    "account",
    "user_id",
    "first_name",
    "last_name",
    "username",
    "is_premium",
    "status",
    "error_type",
    "timestamp",
]


class OpReport:
    """Generates CSV reports for operations.

    Each operation creates a new report file with a timestamp.
    Async-safe writes via internal lock.
    """

    def __init__(
        self,
        op_name: str,
        reports_dir: Path = Path("reports"),
    ) -> None:
        self.op_name = op_name
        self.reports_dir = reports_dir
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = self.reports_dir / f"report_{op_name}_{ts}.csv"
        self._lock = asyncio.Lock()
        self._write_header()

    def _write_header(self) -> None:
        """Write CSV header to a new file."""
        try:
            with open(self.path, "w", encoding="utf-8", newline="") as f:
                csv.writer(f).writerow(FIELDS)
            log.info("Report initialized: %s", self.path)
        except Exception as e:
            log.error("Failed to initialize report %s: %s", self.path, e)

    async def log(
        self,
        account: str,
        user_id: int,
        first: str = "",
        last: str = "",
        username: str = "",
        is_premium: bool = False,
        status: str = "added",
        error_type: str = "",
    ) -> None:
        """Append a row to the report."""
        row: dict[str, Any] = {
            "account": account,
            "user_id": user_id,
            "first_name": first,
            "last_name": last,
            "username": username,
            "is_premium": is_premium,
            "status": status,
            "error_type": error_type,
            "timestamp": datetime.now().isoformat(),
        }
        async with self._lock:
            try:
                with open(self.path, "a", encoding="utf-8", newline="") as f:
                    csv.DictWriter(f, fieldnames=FIELDS).writerow(row)
            except Exception as e:
                log.error("Failed to write report row: %s", e)
