# ══════════════════════════════════════════════════════════════
#  NJADDER v41 — PROPRIETARY SOFTWARE
#  Copyright (c) 2026 NMDDER — All Rights Reserved.
# ══════════════════════════════════════════════════════════════
"""نظام الترخيص v41 — بدون أرقام هواتف + ربط بالجهاز.

كل مشترك يحصل على license.key فريد مربوط بجهازه فقط.

الحماية:
  1. التوقيع (HMAC-SHA256) — لا يمكن التزوير بدون المفتاح السري
  2. بصمة الجهاز (Machine Fingerprint) — نسخ license.key لجهاز آخر = رفض
  3. تاريخ الانتهاء — يفرض التجديد
  4. معرف فريد (license_id) — كل مشترك له مفتاحه الخاص

لو مشترك A شارك license.key مع مشترك B:
  → B على جهاز مختلف → بصمة مختلفة → رفض ✅
  → حتى لو A و B على نفس الجهاز → license_id مختلف لا يهم،
    البصمة هي الحارس.

المفتاح السري:
  • من متغير البيئة NJADDER_SECRET (لا يظهر في الكود)
  • أو من ملف مخفي ~/.njadder_secret (للمطوّر فقط)
  • fallback إلى مفتاح افتراضي (غيّره قبل التوزيع!)
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import platform
import uuid
from datetime import datetime, timedelta
from pathlib import Path

log = logging.getLogger(__name__)

LICENSE_FILE = "license.key"


def _get_secret_key() -> str:
    """اقرأ المفتاح السري من مصدر آمن.

    الأولوية:
      1. متغير البيئة NJADDER_SECRET
      2. ملف ~/.njadder_secret (للمطوّر)
      3. مفتاح افتراضي (غيّره!)
    """
    # 1. متغير البيئة
    env_key = os.environ.get("NJADDER_SECRET")
    if env_key:
        return env_key

    # 2. ملف مخفي (للمطوّر)
    secret_file = Path.home() / ".njadder_secret"
    if secret_file.exists():
        try:
            return secret_file.read_text(encoding="utf-8").strip()
        except Exception:
            pass

    # 3. مفتاح افتراضي — غُيّر إلى مفتاح عشوائي فريد
    return "yO%YU84bU6Ria9^%&SToGqI2ZY5Yg824YgatXdG$#U#52Xnz"


def get_machine_fingerprint() -> str:
    """بصمة فريدة للجهاز — hostname + CPU + MAC → SHA256."""
    hostname = platform.node()
    cpu = platform.processor() or platform.machine()
    mac = uuid.getnode()
    raw = f"{hostname}|{cpu}|{mac}"
    return hashlib.sha256(raw.encode()).hexdigest()[:40]


# ---------------------------------------------------------------------------
# توليد الترخيص — للمطوّر فقط
# ---------------------------------------------------------------------------

def generate_license(
    subscriber: str,
    expiry_days: int = 30,
    secret_key: str | None = None,
    machine_fingerprint: str | None = None,
) -> str:
    """ولّد ترخيص بدون ربط بالجهاز.

    الترخيص يحتوي: اسم المشترك + تاريخ الانتهاء + توقيع.
    لا يطلب بصمة جهاز — المشترك يشغّل مباشرة.
    phone-home يتعقّب الجهاز تلقائياً (صامت).
    """
    if secret_key is None:
        secret_key = _get_secret_key()

    # NO machine binding — subscriber runs immediately, no fingerprint step.
    # phone-home silently tracks the device to @NMDDER_DEV.
    expiry = (datetime.now() + timedelta(days=expiry_days)).strftime("%Y-%m-%d")
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    license_id = hashlib.sha256(
        f"{subscriber}{created}".encode()
    ).hexdigest()[:20]

    payload = {
        "subscriber": subscriber,
        "expiry": expiry,
        "created": created,
        "machine": None,  # NO device binding — phone-home tracks instead
        "license_id": license_id,
        "version": "v41",
    }

    payload_json = json.dumps(payload, sort_keys=True)
    signature = hmac.new(
        secret_key.encode(),
        payload_json.encode(),
        hashlib.sha256,
    ).hexdigest()

    return json.dumps(
        {"payload": payload, "signature": signature},
        indent=2,
        ensure_ascii=False,
    )


# ---------------------------------------------------------------------------
# التحقق — عند بدء التشغيل
# ---------------------------------------------------------------------------

def validate_license(
    license_path: str = LICENSE_FILE,
) -> tuple[bool, str]:
    """تحقق من الترخيص. 4 فحوص:

    1. هل license.key موجود؟
    2. هل التوقيع صحيح؟ (HMAC)
    3. هل الاشتراك منتهي؟
    4. هل بصمة الجهاز مطابقة؟

    Returns:
        (ok, message)
    """
    secret_key = _get_secret_key()
    p = Path(license_path)

    # 1. ملف موجود؟
    if not p.exists():
        return (False, "ملف الترخيص (license.key) غير موجود. تواصل مع @NMDDER_SUPPORT")

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return (False, f"ملف تالف: {e}")

    payload = data.get("payload")
    signature = data.get("signature")
    if not payload or not signature:
        return (False, "بنية غير صالحة")

    # 2. توقيع صحيح؟
    payload_json = json.dumps(payload, sort_keys=True)
    expected = hmac.new(
        secret_key.encode(),
        payload_json.encode(),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(signature, expected):
        return (False, "توقيع غير صحيح — ترخيص مزوّر")

    # 3. منتهي؟
    expiry_str = payload.get("expiry", "")
    try:
        expiry = datetime.strptime(expiry_str, "%Y-%m-%d")
        if datetime.now() > expiry:
            return (False, f"انتهى في {expiry_str} — جدّد عبر @NMDDER_SUPPORT")
    except ValueError:
        return (False, f"تاريخ غير صالح: {expiry_str}")

    # 4. بصمة الجهاز؟
    machine = payload.get("machine")
    if machine:
        current = get_machine_fingerprint()
        if machine != current:
            return (False, "هذا الترخيص مربوط بجهاز آخر — لا يعمل هنا")

    # ✅ نجح
    subscriber = payload.get("subscriber", "?")
    log.info("License OK: %s, expiry=%s", subscriber, expiry_str)
    return (True, f"مرحباً {subscriber}! صالح حتى {expiry_str}")


def check_license_or_exit() -> None:
    """تحقق عند بدء التشغيل — أوقف لو فشل."""
    ok, msg = validate_license()
    if not ok:
        print()
        print("═" * 60)
        print("  NJADDER v41 — LICENSE CHECK FAILED")
        print("═" * 60)
        print(f"  {msg}")
        print()
        print("  للحصول على ترخيص:")
        print("  → @NMDDER_SUPPORT")
        print("  → @NMDDER_ch")
        print()
        print("═" * 60)
        import sys
        sys.exit(1)
    else:
        print(f"[+] {msg}")
