"""Persistent PeerFlood tracker.

Records when each account hit PeerFlood so subsequent runs can skip
accounts that are still in Telegram's 24h cooldown. Stored as a simple
CSV: ``phone,timestamp_iso``.

The tracker is best-effort — if the file is unreadable or missing we
simply assume the account is not in cooldown.
"""
from __future__ import annotations

import asyncio
import csv
import logging
from datetime import datetime, timedelta
from pathlib import Path

log = logging.getLogger(__name__)

HEADER = ["phone", "timestamp"]
DEFAULT_COOLDOWN_HOURS = 24

# Cooldown inserted between consecutive accounts when one hits
# PeerFlood. Telegram has already rate-limited the next account if it
# was used recently; a long pause gives the API time to settle.
INTER_ACCOUNT_PEERFLOOD_COOLDOWN = 60  # seconds


class FloodTracker:
    """Tracks PeerFlood events per phone, persisted to disk."""

    def __init__(
        self,
        path: Path | str = Path("flooded.csv"),
        cooldown_hours: int = DEFAULT_COOLDOWN_HOURS,
    ) -> None:
        self.path = Path(path)
        self.cooldown = timedelta(hours=cooldown_hours)
        self._lock = asyncio.Lock()
        self._cache: dict[str, datetime] | None = None

    def _load(self) -> dict[str, datetime]:
        """Load phone → last-flood timestamp from disk."""
        result: dict[str, datetime] = {}
        if not self.path.exists():
            return result
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    phone = (row.get("phone") or "").strip()
                    ts_str = (row.get("timestamp") or "").strip()
                    if not phone or not ts_str:
                        continue
                    try:
                        result[phone] = datetime.fromisoformat(ts_str)
                    except ValueError:
                        continue
        except Exception as e:
            log.error("Failed to load %s: %s", self.path, e)
        return result

    @property
    def cache(self) -> dict[str, datetime]:
        """Lazy-loaded in-memory cache of flood timestamps."""
        if self._cache is None:
            self._cache = self._load()
        return self._cache

    def is_in_cooldown(self, phone: str, now: datetime | None = None) -> bool:
        """Check if ``phone`` is still in PeerFlood cooldown."""
        now = now or datetime.now()
        ts = self.cache.get(phone)
        if ts is None:
            return False
        return (now - ts) < self.cooldown

    def remaining_cooldown(self, phone: str, now: datetime | None = None) -> timedelta:
        """Return how long until ``phone`` exits cooldown (zero if not in cooldown)."""
        now = now or datetime.now()
        ts = self.cache.get(phone)
        if ts is None:
            return timedelta()
        elapsed = now - ts
        if elapsed >= self.cooldown:
            return timedelta()
        return self.cooldown - elapsed

    async def mark_flooded(self, phone: str, now: datetime | None = None) -> None:
        """Record that ``phone`` hit PeerFlood at ``now`` (default: now)."""
        now = now or datetime.now()
        async with self._lock:
            # Update cache.
            self.cache[phone] = now
            # Persist (overwrite entire file with current cache).
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.path, "w", encoding="utf-8", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=HEADER)
                    writer.writeheader()
                    for p, ts in self.cache.items():
                        writer.writerow(
                            {"phone": p, "timestamp": ts.isoformat()}
                        )
            except Exception as e:
                log.error("Failed to persist %s: %s", self.path, e)

    def filter_active(self, phones: list[str]) -> list[str]:
        """Return only phones NOT in cooldown (preserves input order)."""
        return [p for p in phones if not self.is_in_cooldown(p)]

    def summary(self) -> dict[str, int]:
        """Return ``{'total': N, 'in_cooldown': M}`` for status display."""
        now = datetime.now()
        in_cd = sum(1 for p in self.cache if self.is_in_cooldown(p, now))
        return {"total": len(self.cache), "in_cooldown": in_cd}
