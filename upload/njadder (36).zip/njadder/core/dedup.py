"""Deduplication manager: in-memory cache + disk CSV + live API check."""
from __future__ import annotations

import asyncio
import csv
import logging
from pathlib import Path
from typing import Set

log = logging.getLogger(__name__)

HEADER = ["user_id", "first_name", "last_name", "username"]


class DedupManager:
    """Three-layer deduplication for added users.

    Layer 1: In-memory set (O(1) lookup)
    Layer 2: Disk CSV (persists across restarts)
    Layer 3: Live API check (performed by callers)
    """

    def __init__(self, done_file: Path = Path("done.csv")) -> None:
        self.done_file = done_file
        self._lock = asyncio.Lock()
        self._cache: Set[int] | None = None

    def _ensure_header(self) -> None:
        """Create the file with header if it doesn't exist."""
        if not self.done_file.exists():
            self.done_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.done_file, "w", encoding="utf-8", newline="") as f:
                csv.DictWriter(f, fieldnames=HEADER).writeheader()

    def _load_cache(self) -> Set[int]:
        """Load user IDs from disk into memory."""
        result: Set[int] = set()
        if not self.done_file.exists():
            return result
        try:
            with open(self.done_file, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    uid_str = str(row.get("user_id", "")).strip()
                    if uid_str and uid_str.isdigit():
                        result.add(int(uid_str))
        except Exception as e:
            log.error("Failed to load done.csv: %s", e)
        return result

    @property
    def cache(self) -> Set[int]:
        """Lazy-loaded in-memory cache."""
        if self._cache is None:
            self._cache = self._load_cache()
        return self._cache

    def is_done(self, user_id: int) -> bool:
        """Check if a user has already been added (synchronous)."""
        return user_id in self.cache

    async def is_done_async(self, user_id: int) -> bool:
        """Async version with lock protection."""
        async with self._lock:
            return self.is_done(user_id)

    async def mark_done(
        self,
        user_id: int,
        first_name: str = "",
        last_name: str = "",
        username: str = "",
    ) -> None:
        """Mark a user as done (added). Persists to disk."""
        async with self._lock:
            self._ensure_header()
            try:
                with open(self.done_file, "a", encoding="utf-8", newline="") as f:
                    csv.DictWriter(f, fieldnames=HEADER).writerow(
                        {
                            "user_id": user_id,
                            "first_name": first_name,
                            "last_name": last_name,
                            "username": username,
                        }
                    )
                self.cache.add(user_id)
            except Exception as e:
                log.error("Failed to mark user %d as done: %s", user_id, e)

    def reset_cache(self) -> None:
        """Force reload of the cache on next access."""
        self._cache = None

    def count(self) -> int:
        """Return number of done users."""
        return len(self.cache)
