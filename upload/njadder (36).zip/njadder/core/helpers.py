"""Helper utilities: phone loading, smart delays, progress bars, classification."""
from __future__ import annotations

import asyncio
import csv
import logging
import math
import random
import re
import sys
from pathlib import Path

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Phone loading
# ---------------------------------------------------------------------------

def load_phones(phone_file: Path | str = Path("phone.csv")) -> list[str]:
    """Load and deduplicate phone numbers from a CSV file.

    The file may contain one phone per line, or a CSV with the phone in the
    first column. Duplicate digits (ignoring ``+`` and whitespace) are
    collapsed. Numbers shorter than 7 digits are rejected as invalid.

    Args:
        phone_file: Path to the phone CSV file.

    Returns:
        List of unique phone numbers in international format (``+XXX...``).
    """
    phone_file = Path(phone_file)
    if not phone_file.exists():
        log.error("Phone file not found: %s", phone_file)
        return []

    seen: set[str] = set()
    phones: list[str] = []

    try:
        with open(phone_file, "r", encoding="utf-8") as f:
            for row in csv.reader(f):
                if not row:
                    continue
                raw = str(row[0]).strip()
                if not raw:
                    continue
                normalized = _normalize_phone(raw)
                if not normalized:
                    continue
                digits = _digits_only(normalized)
                if not digits or digits in seen:
                    continue
                seen.add(digits)
                phones.append(normalized)
    except Exception as e:
        log.error("Failed to load phones from %s: %s", phone_file, e)
        return []

    log.info("Loaded %d unique phones from %s", len(phones), phone_file)
    return phones


def _normalize_phone(raw: str) -> str | None:
    """Normalize a phone number to international format.

    Returns ``None`` if the input has fewer than 7 digits (invalid).
    """
    raw = raw.strip()
    if not raw:
        return None
    digits = _digits_only(raw)
    if len(digits) < 7:
        return None
    return raw if raw.startswith("+") else f"+{digits}"


def _digits_only(s: str) -> str:
    """Extract only digit characters from ``s``."""
    return "".join(c for c in s if c.isdigit())


# ---------------------------------------------------------------------------
# Smart delay (human-like)
# ---------------------------------------------------------------------------

# Action profiles: (mean delay in seconds, log-normal sigma).
_DELAY_PROFILES: dict[str, tuple[float, float]] = {
    "default": (2.0, 0.5),
    "add_member": (3.5, 1.0),
    "send_message": (5.0, 2.0),
    "join_chat": (8.0, 3.0),
    "fast": (1.0, 0.3),
    "micro": (0.5, 0.1),
}


async def smart_delay(
    base: float = 2.0,
    action_type: str = "default",
) -> float:
    """Async delay with realistic log-normal distribution.

    Mimics human behavior — most delays are short, some are longer. The
    actual delay is clamped to ``[0.3, mean * 5]`` to avoid pathological
    outliers.

    Args:
        base: Base delay in seconds. Overridden by ``action_type`` profile
            unless ``action_type`` is unknown.
        action_type: One of ``'default'``, ``'add_member'``,
            ``'send_message'``, ``'join_chat'``, ``'fast'``, ``'micro'``.

    Returns:
        Actual delay duration in seconds.
    """
    mean, std = _DELAY_PROFILES.get(action_type, (base, 0.5))
    delay = random.lognormvariate(math.log(max(mean, 0.1)), std)
    delay = min(delay, mean * 5)
    delay = max(delay, 0.3)
    await asyncio.sleep(delay)
    return delay


# ---------------------------------------------------------------------------
# Progress bar
# ---------------------------------------------------------------------------

def progress_bar(
    current: int,
    total: int,
    width: int = 40,
    label: str = "",
    file=None,
) -> None:
    """Display a single-line progress bar on stderr.

    No-op if ``total <= 0``. Adds a newline when ``current >= total`` so
    subsequent log lines do not overwrite the bar.
    """
    if total <= 0:
        return
    out = file or sys.stderr
    pct = min(1.0, current / total)
    filled = int(width * pct)
    bar = "█" * filled + "░" * (width - filled)
    print(
        f"\r[{bar}] {pct * 100:.1f}% ({current}/{total}) {label}",
        end="",
        file=out,
        flush=True,
    )
    if current >= total:
        print(file=out)


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------

# Error string -> counter kind mapping. Order matters — first match wins.
_ERROR_KINDS: tuple[tuple[str, str], ...] = (
    ("FloodWait", "flood"),
    ("PeerFlood", "peer"),
    ("PeerIdInvalid", "invalid"),
    ("UserPrivacyRestricted", "privacy"),
    ("PhoneNumberBanned", "banned"),
    ("UserBannedInChannel", "banned"),
)


def classify_error(reason: str) -> str:
    """Classify an error reason string into a counter kind.

    Returns one of ``'flood'``, ``'peer'``, ``'banned'``, ``'privacy'``,
    ``'invalid'``, ``'other'``.
    """
    for needle, kind in _ERROR_KINDS:
        if needle in reason:
            return kind
    return "other"


# Accepts "FloodWait 30s", "FloodWait 30", "A wait of 30 seconds", etc.
_FLOOD_RE = re.compile(r"(\d+)\s*s?", re.IGNORECASE)


def extract_flood_seconds(reason: str) -> int | None:
    """Extract FloodWait seconds from a reason string.

    Accepts both ``"FloodWait 30s"`` (with the ``s`` suffix) and
    ``"FloodWait 30"`` (plain integer). Returns ``None`` if no integer
    could be parsed.
    """
    match = _FLOOD_RE.search(reason)
    if not match:
        return None
    try:
        return int(match.group(1))
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def chunk_list(items: list, n_chunks: int) -> list[list]:
    """Split ``items`` into ``n_chunks`` roughly equal chunks.

    - If ``n_chunks <= 0``: returns ``[items]`` (one chunk).
    - If ``n_chunks >= len(items)``: returns one-item-per-chunk for the
      available items, **without** padding with empty chunks.
    - Otherwise: distributes items as evenly as possible, with the last
      chunk absorbing any remainder.
    """
    if n_chunks <= 0:
        return [list(items)]

    n = len(items)
    if n == 0:
        return []

    if n_chunks >= n:
        return [[item] for item in items]

    per = max(1, n // n_chunks)
    chunks = [items[i * per:(i + 1) * per] for i in range(n_chunks)]
    remainder = items[n_chunks * per:]
    if remainder and chunks:
        chunks[-1].extend(remainder)
    return chunks
