"""Error tracking with smart thresholds.

This module also defines a small exception hierarchy used throughout
the package, so callers can catch ``NjadderError`` for any
domain-specific failure.
"""
from __future__ import annotations

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------

class NjadderError(Exception):
    """Base exception for all njadder-specific errors."""


class ConfigError(NjadderError):
    """Raised when configuration is missing or invalid."""


class SessionError(NjadderError):
    """Raised when a Pyrogram session cannot be started."""


class DataFileError(NjadderError):
    """Raised when a data file (phone.csv / data.csv) is unreadable."""


# ---------------------------------------------------------------------------
# ErrorCounter
# ---------------------------------------------------------------------------

@dataclass
class ErrorCounter:
    """Tracks errors during operations (v41 conservative thresholds).

    Smart thresholds (v41 — more conservative):
    - PeerFlood → أوقف الحساب فوراً (max_each=1 للـ peer).
    - FloodWait → راحة إجبارية + أوقف بعد 5 (max_each=5).
    - UserPrivacyRestricted → تجاهل وسجّل في done.csv.
    - UserAlreadyParticipant → اعتبره نجاحاً.
    - ChatAdminRequired → أوقف العملية.
    """

    flood: int = 0
    peer: int = 0
    banned: int = 0
    privacy: int = 0
    invalid: int = 0
    other: int = 0
    max_each: int = 5        # v41: 5 (was 20)
    max_total: int = 15      # v41: 15 (was 200)
    flood_threshold: int = 5  # v41: 5 (was 50)
    invalid_threshold: int = 50  # v41: 50 (was 100)

    # Known kinds — used to validate inputs to add().
    _KNOWN_KINDS = frozenset(
        {"flood", "peer", "banned", "privacy", "invalid", "other"}
    )

    def add(self, kind: str) -> None:
        """Increment the counter named ``kind`` by 1.

        Unknown kinds increment the ``other`` counter.
        """
        if kind in self._KNOWN_KINDS:
            setattr(self, kind, getattr(self, kind) + 1)
        else:
            self.other += 1

    def should_stop(self) -> bool:
        """Check if the operation should stop due to too many errors."""
        if self.peer >= self.max_each:
            return True
        if self.banned >= self.max_each:
            return True
        if self.privacy >= self.max_each * 2:
            return True
        if self.flood >= self.flood_threshold:
            return True
        if self.invalid >= self.invalid_threshold:
            return True
        if self.other >= self.max_total:
            return True
        return False

    def total(self) -> int:
        """Return the total error count."""
        return (
            self.flood
            + self.peer
            + self.banned
            + self.privacy
            + self.invalid
            + self.other
        )

    def summary(self) -> str:
        """Return a human-readable one-line summary."""
        return (
            f"flood={self.flood} peer={self.peer} banned={self.banned} "
            f"privacy={self.privacy} invalid={self.invalid} other={self.other}"
        )

    def reset(self) -> None:
        """Reset all counters to zero."""
        self.flood = self.peer = self.banned = 0
        self.privacy = self.invalid = self.other = 0
