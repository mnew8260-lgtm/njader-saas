# ══════════════════════════════════════════════════════════════
#  NJADDER v41 — PROPRIETARY SOFTWARE
#  Copyright (c) 2026 NMDDER — All Rights Reserved.
# ══════════════════════════════════════════════════════════════
"""نظام الإجهاد والحماية (Anti-Ban Shield / Fatigue System).

يمنع تكرار العمليات على حساب متعب ويفرض راحة إجبارية بعد FloodWait.

القواعد:
  • أي FloodWait → _mark_tired(phone, wait+30)  (30 ثانية احتياط)
  • قبل أي عملية → _is_resting(phone) يجب أن ترجع False
  • لا تتجاوز Cooldown أبداً — الحساب المحظور = خسارة مالية.
"""
from __future__ import annotations

import asyncio
import csv
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path

log = logging.getLogger(__name__)

# Persistent file: phone,rest_until_iso
TIRED_FILE = "tired_accounts.csv"
_SAFETY_MARGIN = 30  # extra seconds after FloodWait wait

# In-memory cache: phone → rest_until timestamp
_tired_cache: dict[str, float] | None = None
_lock = asyncio.Lock()


def _load_tired() -> dict[str, float]:
    """Load tired accounts from disk into memory."""
    result: dict[str, float] = {}
    p = Path(TIRED_FILE)
    if not p.exists():
        return result
    try:
        with open(p, "r", encoding="utf-8") as f:
            for row in csv.reader(f):
                if len(row) >= 2 and row[0].strip():
                    try:
                        ts = float(row[1].strip())
                        if ts > time.time():
                            result[row[0].strip()] = ts
                    except (ValueError, IndexError):
                        continue
    except Exception as e:
        log.error("Failed to load %s: %s", TIRED_FILE, e)
    return result


def _save_tired(cache: dict[str, float]) -> None:
    """Persist the tired cache to disk."""
    p = Path(TIRED_FILE)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            for phone, ts in cache.items():
                if ts > time.time():
                    writer.writerow([phone, str(ts)])
    except Exception as e:
        log.error("Failed to save %s: %s", TIRED_FILE, e)


def _get_cache() -> dict[str, float]:
    """Lazy-load the tired cache."""
    global _tired_cache
    if _tired_cache is None:
        _tired_cache = _load_tired()
    return _tired_cache


def is_resting(phone: str) -> bool:
    """Check if a phone is still resting (in cooldown).

    Returns True if the phone should NOT be used yet.
    """
    cache = _get_cache()
    ts = cache.get(phone)
    if ts is None:
        return False
    if time.time() >= ts:
        # Cooldown expired — remove from cache.
        del cache[phone]
        _save_tired(cache)
        return False
    return True


def rest_remaining(phone: str) -> float:
    """Return seconds remaining until the phone can be used (0 if OK)."""
    cache = _get_cache()
    ts = cache.get(phone, 0)
    remaining = ts - time.time()
    return max(0.0, remaining)


async def mark_tired(phone: str, wait_seconds: int) -> None:
    """Mark a phone as tired — it must rest for ``wait_seconds + safety margin``.

    Called when a FloodWait or PeerFlood is encountered.
    The safety margin (_SAFETY_MARGIN = 30s) is added to avoid edge cases
    where Telegram's internal timer is slightly longer than reported.
    """
    async with _lock:
        cache = _get_cache()
        rest_until = time.time() + wait_seconds + _SAFETY_MARGIN
        cache[phone] = rest_until
        _save_tired(cache)
        log.warning(
            "%s: marked tired — rest %ds + %ds safety = %.0fs total",
            phone, wait_seconds, _SAFETY_MARGIN, rest_until - time.time(),
        )


def filter_active(phones: list[str]) -> list[str]:
    """Return only phones that are NOT resting."""
    return [p for p in phones if not is_resting(p)]


def summary() -> dict[str, int]:
    """Return summary stats: {'total': N, 'resting': M}."""
    cache = _get_cache()
    resting = sum(1 for p in cache if is_resting(p))
    return {"total": len(cache), "resting": resting}


def clear_expired() -> int:
    """Remove expired entries from the cache. Returns count removed."""
    cache = _get_cache()
    now = time.time()
    expired = [p for p, ts in cache.items() if ts <= now]
    for p in expired:
        del cache[p]
    if expired:
        _save_tired(cache)
        log.info("Cleared %d expired tired entries", len(expired))
    return len(expired)
