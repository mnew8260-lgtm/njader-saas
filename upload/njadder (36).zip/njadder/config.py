"""Configuration management via configparser.

Reads from ``config.ini`` using the ``[NJaddingZone]`` section. No
pydantic dependency — pure standard library.

The config file is resolved as follows:
1. The path passed to ``Config(config_file=...)`` (if set).
2. The ``NJADDER_CONFIG`` environment variable.
3. ``config.ini`` in the current working directory.
"""
from __future__ import annotations

import configparser
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

DEFAULT_SECTION = "NJaddingZone"

# Default values if config.ini is missing or values absent.
_DEFAULTS: dict[str, str] = {
    "api_id": "0",
    "api_hash": "YOUR_API_HASH_HERE",
    "startingaccount": "1",
    "endaccount": "50",
    "enterstop": "1000000",
    "togroup": "",
    "fromgroup": "",
    "phone": "",
    "proxy_enabled": "false",
    "proxy_type": "socks5",
    "proxy_host": "127.0.0.1",
    "proxy_port": "1080",
    "proxy_username": "",
    "proxy_password": "",
    "support_group": "@NMDDER_SUPPORT",
}

# Truthy string values for get_bool.
_TRUE_VALUES = frozenset({"true", "1", "yes", "on"})


def _resolve_config_path(explicit: Path | None) -> Path:
    """Return the config file path to load."""
    if explicit is not None:
        return explicit
    env = os.environ.get("NJADDER_CONFIG")
    if env:
        return Path(env)
    return Path("config.ini")


class Config:
    """Type-safe wrapper around :mod:`configparser`.

    Use :meth:`get_str`, :meth:`get_int`, :meth:`get_bool` for typed
    access, or the convenience properties (``api_id``, ``api_hash``, ...).
    """

    def __init__(self, config_file: Path | None = None) -> None:
        self.config_file = _resolve_config_path(config_file)
        self.parser = configparser.ConfigParser()
        self.parser.optionxform = str  # preserve case in keys
        if self.config_file.exists():
            self.parser.read(self.config_file, encoding="utf-8")
            log.info("Loaded config from %s", self.config_file)
        else:
            log.warning(
                "config.ini not found at %s — using defaults",
                self.config_file,
            )

    def get(self, key: str, default: str | None = None) -> str:
        """Get string value from ``[NJaddingZone]`` section."""
        fallback = default if default is not None else _DEFAULTS.get(key, "")
        if self.parser.has_section(DEFAULT_SECTION):
            return self.parser.get(DEFAULT_SECTION, key, fallback=fallback)
        return fallback

    def get_str(self, key: str, default: str = "") -> str:
        """Get a string value (alias for :meth:`get` with a default)."""
        return self.get(key, default)

    def get_int(self, key: str, default: int = 0) -> int:
        """Get an integer value, returning ``default`` on parse failure."""
        try:
            return int(self.get(key, str(default)))
        except (ValueError, TypeError):
            return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get a boolean value (true/1/yes/on → True)."""
        return self.get(key, str(default)).lower() in _TRUE_VALUES

    # -- Convenience properties --------------------------------------------

    @property
    def api_id(self) -> int:
        return self.get_int("api_id", 0)

    @property
    def api_hash(self) -> str:
        return self.get_str("api_hash", "")

    @property
    def from_group(self) -> str:
        return self.get_str("fromgroup")

    @property
    def to_group(self) -> str:
        return self.get_str("togroup")

    @property
    def start_account(self) -> int:
        return self.get_int("startingaccount", 1)

    @property
    def end_account(self) -> int:
        return self.get_int("endaccount", 50)

    @property
    def enter_stop(self) -> int:
        return self.get_int("enterstop", 1000000)

    @property
    def support_group(self) -> str:
        return self.get_str("support_group", "@NMDDER_SUPPORT")

    @property
    def proxy_enabled(self) -> bool:
        return self.get_bool("proxy_enabled", False)

    def proxy_dict(self) -> dict[str, Any] | None:
        """Return a Pyrogram-compatible proxy dict, or ``None`` if disabled."""
        if not self.proxy_enabled:
            return None
        return {
            "scheme": self.get_str("proxy_type", "socks5").lower(),
            "hostname": self.get_str("proxy_host", "127.0.0.1"),
            "port": self.get_int("proxy_port", 1080),
            "username": self.get_str("proxy_username") or None,
            "password": self.get_str("proxy_password") or None,
        }

    def validate(self) -> tuple[bool, str]:
        """Check that required API credentials are present.

        Returns ``(ok, message)``. When ``ok`` is False, ``message``
        describes what is missing.
        """
        if self.api_id == 0:
            return (False, "api_id is 0 — set it in config.ini")
        if not self.api_hash or self.api_hash == "YOUR_API_HASH_HERE":
            return (False, "api_hash is missing — set it in config.ini")
        return (True, "ok")


# Module-level singleton. Use :func:`get_config` to access it.
_config: Config | None = None


def get_config() -> Config:
    """Get the shared :class:`Config` singleton (lazy-initialized)."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def reset_config() -> None:
    """Reset the singleton — primarily for tests."""
    global _config
    _config = None
