"""Nearby adder: adds users found via Telegram Nearby feature."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.raw import functions
from pyrogram.errors import UserAlreadyParticipant

from ..adders.base import BaseAdder, OperationResult
from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones

log = logging.getLogger(__name__)

# Country → locale map (replaces 20+ duplicate functions from ramexfour.py)
COUNTRY_MAP: dict[str, tuple[str, str | None]] = {
    "india": ("en_IN", None),
    "usa": ("en_US", None),
    "bangladesh": ("bn_BD", None),
    "russia": ("ru_RU", None),
    "ukraine": ("uk_UA", None),
    "pakistan": ("fa_IR", "Pakistan not in DB — using Iran"),
    "bhutan": ("fa_IR", "Bhutan not in DB — using Iran"),
    "uzbekistan": ("ru_RU", "Uzbekistan not in DB — using Russia"),
    "combodia": ("th_TH", "Cambodia not in DB — using Thailand"),
    "ethiopia": ("am_ET", None),
    "nigera": ("ha_NG", None),
    "israel": ("he_IL", None),
    "uk": ("en_GB", None),
    "japan": ("ja_JP", None),
    "germany": ("de_DE", None),
    "switzerland": ("de_CH", None),
    "brazil": ("pt_BR", None),
    "indonesia": ("id_ID", None),
    "belgium": ("nl_BE", None),
    "turkey": ("tr_TR", None),
}


class NearbyAdder(BaseAdder):
    """Adds users found via Telegram Nearby feature.

    Replaces 20+ duplicate country-specific functions from ramexfour.py
    with a single unified implementation.
    """

    async def run(
        self,
        target_group: str,
        country: str = "india",
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
    ) -> OperationResult:
        """Execute the nearby adder operation."""
        country = country.lower()
        if country not in COUNTRY_MAP:
            log.error("Country '%s' not supported. Valid: %s", country, list(COUNTRY_MAP))
            return OperationResult()

        locale, note = COUNTRY_MAP[country]
        if note:
            log.warning(note)

        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport(f"nearby_{country}")
        result = OperationResult()

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    try:
                        await app.join_chat(target_group)
                    except UserAlreadyParticipant:
                        pass

                    try:
                        tgt = await app.get_chat(target_group)
                    except Exception as e:
                        log.error("%s: failed to resolve target: %s", phone, e)
                        continue

                    # Get nearby users via raw API
                    try:
                        result_obj = await app.invoke(functions.contacts.GetLocated())
                        for chat in getattr(result_obj, "chats", []):
                            uid = getattr(chat, "id", 0)
                            if not uid or uid in self.dedup.cache:
                                continue

                            ok, reason = await self._add_to_group_safe(app, tgt.id, uid)
                            if ok:
                                added += 1
                                await self.dedup.mark_done(uid)
                                await report.log(
                                    account=phone, user_id=uid, status="added",
                                )
                            else:
                                await report.log(
                                    account=phone, user_id=uid,
                                    status="skipped", error_type=reason,
                                )
                                if await self._handle_error(reason, counter, phone):
                                    break

                            if added >= max_per_account:
                                break
                            await self._delay(delay)
                    except Exception as e:
                        log.error("%s: GetLocated failed: %s", phone, e)

            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.add_account(phone, counter)

        result.report_path = str(report.path)
        return result
