"""Tests for the FloodTracker."""
from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

import pytest

from njadder.core.flood import FloodTracker


@pytest.fixture
def tracker(tmp_path: Path) -> FloodTracker:
    return FloodTracker(path=tmp_path / "flooded.csv", cooldown_hours=24)


class TestFloodTracker:
    def test_initial_state_no_cooldown(self, tracker: FloodTracker) -> None:
        assert not tracker.is_in_cooldown("+1234567890")
        assert tracker.summary() == {"total": 0, "in_cooldown": 0}

    @pytest.mark.asyncio
    async def test_mark_flooded_persists(self, tracker: FloodTracker) -> None:
        await tracker.mark_flooded("+1234567890")
        assert tracker.is_in_cooldown("+1234567890")
        assert tracker.summary()["in_cooldown"] == 1

    @pytest.mark.asyncio
    async def test_mark_flooded_survives_reload(self, tracker: FloodTracker, tmp_path: Path) -> None:
        await tracker.mark_flooded("+111111")
        await tracker.mark_flooded("+222222")
        # Reload from the same file.
        new_tracker = FloodTracker(path=tmp_path / "flooded.csv", cooldown_hours=24)
        assert new_tracker.is_in_cooldown("+111111")
        assert new_tracker.is_in_cooldown("+222222")
        assert new_tracker.summary()["total"] == 2

    def test_filter_active_returns_only_unflooded(self, tracker: FloodTracker) -> None:
        # Manually inject a flood event 1 hour ago.
        tracker._cache = {"+111111": datetime.now() - timedelta(hours=1)}
        # And one from 25h ago — should be expired.
        tracker._cache["+222222"] = datetime.now() - timedelta(hours=25)
        active = tracker.filter_active(["+111111", "+222222", "+333333"])
        assert active == ["+222222", "+333333"]

    def test_remaining_cooldown_zero_when_no_flood(self, tracker: FloodTracker) -> None:
        assert tracker.remaining_cooldown("+999999") == timedelta()

    @pytest.mark.asyncio
    async def test_remaining_cooldown_positive_in_window(self, tracker: FloodTracker) -> None:
        await tracker.mark_flooded("+111111")
        remaining = tracker.remaining_cooldown("+111111")
        assert timedelta(hours=23, minutes=55) <= remaining <= timedelta(hours=24)

    @pytest.mark.asyncio
    async def test_remaining_cooldown_zero_after_expiry(self, tracker: FloodTracker) -> None:
        # Flood event 30h ago — past 24h cooldown.
        tracker._cache = {"+111111": datetime.now() - timedelta(hours=30)}
        assert not tracker.is_in_cooldown("+111111")
        assert tracker.remaining_cooldown("+111111") == timedelta()

    def test_corrupt_file_is_handled_gracefully(self, tmp_path: Path) -> None:
        p = tmp_path / "flooded.csv"
        p.write_text("phone,timestamp\n+123,not-a-date\n", encoding="utf-8")
        t = FloodTracker(path=p, cooldown_hours=24)
        # The corrupt row is skipped — no crash.
        assert not t.is_in_cooldown("+123")
        assert t.summary() == {"total": 0, "in_cooldown": 0}
