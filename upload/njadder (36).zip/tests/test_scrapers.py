"""Tests for scraper helpers (filter distribution)."""
from __future__ import annotations

from njadder.scrapers.public import _ALL_FILTERS, _distribute_filters


def test_all_filters_has_empty_first() -> None:
    """Empty filter must be first so non-ASCII names are captured."""
    assert _ALL_FILTERS[0] == ""


def test_all_filters_contains_a_to_z() -> None:
    for c in "abcdefghijklmnopqrstuvwxyz":
        assert c in _ALL_FILTERS


def test_all_filters_contains_0_to_9() -> None:
    for c in "0123456789":
        assert c in _ALL_FILTERS


def test_distribute_more_accounts_than_filters() -> None:
    """Bug fix: previously, phones beyond index 37 got empty lists."""
    # 50 accounts but only 37 filters — every account must get a
    # non-empty filter list.
    chunks = _distribute_filters(_ALL_FILTERS, 50)
    assert len(chunks) == 50
    for chunk in chunks:
        assert len(chunk) >= 1  # critical: no empty chunks


def test_distribute_more_filters_than_accounts() -> None:
    """Filters split evenly when more filters than accounts."""
    chunks = _distribute_filters(_ALL_FILTERS, 3)
    assert len(chunks) == 3
    # The total coverage across chunks equals all filters.
    flat = [f for chunk in chunks for f in chunk]
    assert set(flat) == set(_ALL_FILTERS)
    # Each chunk is non-empty.
    for chunk in chunks:
        assert len(chunk) > 0


def test_distribute_zero_accounts_returns_one_chunk() -> None:
    chunks = _distribute_filters(_ALL_FILTERS, 0)
    assert len(chunks) == 1
    assert chunks[0] == _ALL_FILTERS


def test_distribute_one_account_gets_all() -> None:
    chunks = _distribute_filters(_ALL_FILTERS, 1)
    assert chunks == [_ALL_FILTERS]


def test_distribute_no_filters_returns_empties() -> None:
    chunks = _distribute_filters([], 5)
    assert len(chunks) == 5
    for chunk in chunks:
        assert chunk == []
