"""Tests for ErrorCounter."""
from __future__ import annotations

from njadder.core.errors import (
    ConfigError,
    DataFileError,
    ErrorCounter,
    NjadderError,
    SessionError,
)


class TestErrorCounter:
    def test_add_unknown_kind_increments_other(self) -> None:
        c = ErrorCounter()
        c.add("totally-unknown-kind")
        assert c.other == 1

    def test_add_known_kind_increments_field(self) -> None:
        c = ErrorCounter()
        c.add("flood")
        c.add("flood")
        assert c.flood == 2
        assert c.total() == 2

    def test_should_stop_on_peer_threshold(self) -> None:
        c = ErrorCounter()
        for _ in range(c.max_each):
            c.add("peer")
        assert c.should_stop() is True

    def test_should_stop_on_flood_threshold(self) -> None:
        c = ErrorCounter()
        for _ in range(c.flood_threshold):
            c.add("flood")
        assert c.should_stop() is True

    def test_should_not_stop_below_invalid_threshold(self) -> None:
        c = ErrorCounter()
        for _ in range(c.invalid_threshold - 1):
            c.add("invalid")
        assert c.should_stop() is False

    def test_should_stop_at_invalid_threshold(self) -> None:
        c = ErrorCounter()
        for _ in range(c.invalid_threshold):
            c.add("invalid")
        assert c.should_stop() is True

    def test_reset_zeros_all(self) -> None:
        c = ErrorCounter()
        c.add("flood")
        c.add("peer")
        c.add("other")
        c.reset()
        assert c.total() == 0
        assert c.flood == 0
        assert c.peer == 0
        assert c.other == 0

    def test_summary_contains_all_kinds(self) -> None:
        c = ErrorCounter()
        c.add("flood")
        s = c.summary()
        for kind in ("flood", "peer", "banned", "privacy", "invalid", "other"):
            assert kind in s

    def test_total_sums_all_counters(self) -> None:
        c = ErrorCounter()
        c.add("flood")
        c.add("peer")
        c.add("banned")
        c.add("privacy")
        c.add("invalid")
        c.add("other")
        assert c.total() == 6


def test_exception_hierarchy() -> None:
    """All custom exceptions inherit from NjadderError."""
    assert issubclass(ConfigError, NjadderError)
    assert issubclass(SessionError, NjadderError)
    assert issubclass(DataFileError, NjadderError)
