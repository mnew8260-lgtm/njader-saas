"""Tests for core helpers."""
from __future__ import annotations

import asyncio
import time
from pathlib import Path

import pytest

from njadder.core.helpers import (
    chunk_list,
    classify_error,
    extract_flood_seconds,
    load_phones,
    progress_bar,
    smart_delay,
)


class TestLoadPhones:
    """Tests for load_phones function."""

    def test_load_phones_from_valid_file(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text("+967123456789\n+967987654321\n", encoding="utf-8")
        result = load_phones(phone_file)
        assert len(result) == 2
        assert "+967123456789" in result

    def test_load_phones_dedup(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text("+967123456789\n+967123456789\n+967987654321\n", encoding="utf-8")
        result = load_phones(phone_file)
        assert len(result) == 2

    def test_load_phones_skip_short_numbers(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text("+123\n+967123456789\n", encoding="utf-8")
        result = load_phones(phone_file)
        assert len(result) == 1

    def test_load_phones_missing_file(self, tmp_path: Path) -> None:
        result = load_phones(tmp_path / "nonexistent.csv")
        assert result == []

    def test_load_phones_accepts_str_path(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text("+967123456789\n", encoding="utf-8")
        # Pass a plain str, not a Path.
        result = load_phones(str(phone_file))
        assert result == ["+967123456789"]

    def test_load_phones_strips_whitespace(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text("  +967123456789  \n\t+967987654321\n", encoding="utf-8")
        result = load_phones(phone_file)
        assert "+967123456789" in result
        assert "+967987654321" in result

    def test_load_phones_handles_csv_rows(self, tmp_path: Path) -> None:
        phone_file = tmp_path / "phones.csv"
        phone_file.write_text(
            "+967123456789,name1\n+967987654321,name2\n", encoding="utf-8"
        )
        result = load_phones(phone_file)
        assert len(result) == 2


class TestSmartDelay:
    """Tests for smart_delay function."""

    @pytest.mark.asyncio
    async def test_smart_delay_returns_float(self) -> None:
        result = await smart_delay(0.5, "fast")
        assert isinstance(result, float)
        assert 0.3 <= result <= 2.5

    @pytest.mark.asyncio
    async def test_smart_delay_actually_delays(self) -> None:
        start = time.monotonic()
        await smart_delay(0.3, "micro")
        elapsed = time.monotonic() - start
        assert elapsed >= 0.3

    @pytest.mark.asyncio
    async def test_smart_delay_unknown_action_falls_back(self) -> None:
        # Should not raise on an unknown action_type.
        result = await smart_delay(0.3, "totally-unknown-action")
        assert isinstance(result, float)
        assert result >= 0.3


class TestClassifyError:
    """Tests for classify_error function."""

    @pytest.mark.parametrize(
        "reason,expected",
        [
            ("FloodWait 30s", "flood"),
            ("PeerFlood", "peer"),
            ("PeerIdInvalid", "invalid"),
            ("UserPrivacyRestricted", "privacy"),
            ("UserBannedInChannel", "banned"),
            ("PhoneNumberBanned", "banned"),
            ("SomeUnknownError", "other"),
        ],
    )
    def test_classify_error(self, reason: str, expected: str) -> None:
        assert classify_error(reason) == expected


class TestExtractFloodSeconds:
    """Tests for extract_flood_seconds function."""

    def test_extract_with_s_suffix(self) -> None:
        assert extract_flood_seconds("FloodWait 30s") == 30

    def test_extract_without_s_suffix(self) -> None:
        # Plain integer — must still work.
        assert extract_flood_seconds("FloodWait 30") == 30

    def test_extract_with_seconds_word(self) -> None:
        assert extract_flood_seconds("A wait of 300 seconds is required") == 300

    def test_extract_returns_none_when_no_digits(self) -> None:
        assert extract_flood_seconds("PeerFlood") is None

    def test_extract_returns_none_on_empty(self) -> None:
        assert extract_flood_seconds("") is None


class TestChunkList:
    """Tests for chunk_list function."""

    def test_chunk_equal_split(self) -> None:
        result = chunk_list([1, 2, 3, 4, 5, 6], 3)
        assert len(result) == 3

    def test_chunk_zero_returns_original(self) -> None:
        result = chunk_list([1, 2, 3], 0)
        assert result == [[1, 2, 3]]

    def test_chunk_more_chunks_than_items_no_empties(self) -> None:
        # Bug fix: previously returned [[1],[2],[3],[],[],[],[],[]].
        result = chunk_list([1, 2, 3, 4, 5], 10)
        assert result == [[1], [2], [3], [4], [5]]

    def test_chunk_empty_list(self) -> None:
        assert chunk_list([], 5) == []

    def test_chunk_negative_returns_one_chunk(self) -> None:
        assert chunk_list([1, 2, 3], -1) == [[1, 2, 3]]

    def test_chunk_distributes_remainder_to_last(self) -> None:
        # 7 items / 3 chunks → per=2, remainder=[6,7] goes into last chunk.
        result = chunk_list([1, 2, 3, 4, 5, 6, 7], 3)
        assert len(result) == 3
        assert result[0] == [1, 2]
        assert result[1] == [3, 4]
        assert result[2] == [5, 6, 7]


class TestProgressBar:
    """Tests for progress_bar function."""

    def test_progress_bar_zero_total_is_noop(self, capsys) -> None:
        # Should not raise on total <= 0.
        progress_bar(5, 0)
        # And produce no output.
        captured = capsys.readouterr()
        assert captured.err == ""

    def test_progress_bar_writes_something(self, capsys) -> None:
        progress_bar(5, 10, label="test")
        captured = capsys.readouterr()
        assert "50.0%" in captured.err
        assert "test" in captured.err

    def test_progress_bar_completes_with_newline(self, capsys) -> None:
        progress_bar(10, 10)
        captured = capsys.readouterr()
        # Should end with a newline so subsequent prints are not on the bar.
        assert captured.err.endswith("\n")
