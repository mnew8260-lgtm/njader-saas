"""Tests for DedupManager."""
from __future__ import annotations

from pathlib import Path

import pytest

from njadder.core.dedup import DedupManager


@pytest.fixture
def dedup(tmp_path: Path) -> DedupManager:
    return DedupManager(done_file=tmp_path / "done.csv")


class TestDedupManager:
    """Tests for DedupManager."""

    def test_initial_state_empty(self, dedup: DedupManager) -> None:
        assert dedup.count() == 0
        assert not dedup.is_done(123)

    @pytest.mark.asyncio
    async def test_mark_done_adds_to_cache(self, dedup: DedupManager) -> None:
        await dedup.mark_done(123, "Test", "User", "@test")
        assert dedup.is_done(123)
        assert dedup.count() == 1

    @pytest.mark.asyncio
    async def test_mark_done_persists_to_disk(self, dedup: DedupManager) -> None:
        await dedup.mark_done(123, "Test", "User", "@test")
        dedup.reset_cache()
        assert dedup.is_done(123)

    @pytest.mark.asyncio
    async def test_multiple_users(self, dedup: DedupManager) -> None:
        for uid in range(100, 110):
            await dedup.mark_done(uid)
        assert dedup.count() == 10
        for uid in range(100, 110):
            assert dedup.is_done(uid)

    @pytest.mark.asyncio
    async def test_is_done_async(self, dedup: DedupManager) -> None:
        await dedup.mark_done(999)
        assert await dedup.is_done_async(999)
        assert not await dedup.is_done_async(888)
