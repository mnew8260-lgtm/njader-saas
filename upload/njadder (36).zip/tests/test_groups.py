"""Tests for the groups subpackage."""
from __future__ import annotations

from njadder.groups.manager import _is_restricted, _RESTRICTED_LEAVE_TARGETS


def test_restricted_targets_include_support_channels() -> None:
    # The support channels must be in the protected list.
    assert _is_restricted("@NMDDER_SUPPORT")
    assert _is_restricted("NMDDER_SUPPORT")
    assert _is_restricted("https://t.me/NMDDER_ch")


def test_restricted_check_is_case_insensitive() -> None:
    assert _is_restricted("@nmdder_support")
    assert _is_restricted("NJADDER_PRO")
    assert _is_restricted("https://t.me/NMDDER_CH")


def test_non_restricted_target_returns_false() -> None:
    assert not _is_restricted("@some_random_group")
    assert not _is_restricted("https://t.me/anygroup")
    assert not _is_restricted("")


def test_restricted_set_is_frozen() -> None:
    # Sanity-check that the module-level constant exists and has the
    # expected entries.
    assert isinstance(_RESTRICTED_LEAVE_TARGETS, frozenset)
    assert "@nmdder_support" in _RESTRICTED_LEAVE_TARGETS
