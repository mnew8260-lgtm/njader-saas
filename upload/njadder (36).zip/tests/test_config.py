"""Tests for the Config wrapper."""
from __future__ import annotations

from pathlib import Path

import pytest

from njadder.config import Config


@pytest.fixture
def config_file(tmp_path: Path) -> Path:
    p = tmp_path / "config.ini"
    p.write_text(
        """
[NJaddingZone]
api_id = 12345
api_hash = abcdef0123456789
startingaccount = 1
endaccount = 100
enterstop = 500000
togroup = @target_group
fromgroup = @source_group
phone = +966500000000
proxy_enabled = true
proxy_type = socks5
proxy_host = 127.0.0.1
proxy_port = 1080
proxy_username = user
proxy_password = pass
support_group = @MY_SUPPORT
""".strip(),
        encoding="utf-8",
    )
    return p


def test_get_str_returns_value(config_file: Path) -> None:
    cfg = Config(config_file)
    assert cfg.get_str("api_hash") == "abcdef0123456789"


def test_get_int_parses(config_file: Path) -> None:
    cfg = Config(config_file)
    assert cfg.api_id == 12345
    assert cfg.start_account == 1
    assert cfg.end_account == 100


def test_get_bool_parses(config_file: Path) -> None:
    cfg = Config(config_file)
    assert cfg.proxy_enabled is True


def test_proxy_dict_returns_full_dict_when_enabled(config_file: Path) -> None:
    cfg = Config(config_file)
    proxy = cfg.proxy_dict()
    assert proxy is not None
    assert proxy["scheme"] == "socks5"
    assert proxy["hostname"] == "127.0.0.1"
    assert proxy["port"] == 1080
    assert proxy["username"] == "user"
    assert proxy["password"] == "pass"


def test_proxy_dict_returns_none_when_disabled(tmp_path: Path) -> None:
    p = tmp_path / "config.ini"
    p.write_text(
        "[NJaddingZone]\napi_id = 1\napi_hash = x\nproxy_enabled = false\n",
        encoding="utf-8",
    )
    cfg = Config(p)
    assert cfg.proxy_dict() is None


def test_validate_returns_error_when_api_id_zero(tmp_path: Path) -> None:
    p = tmp_path / "config.ini"
    p.write_text(
        "[NJaddingZone]\napi_id = 0\napi_hash = YOUR_API_HASH_HERE\n",
        encoding="utf-8",
    )
    cfg = Config(p)
    ok, msg = cfg.validate()
    assert ok is False
    assert "api_id" in msg


def test_validate_returns_error_when_api_hash_placeholder(tmp_path: Path) -> None:
    p = tmp_path / "config.ini"
    p.write_text(
        "[NJaddingZone]\napi_id = 100\napi_hash = YOUR_API_HASH_HERE\n",
        encoding="utf-8",
    )
    cfg = Config(p)
    ok, msg = cfg.validate()
    assert ok is False
    assert "api_hash" in msg


def test_validate_passes_on_valid_config(config_file: Path) -> None:
    cfg = Config(config_file)
    ok, msg = cfg.validate()
    assert ok is True


def test_missing_file_uses_defaults(tmp_path: Path) -> None:
    cfg = Config(tmp_path / "nonexistent.ini")
    # Falls back to the support_group default.
    assert cfg.support_group == "@NMDDER_SUPPORT"
    assert cfg.api_id == 0


def test_get_int_returns_default_on_garbage(tmp_path: Path) -> None:
    p = tmp_path / "config.ini"
    p.write_text(
        "[NJaddingZone]\napi_id = not_an_int\n",
        encoding="utf-8",
    )
    cfg = Config(p)
    # Falls back to default (0) on ValueError.
    assert cfg.api_id == 0
