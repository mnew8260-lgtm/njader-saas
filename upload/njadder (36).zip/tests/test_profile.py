"""Tests for the new account profile utilities."""
from __future__ import annotations

from njadder.account.profile import (
    _classify_username_error,
    _validate_username_format,
    _read_first_column,
    generate_usernames_file,
    random_username,
)


class TestRandomUsername:
    def test_default_length(self) -> None:
        u = random_username()
        assert len(u) == 10  # Default bumped from 8 to 10 to avoid premium-reserved.

    def test_starts_with_letter(self) -> None:
        for _ in range(20):
            u = random_username(length=10)
            assert u[0].isalpha()
            assert u[0].islower() or u[0].isupper()

    def test_min_max_clamping(self) -> None:
        # Too short → clamped to 5.
        assert len(random_username(length=1)) == 5
        # Too long → clamped to 32.
        assert len(random_username(length=100)) == 32

    def test_only_valid_chars(self) -> None:
        import string

        allowed = set(string.ascii_letters + string.digits + "_")
        for _ in range(50):
            u = random_username(length=12)
            assert all(c in allowed for c in u)

    def test_prefix(self) -> None:
        u = random_username(length=8, prefix="bot_")
        assert u.startswith("bot_")
        # Prefix is in addition to the 8 chars.
        assert len(u) == 8 + len("bot_")


class TestGenerateUsernamesFile:
    def test_generates_unique_usernames(self, tmp_path) -> None:
        out = tmp_path / "usernames.csv"
        n = generate_usernames_file(10, out_path=str(out), length=8)
        assert n == 10
        assert out.exists()
        # All rows must be unique.
        usernames = _read_first_column(out)
        assert len(usernames) == 10
        assert len(set(usernames)) == 10

    def test_handles_small_count(self, tmp_path) -> None:
        out = tmp_path / "u.csv"
        n = generate_usernames_file(3, out_path=str(out), length=10)
        assert n == 3
        usernames = _read_first_column(out)
        assert len(usernames) == 3


class TestValidateUsernameFormat:
    def test_valid_username_passes(self) -> None:
        assert _validate_username_format("ahmed123") == []
        assert _validate_username_format("Ahmed_Ali") == []
        assert _validate_username_format("a1234567890") == []

    def test_too_short_detected(self) -> None:
        issues = _validate_username_format("abc")
        assert any("too short" in i for i in issues)

    def test_too_long_detected(self) -> None:
        issues = _validate_username_format("a" * 33)
        assert any("too long" in i for i in issues)

    def test_starts_with_non_letter_detected(self) -> None:
        issues = _validate_username_format("12345")
        assert any("must start with a letter" in i for i in issues)

    def test_ends_with_underscore_detected(self) -> None:
        issues = _validate_username_format("ahmed_")
        assert any("cannot end with underscore" in i for i in issues)

    def test_consecutive_underscores_detected(self) -> None:
        issues = _validate_username_format("ah__med")
        assert any("consecutive underscores" in i for i in issues)

    def test_invalid_chars_detected(self) -> None:
        issues = _validate_username_format("ahméd123")
        assert any("invalid chars" in i for i in issues)


class TestClassifyUsernameError:
    def _make_err(self, msg: str) -> Exception:
        e = Exception(msg)
        return e

    def test_purchase_available_detected(self) -> None:
        err = self._make_err(
            'Telegram says: [400 Bad Request] - [400 USERNAME_PURCHASE_AVAILABLE] '
            '(caused by "account.UpdateUsername")'
        )
        reason = _classify_username_error(err)
        assert "PURCHASE_AVAILABLE" in reason

    def test_occupied_detected(self) -> None:
        err = self._make_err("400 USERNAME_OCCUPIED")
        assert "OCCUPIED" in _classify_username_error(err)

    def test_invalid_detected(self) -> None:
        err = self._make_err("400 USERNAME_INVALID")
        assert "INVALID" in _classify_username_error(err)

    def test_not_modified_detected(self) -> None:
        err = self._make_err("400 USERNAME_NOT_MODIFIED")
        assert "NOT_MODIFIED" in _classify_username_error(err)

    def test_unknown_falls_back_to_type_name(self) -> None:
        err = self._make_err("Some weird error")
        # Falls back to 'Exception' (the type name).
        assert _classify_username_error(err) == "Exception"


class TestReadFirstColumn:
    def test_reads_first_column_only(self, tmp_path) -> None:
        p = tmp_path / "data.csv"
        p.write_text(
            "alice,extra,ignored\nbob,more\n  carol  \n",
            encoding="utf-8",
        )
        result = _read_first_column(p)
        assert result == ["alice", "bob", "carol"]

    def test_skips_empty_rows(self, tmp_path) -> None:
        p = tmp_path / "data.csv"
        p.write_text("\n\nalice\n\nbob\n", encoding="utf-8")
        result = _read_first_column(p)
        assert result == ["alice", "bob"]
