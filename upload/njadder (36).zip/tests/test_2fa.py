"""Tests for the 2FA password helpers."""
from __future__ import annotations

import csv
from pathlib import Path

import pytest

from njadder.account.security import (
    _classify_2fa_error,
    _load_2fa_passwords_csv,
    set_2fa_password,
)


class TestClassify2FAError:
    def _err(self, msg: str) -> Exception:
        return Exception(msg)

    def test_password_hash_invalid(self) -> None:
        e = self._err(
            "Telegram says: [400 Bad Request] - [400 PASSWORD_HASH_INVALID] "
            "- The two-step verification password is invalid "
            '(caused by "account.UpdatePasswordSettings")'
        )
        result = _classify_2fa_error(e)
        assert "PASSWORD_HASH_INVALID" in result
        assert "wrong" in result.lower()

    def test_password_required(self) -> None:
        e = self._err("400 PASSWORD_REQUIRED")
        assert "PASSWORD_REQUIRED" in _classify_2fa_error(e)

    def test_fresh_reset_forbidden(self) -> None:
        e = self._err("400 FRESH_RESET_AUTHORISATION_FORBIDDEN")
        result = _classify_2fa_error(e)
        assert "FRESH_RESET_FORBIDDEN" in result

    def test_password_too_short(self) -> None:
        e = self._err("400 NEW_PASSWORD_TOO_SHORT")
        assert "PASSWORD_TOO_SHORT" in _classify_2fa_error(e)

    def test_unknown_falls_back_to_type_name(self) -> None:
        e = self._err("Some unexpected error")
        result = _classify_2fa_error(e)
        # Falls back to 'Exception' (the type name).
        assert "Exception" in result


class TestLoad2FAPasswordsCSV:
    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        result = _load_2fa_passwords_csv(str(tmp_path / "no.csv"))
        assert result == {}

    def test_loads_phone_password_pairs(self, tmp_path: Path) -> None:
        p = tmp_path / "2fa.csv"
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["phone", "current_password"])
            w.writerow(["+1234567890", "pass1"])
            w.writerow(["+9876543210", "pass2"])
        result = _load_2fa_passwords_csv(str(p))
        assert result == {"+1234567890": "pass1", "+9876543210": "pass2"}

    def test_accepts_password_column_name_too(self, tmp_path: Path) -> None:
        p = tmp_path / "2fa.csv"
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["phone", "password"])  # 'password' instead of 'current_password'
            w.writerow(["+111", "secret"])
        result = _load_2fa_passwords_csv(str(p))
        assert result == {"+111": "secret"}

    def test_skips_empty_rows(self, tmp_path: Path) -> None:
        p = tmp_path / "2fa.csv"
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["phone", "current_password"])
            w.writerow(["", ""])
            w.writerow(["+111", ""])
            w.writerow(["+222", "realpass"])
        result = _load_2fa_passwords_csv(str(p))
        assert result == {"+222": "realpass"}

    def test_handles_corrupt_file(self, tmp_path: Path) -> None:
        p = tmp_path / "2fa.csv"
        p.write_text("not,a,csv,that,makes,sense\nbut,we,still,try\n", encoding="utf-8")
        # Should not crash — just return whatever it can parse.
        result = _load_2fa_passwords_csv(str(p))
        assert isinstance(result, dict)


class TestSet2FAPasswordNoPhones:
    @pytest.mark.asyncio
    async def test_returns_zero_when_no_phones(self, tmp_path: Path, monkeypatch) -> None:
        # Make load_phones return empty.
        from njadder.account import security as sec
        monkeypatch.setattr(sec, "load_phones", lambda *a, **k: [])
        result = await set_2fa_password(None, "newpassword", "oldpassword")
        assert result == 0
