"""Tests for the new utilities: delete_already_filter, extract_vcf stubs, etc."""
from __future__ import annotations

import csv
from pathlib import Path

from njadder.utilities.csv_tools import (
    delete_already_filter,
    extract_vcf_to_numbers,
)


class TestDeleteAlreadyFilter:
    def test_removes_rows_present_in_done(self, tmp_path: Path) -> None:
        data = tmp_path / "data.csv"
        done = tmp_path / "done.csv"

        with open(data, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["user_id", "first_name"])
            w.writeheader()
            w.writerow({"user_id": "100", "first_name": "Alice"})
            w.writerow({"user_id": "200", "first_name": "Bob"})
            w.writerow({"user_id": "300", "first_name": "Carol"})

        with open(done, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["user_id", "first_name", "last_name", "username"])
            w.writeheader()
            w.writerow({"user_id": "200", "first_name": "Bob", "last_name": "", "username": ""})

        removed = delete_already_filter(
            data_csv=str(data), done_csv=str(done)
        )
        assert removed == 1
        # data.csv now has 100 and 300, but not 200.
        with open(data, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        ids = {r["user_id"] for r in rows}
        assert ids == {"100", "300"}

    def test_no_done_csv_returns_zero(self, tmp_path: Path) -> None:
        data = tmp_path / "data.csv"
        with open(data, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["user_id"])
            w.writeheader()
            w.writerow({"user_id": "1"})
        # No done.csv — should return 0 and not crash.
        removed = delete_already_filter(
            data_csv=str(data), done_csv=str(tmp_path / "nonexistent.csv")
        )
        assert removed == 0

    def test_empty_done_returns_zero(self, tmp_path: Path) -> None:
        data = tmp_path / "data.csv"
        done = tmp_path / "done.csv"
        with open(data, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["user_id"])
            w.writeheader()
            w.writerow({"user_id": "1"})
        with open(done, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["user_id", "first_name", "last_name", "username"])
            w.writeheader()  # No rows — just the header.
        removed = delete_already_filter(
            data_csv=str(data), done_csv=str(done)
        )
        assert removed == 0


class TestExtractVcf:
    def test_missing_file_returns_zero(self, tmp_path: Path) -> None:
        result = extract_vcf_to_numbers(
            vcf_path=str(tmp_path / "nonexistent.vcf"),
            out_path=str(tmp_path / "out.csv"),
        )
        assert result == 0

    def test_skips_when_vobject_missing(self, tmp_path: Path, monkeypatch) -> None:
        # Force ImportError even if vobject is installed.
        import builtins

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "vobject":
                raise ImportError("simulated")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", fake_import)

        vcf = tmp_path / "test.vcf"
        vcf.write_text("BEGIN:VCARD\nTEL:+123\nEND:VCARD\n", encoding="utf-8")
        result = extract_vcf_to_numbers(
            vcf_path=str(vcf),
            out_path=str(tmp_path / "out.csv"),
        )
        assert result == 0
