"""Tests for the secure-login resource loaders and rotation helpers."""
from __future__ import annotations

import csv
from pathlib import Path

import pytest

from njadder.core.secure_login import (
    DEVICE_POOL,
    build_secure_client_kwargs,
    get_api_for_account,
    get_device_for_account,
    get_proxy_for_account_balanced,
    load_apis,
    load_devices,
    load_proxies,
    is_proxy_alive,
)


# ---------------------------------------------------------------------------
# CSV loaders
# ---------------------------------------------------------------------------

class TestLoadApis:
    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        assert load_apis(path=str(tmp_path / "no.csv")) == []

    def test_parses_valid_rows(self, tmp_path: Path) -> None:
        p = tmp_path / "api.csv"
        p.write_text("12345,abcdef0123\n67890,bbceface01\n", encoding="utf-8")
        apis = load_apis(path=str(p))
        assert len(apis) == 2
        assert apis[0] == {"api_id": 12345, "api_hash": "abcdef0123"}
        assert apis[1] == {"api_id": 67890, "api_hash": "bbceface01"}

    def test_skips_invalid_rows(self, tmp_path: Path) -> None:
        p = tmp_path / "api.csv"
        p.write_text("12345,abcdef\nnot_a_number,xyz\n\n67890,fedcba\n", encoding="utf-8")
        apis = load_apis(path=str(p))
        assert len(apis) == 2
        assert apis[0]["api_id"] == 12345
        assert apis[1]["api_id"] == 67890


class TestLoadDevices:
    def test_missing_file_returns_default_pool(self, tmp_path: Path) -> None:
        result = load_devices(path=str(tmp_path / "no.csv"))
        assert result == DEVICE_POOL
        assert len(result) >= 10

    def test_parses_custom_devices(self, tmp_path: Path) -> None:
        p = tmp_path / "devices.csv"
        p.write_text(
            "MyPhone,Android 15,10.5.0\nOtherPhone,iOS 18.0,10.5.0\n",
            encoding="utf-8",
        )
        devices = load_devices(path=str(p))
        assert len(devices) == 2
        assert devices[0]["device_model"] == "MyPhone"
        assert devices[1]["system_version"] == "iOS 18.0"


class TestLoadProxies:
    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        assert load_proxies(path=str(tmp_path / "no.csv")) == []

    def test_parses_with_auth(self, tmp_path: Path) -> None:
        p = tmp_path / "proxies.csv"
        p.write_text("socks5,1.2.3.4,1080,user,pass\n", encoding="utf-8")
        proxies = load_proxies(path=str(p))
        assert len(proxies) == 1
        assert proxies[0] == {
            "scheme": "socks5",
            "hostname": "1.2.3.4",
            "port": 1080,
            "username": "user",
            "password": "pass",
        }

    def test_parses_without_auth(self, tmp_path: Path) -> None:
        p = tmp_path / "proxies.csv"
        p.write_text("socks5,1.2.3.4,1080\n", encoding="utf-8")
        proxies = load_proxies(path=str(p))
        assert len(proxies) == 1
        assert "username" not in proxies[0]
        assert "password" not in proxies[0]

    def test_skips_malformed_rows(self, tmp_path: Path) -> None:
        p = tmp_path / "proxies.csv"
        p.write_text("socks5,1.2.3.4\nnot_a_port\n\nsocks5,5.6.7.8,1080\n", encoding="utf-8")
        proxies = load_proxies(path=str(p))
        assert len(proxies) == 1


# ---------------------------------------------------------------------------
# Per-account assignment (round-robin)
# ---------------------------------------------------------------------------

class TestGetApiForAccount:
    def test_round_robin(self, tmp_path: Path, monkeypatch) -> None:
        # Create api.csv with 2 entries.
        p = tmp_path / "api.csv"
        p.write_text("111,aaa\n222,bbb\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        # Account 0 → api 0
        assert get_api_for_account(0)["api_id"] == 111
        # Account 1 → api 1
        assert get_api_for_account(1)["api_id"] == 222
        # Account 2 → wraps back to api 0 (round-robin)
        assert get_api_for_account(2)["api_id"] == 111

    def test_fallback_to_config(self, tmp_path: Path, monkeypatch) -> None:
        # No api.csv → must fall back to provided defaults.
        monkeypatch.chdir(tmp_path)
        result = get_api_for_account(0, fallback_api_id=99, fallback_api_hash="xyz")
        assert result == {"api_id": 99, "api_hash": "xyz"}


class TestGetDeviceForAccount:
    def test_uses_default_pool(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        d0 = get_device_for_account(0)
        d1 = get_device_for_account(1)
        assert d0["device_model"] != d1["device_model"]  # Different devices
        # Round-robin wraps around.
        d_wrap = get_device_for_account(len(DEVICE_POOL))
        assert d_wrap["device_model"] == d0["device_model"]


class TestGetProxyForAccountBalanced:
    def test_round_robin(self, tmp_path: Path, monkeypatch) -> None:
        p = tmp_path / "proxies.csv"
        p.write_text("socks5,1.1.1.1,1080\nsocks5,2.2.2.2,1080\n", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        assert get_proxy_for_account_balanced(0, 5)["hostname"] == "1.1.1.1"
        assert get_proxy_for_account_balanced(1, 5)["hostname"] == "2.2.2.2"
        # Account 2 wraps back to proxy 0.
        assert get_proxy_for_account_balanced(2, 5)["hostname"] == "1.1.1.1"

    def test_returns_none_when_no_proxies(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        assert get_proxy_for_account_balanced(0, 5) is None


# ---------------------------------------------------------------------------
# Liveness test
# ---------------------------------------------------------------------------

class TestTestProxyAlive:
    def test_dead_proxy_returns_false(self) -> None:
        # 192.0.2.1 is TEST-NET-1 (RFC 5737) — guaranteed unreachable.
        proxy = {"hostname": "192.0.2.1", "port": 1}
        assert is_proxy_alive(proxy, timeout=0.5) is False

    def test_empty_proxy_returns_false(self) -> None:
        assert is_proxy_alive(None) is False  # type: ignore[arg-type]

    def test_local_open_port_returns_true(self) -> None:
        # Bind a local socket and check.
        import socket as _socket

        srv = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        try:
            proxy = {"hostname": "127.0.0.1", "port": port}
            assert is_proxy_alive(proxy, timeout=1.0) is True
        finally:
            srv.close()
