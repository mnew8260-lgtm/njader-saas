'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

// Mask a string value: keep last 4 chars, replace the rest with •
function maskSecret(value: string): string {
  if (!value) return '';
  if (value.length <= 4) return '••••';
  return '••••••••••••' + value.slice(-4);
}

export function ConfigModal() {
  const { isConfigOpen, setConfigOpen, config, updateConfig, addLog, language } = useStore();
  const [local, setLocal] = useState(config);
  const [showApiId, setShowApiId] = useState(false);
  const [showApiHash, setShowApiHash] = useState(false);

  // Sync when opening — reset reveal flags too for security
  const handleOpenChange = (open: boolean) => {
    if (open) {
      setLocal(config);
      setShowApiId(false);
      setShowApiHash(false);
    }
    setConfigOpen(open);
  };

  const save = () => {
    updateConfig(local);
    addLog({
      level: 'success',
      message: `[✓] ${language === 'ar' ? 'تم حفظ إعدادات config.ini بنجاح' : 'config.ini settings saved successfully'}`,
    });
    toast.success(language === 'ar' ? 'تم حفظ الإعدادات' : 'Settings saved');
    setConfigOpen(false);
  };

  const exportIni = () => {
    const ini = `[HackingZone]
api_id = ${local.api_id}
api_hash = ${local.api_hash}
phone = ${local.phone}
fromgroup = ${local.fromgroup}
ToGroup = ${local.ToGroup}
EnterStop = ${local.EnterStop}
StartingAccount = ${local.StartingAccount}
EndAccount = ${local.EndAccount}
support_group = ${local.support_group}
`;
    const blob = new Blob([ini], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'config.ini';
    a.click();
    URL.revokeObjectURL(url);
    toast.success(language === 'ar' ? 'تم تصدير config.ini' : 'config.ini exported');
  };

  return (
    <Dialog open={isConfigOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icons.Settings className="h-5 w-5 text-primary" />
            {language === 'ar' ? 'إعدادات config.ini' : 'config.ini Settings'}
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'إعدادات الأداة الرئيسية — API credentials, source/target groups, limits.'
              : 'Main tool configuration — API credentials, source/target groups, limits.'}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="api" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="api" className="text-xs">
              <Icons.KeyRound className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'API' : 'API'}
            </TabsTrigger>
            <TabsTrigger value="groups" className="text-xs">
              <Icons.Users className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'المجموعات' : 'Groups'}
            </TabsTrigger>
            <TabsTrigger value="limits" className="text-xs">
              <Icons.Gauge className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'الحدود' : 'Limits'}
            </TabsTrigger>
          </TabsList>

          {/* API tab */}
          <TabsContent value="api" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* API ID — masked by default */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium">API ID</Label>
                  <Badge variant="outline" className="h-4 text-[9px] px-1 bg-amber-500/10 text-amber-400 border-amber-500/20">
                    <Icons.Lock className="h-2.5 w-2.5 ml-0.5" /> {language === 'ar' ? 'مخفي' : 'Hidden'}
                  </Badge>
                </div>
                <div className="relative">
                  <Input
                    type={showApiId ? 'text' : 'password'}
                    value={local.api_id}
                    onChange={(e) => setLocal({ ...local, api_id: e.target.value })}
                    className="font-mono text-xs pr-10"
                    placeholder="12345678"
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiId((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors"
                    title={showApiId ? (language === 'ar' ? 'إخفاء' : 'Hide') : (language === 'ar' ? 'إظهار' : 'Reveal')}
                  >
                    {showApiId ? <Icons.EyeOff className="h-3.5 w-3.5" /> : <Icons.Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>
                {!showApiId && local.api_id && (
                  <p className="text-[10px] text-muted-foreground/60 font-mono">
                    {language === 'ar' ? 'المعروض:' : 'Preview:'} <span dir="ltr">{maskSecret(local.api_id)}</span>
                  </p>
                )}
              </div>

              {/* API Hash — masked by default */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-medium">API Hash</Label>
                  <Badge variant="outline" className="h-4 text-[9px] px-1 bg-amber-500/10 text-amber-400 border-amber-500/20">
                    <Icons.Lock className="h-2.5 w-2.5 ml-0.5" /> {language === 'ar' ? 'مخفي' : 'Hidden'}
                  </Badge>
                </div>
                <div className="relative">
                  <Input
                    type={showApiHash ? 'text' : 'password'}
                    value={local.api_hash}
                    onChange={(e) => setLocal({ ...local, api_hash: e.target.value })}
                    className="font-mono text-xs pr-10"
                    placeholder="abcdef0123456789abcdef0123456789"
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiHash((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors"
                    title={showApiHash ? (language === 'ar' ? 'إخفاء' : 'Hide') : (language === 'ar' ? 'إظهار' : 'Reveal')}
                  >
                    {showApiHash ? <Icons.EyeOff className="h-3.5 w-3.5" /> : <Icons.Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>
                {!showApiHash && local.api_hash && (
                  <p className="text-[10px] text-muted-foreground/60 font-mono">
                    {language === 'ar' ? 'المعروض:' : 'Preview:'} <span dir="ltr">{maskSecret(local.api_hash)}</span>
                  </p>
                )}
              </div>

              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'رقم الهاتف الافتراضي' : 'Default Phone Number'}
                </Label>
                <Input
                  value={local.phone}
                  onChange={(e) => setLocal({ ...local, phone: e.target.value })}
                  className="font-mono text-xs"
                  placeholder="+1234567890"
                />
              </div>
            </div>
            <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 flex items-start gap-2">
              <Icons.ShieldCheck className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                {language === 'ar'
                  ? '🔒 لأمان أعلى: حقلَا API ID و API Hash مخفيان افتراضياً. اضغط أيقونة العين لإظهارهما مؤقتاً. للأمان القصوى، استخدم Secure Login مع api.csv لتدوير عدة APIs لكل حساب.'
                  : '🔒 For higher security: API ID and API Hash are masked by default. Click the eye icon to reveal temporarily. For maximum security, use Secure Login with api.csv to rotate multiple APIs per account.'}
              </p>
            </div>
          </TabsContent>

          {/* Groups tab */}
          <TabsContent value="groups" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'مجموعة المصدر' : 'Source Group'}
                </Label>
                <Input
                  value={local.fromgroup}
                  onChange={(e) => setLocal({ ...local, fromgroup: e.target.value })}
                  className="font-mono text-xs"
                  placeholder="@sourcegroup"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'مجموعة الهدف' : 'Target Group'}
                </Label>
                <Input
                  value={local.ToGroup}
                  onChange={(e) => setLocal({ ...local, ToGroup: e.target.value })}
                  className="font-mono text-xs"
                  placeholder="@targetgroup"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'مجموعة الدعم الفني' : 'Support Group'}
                </Label>
                <Input
                  value={local.support_group}
                  onChange={(e) => setLocal({ ...local, support_group: e.target.value })}
                  className="font-mono text-xs"
                  placeholder="@NMDDER_SUPPORT (اتركه فارغاً للتعطيل)"
                />
              </div>
            </div>
          </TabsContent>

          {/* Limits tab */}
          <TabsContent value="limits" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'عدد الإيقاف' : 'Stop Count'}
                </Label>
                <Input
                  type="number"
                  value={local.EnterStop}
                  onChange={(e) => setLocal({ ...local, EnterStop: e.target.value })}
                  className="font-mono text-xs"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'حساب البداية' : 'Starting Account'}
                </Label>
                <Input
                  type="number"
                  value={local.StartingAccount}
                  onChange={(e) => setLocal({ ...local, StartingAccount: e.target.value })}
                  className="font-mono text-xs"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">
                  {language === 'ar' ? 'حساب النهاية' : 'End Account'}
                </Label>
                <Input
                  type="number"
                  value={local.EndAccount}
                  onChange={(e) => setLocal({ ...local, EndAccount: e.target.value })}
                  className="font-mono text-xs"
                />
              </div>
            </div>
            <div className="rounded-lg border border-sky-500/20 bg-sky-500/5 p-3 flex items-start gap-2">
              <Icons.Info className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                {language === 'ar'
                  ? 'الحدود تتحكم في عدد المحاولات قبل التوقف التلقائي لمنع حظر الحسابات.'
                  : 'Limits control how many attempts before auto-stopping to prevent account bans.'}
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={exportIni}>
              <Icons.Download className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'تصدير' : 'Export'}
            </Button>
            <Badge variant="outline" className="text-[10px] font-mono">[HackingZone]</Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => setConfigOpen(false)}>
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </Button>
            <Button onClick={save} className="glow-primary">
              <Icons.Save className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'حفظ' : 'Save'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
