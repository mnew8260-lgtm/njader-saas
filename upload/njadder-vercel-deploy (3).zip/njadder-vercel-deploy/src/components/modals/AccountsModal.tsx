'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { useStore, type Account } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

const statusConfig: Record<Account['status'], { label: string; labelAr: string; tone: string }> = {
  logged_in: { label: 'Logged In', labelAr: 'متصل', tone: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20' },
  logged_out: { label: 'Logged Out', labelAr: 'غير متصل', tone: 'bg-muted text-muted-foreground border-border' },
  banned: { label: 'Banned', labelAr: 'محظور', tone: 'bg-red-500/10 text-red-300 border-red-500/20' },
  limited: { label: 'Limited', labelAr: 'مقيّد', tone: 'bg-amber-500/10 text-amber-300 border-amber-500/20' },
  pending: { label: 'Pending OTP', labelAr: 'بانتظار OTP', tone: 'bg-sky-500/10 text-sky-300 border-sky-500/20' },
  not_logged_in: { label: 'Not Logged In', labelAr: 'غير مسجّل', tone: 'bg-amber-500/10 text-amber-300 border-amber-500/20' },
};

export function AccountsModal() {
  const { isAccountsOpen, setAccountsOpen, accounts, addAccount, removeAccount, updateAccount, clearAccounts, addLog, language } = useStore();
  const [phone, setPhone] = useState('');
  const [firstName, setFirstName] = useState('');

  const addNew = () => {
    if (!phone.trim()) {
      toast.error(language === 'ar' ? 'رقم الهاتف مطلوب' : 'Phone number required');
      return;
    }
    const acc: Account = {
      id: crypto.randomUUID(),
      phone: phone.trim(),
      session: `session_${phone.trim().replace(/\D/g, '')}`,
      status: 'pending',
      firstName: firstName.trim() || undefined,
      addedAt: new Date().toISOString(),
    };
    addAccount(acc);
    addLog({ level: 'info', message: `[+] ${language === 'ar' ? 'تمت إضافة حساب:' : 'Account added:'} ${acc.phone} (session: ${acc.session})` });
    setPhone('');
    setFirstName('');
    toast.success(language === 'ar' ? 'تمت الإضافة' : 'Added');
  };

  return (
    <Dialog open={isAccountsOpen} onOpenChange={setAccountsOpen}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icons.Users className="h-5 w-5 text-primary" />
            {language === 'ar' ? 'إدارة الحسابات والجلسات' : 'Accounts & Sessions Manager'}
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'إدارة حسابات تيليجرام المسجّلة — الحالة، الجلسات، آخر نشاط.'
              : 'Manage registered Telegram accounts — status, sessions, last activity.'}
          </DialogDescription>
        </DialogHeader>

        {/* Add new account */}
        <div className="rounded-lg border border-border/60 bg-card/40 p-3 space-y-3">
          <Label className="text-xs font-medium">
            {language === 'ar' ? 'إضافة حساب جديد' : 'Add New Account'}
          </Label>
          <div className="flex items-center gap-2 flex-wrap">
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+1234567890"
              className="font-mono text-xs flex-1 min-w-[140px]"
              onKeyDown={(e) => { if (e.key === 'Enter') addNew(); }}
            />
            <Input
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder={language === 'ar' ? 'الاسم (اختياري)' : 'Name (optional)'}
              className="text-xs flex-1 min-w-[120px]"
            />
            <Button onClick={addNew} className="shrink-0">
              <Icons.UserPlus className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'إضافة' : 'Add'}
            </Button>
          </div>
        </div>

        {/* Account list */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {accounts.length} {language === 'ar' ? 'حساب' : 'accounts'}
            </span>
            <Badge variant="outline" className="text-[10px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
              {accounts.filter((a) => a.status === 'logged_in').length} {language === 'ar' ? 'متصل' : 'active'}
            </Badge>
          </div>
          {accounts.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearAccounts} className="text-red-400 text-xs">
              <Icons.Trash2 className="h-3 w-3 ml-1" />
              {language === 'ar' ? 'مسح الكل' : 'Clear All'}
            </Button>
          )}
        </div>

        <ScrollArea className="h-72 rounded-lg border border-border/40 bg-card/30">
          {accounts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-6">
              <Icons.Users className="h-10 w-10 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground">
                {language === 'ar' ? 'لا توجد حسابات بعد' : 'No accounts yet'}
              </p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                {language === 'ar' ? 'استخدم النموذج أعلاه لإضافة أول حساب' : 'Use the form above to add your first account'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/30">
              {accounts.map((acc) => {
                const st = statusConfig[acc.status];
                return (
                  <div key={acc.id} className="px-3 py-2.5 hover:bg-white/2">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary text-xs font-bold">
                          {(acc.firstName || acc.phone).slice(-2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-mono truncate">{acc.phone}</span>
                            {acc.firstName && <span className="text-xs text-muted-foreground truncate">· {acc.firstName}</span>}
                          </div>
                          <div className="text-[10px] text-muted-foreground/70 font-mono truncate">{acc.session}.session</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Badge variant="outline" className={`text-[9px] ${st.tone}`}>
                          {language === 'ar' ? st.labelAr : st.label}
                        </Badge>
                        <Select
                          value={acc.status}
                          onValueChange={(v) => updateAccount(acc.id, { status: v as Account['status'] })}
                        >
                          <SelectTrigger className="h-6 w-6 p-0 border-0 bg-transparent">
                            <Icons.MoreVertical className="h-3.5 w-3.5 text-muted-foreground" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="logged_in" className="text-xs">{language === 'ar' ? 'متصل' : 'Logged In'}</SelectItem>
                            <SelectItem value="logged_out" className="text-xs">{language === 'ar' ? 'غير متصل' : 'Logged Out'}</SelectItem>
                            <SelectItem value="not_logged_in" className="text-xs">{language === 'ar' ? 'غير مسجّل' : 'Not Logged In'}</SelectItem>
                            <SelectItem value="pending" className="text-xs">{language === 'ar' ? 'بانتظار OTP' : 'Pending OTP'}</SelectItem>
                            <SelectItem value="limited" className="text-xs">{language === 'ar' ? 'مقيّد' : 'Limited'}</SelectItem>
                            <SelectItem value="banned" className="text-xs">{language === 'ar' ? 'محظور' : 'Banned'}</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0 text-red-400" onClick={() => removeAccount(acc.id)}>
                          <Icons.X className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-[10px] text-muted-foreground/50 font-mono">
                      {language === 'ar' ? 'أُضيف:' : 'Added:'} {new Date(acc.addedAt).toLocaleString()}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
