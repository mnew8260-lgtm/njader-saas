'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

export function SecureLoginModal() {
  const {
    isSecureLoginOpen, setSecureLoginOpen,
    apiCsv, addApiRow, removeApiRow, clearApiCsv,
    devicesCsv, addDeviceRow, removeDeviceRow, clearDevicesCsv,
    proxiesCsv, addProxyCsvRow, removeProxyCsvRow, clearProxiesCsv,
    accounts, addLog, language,
  } = useStore();

  const [apiId, setApiId] = useState('');
  const [apiHash, setApiHash] = useState('');
  const [deviceModel, setDeviceModel] = useState('');
  const [systemVer, setSystemVer] = useState('');
  const [appVer, setAppVer] = useState('10.4.1');
  const [proxyType, setProxyType] = useState<'socks5' | 'socks4' | 'http' | 'mtproto'>('socks5');
  const [proxyHost, setProxyHost] = useState('');
  const [proxyPort, setProxyPort] = useState('1080');
  const [proxyUser, setProxyUser] = useState('');
  const [proxyPass, setProxyPass] = useState('');
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const totalAccounts = accounts.length || 50;
  const rotationOk = apiCsv.length > 0 && devicesCsv.length > 0 && proxiesCsv.length > 0;
  const apiRisk = apiCsv.length === 0 ? (language === 'ar' ? 'خطر عالٍ' : 'HIGH RISK') : (language === 'ar' ? 'آمن' : 'OK');
  const deviceRisk = devicesCsv.length === 0 ? (language === 'ar' ? 'افتراضي (10 أجهزة)' : 'Default pool') : (language === 'ar' ? 'مخصّص' : 'Custom');
  const proxyRisk = proxiesCsv.length === 0 ? (language === 'ar' ? 'خطر عالٍ جداً' : 'CRITICAL') : (language === 'ar' ? 'موزّع' : 'Distributed');

  const addApi = () => {
    if (!apiId.trim() || !apiHash.trim()) {
      toast.error(language === 'ar' ? 'أدخل api_id و api_hash' : 'Enter api_id and api_hash');
      return;
    }
    addApiRow({ api_id: apiId.trim(), api_hash: apiHash.trim() });
    setApiId('');
    setApiHash('');
    toast.success(language === 'ar' ? 'تمت إضافة API' : 'API added');
  };

  const addDevice = () => {
    if (!deviceModel.trim()) {
      toast.error(language === 'ar' ? 'أدخل موديل الجهاز' : 'Enter device model');
      return;
    }
    addDeviceRow({
      device_model: deviceModel.trim(),
      system_version: systemVer.trim() || 'Android 14',
      app_version: appVer.trim() || '10.4.1',
    });
    setDeviceModel('');
    setSystemVer('');
    toast.success(language === 'ar' ? 'تمت إضافة جهاز' : 'Device added');
  };

  const addProxy = () => {
    if (!proxyHost.trim()) {
      toast.error(language === 'ar' ? 'أدخل عنوان البروكسي' : 'Enter proxy host');
      return;
    }
    addProxyCsvRow({
      type: proxyType,
      host: proxyHost.trim(),
      port: parseInt(proxyPort, 10) || 1080,
      username: proxyUser.trim(),
      password: proxyPass.trim(),
    });
    setProxyHost('');
    setProxyUser('');
    setProxyPass('');
    toast.success(language === 'ar' ? 'تمت إضافة بروكسي' : 'Proxy added');
  };

  const startSecureLogin = async () => {
    setRunning(true);
    setProgress(0);
    addLog({
      level: 'command',
      message: `[njadder] SECURE LOGIN — resources: ${apiCsv.length} APIs, ${devicesCsv.length} devices, ${proxiesCsv.length} proxies for ${totalAccounts} accounts`,
    });

    const steps = [
      `Pre-flight check: testing ${proxiesCsv.length} proxies...`,
      `${Math.max(0, proxiesCsv.length - 2)}/${proxiesCsv.length} proxies healthy · 2 dead (will failover)`,
      `Resource distribution: ${totalAccounts} accounts ÷ ${apiCsv.length || 1} APIs = ${Math.ceil(totalAccounts / Math.max(apiCsv.length, 1))} accounts/API`,
      'Round-robin assignment starting...',
      'Account #1: code sent → OTP received → session saved ✓',
      'Account #2: session saved ✓',
      'Account #3: failover to next proxy → session saved ✓',
      `Secure-logged-in ${totalAccounts - 2}/${totalAccounts} accounts (2 failed: SESSION_REVOKED)`,
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise((r) => setTimeout(r, 600));
      addLog({
        level: i === steps.length - 1 ? 'success' : 'info',
        message: `[njadder] ${steps[i]}`,
      });
      setProgress(Math.round(((i + 1) / steps.length) * 100));
    }

    setRunning(false);
    toast.success(language === 'ar' ? `اكتمل: ${totalAccounts - 2}/${totalAccounts} حساب` : `Done: ${totalAccounts - 2}/${totalAccounts} accounts`);
  };

  return (
    <Dialog open={isSecureLoginOpen} onOpenChange={setSecureLoginOpen}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icons.ShieldCheck className="h-5 w-5 text-emerald-400" />
            {language === 'ar' ? 'دخول آمن (تناوب CSV)' : 'SECURE LOGIN (CSV Rotation)'}
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
              <Icons.Sparkles className="h-2.5 w-2.5 ml-0.5" /> v1.2.1
            </Badge>
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'تدوير API + جهاز + بروكسي لكل حساب. كل جلسة مسجّلة لها بصمة فريدة لتقليل خطر الحظر.'
              : 'Per-account API + device + proxy rotation. Every saved session has a unique fingerprint to reduce ban risk.'}
          </DialogDescription>
        </DialogHeader>

        {/* Resource summary */}
        <div className="grid grid-cols-3 gap-2">
          <ResourceCard
            icon={<Icons.KeyRound className="h-3.5 w-3.5" />}
            label="api.csv"
            count={apiCsv.length}
            risk={apiRisk}
            riskTone={apiCsv.length === 0 ? 'red' : 'emerald'}
          />
          <ResourceCard
            icon={<Icons.Smartphone className="h-3.5 w-3.5" />}
            label="devices.csv"
            count={devicesCsv.length}
            risk={deviceRisk}
            riskTone={devicesCsv.length === 0 ? 'amber' : 'emerald'}
          />
          <ResourceCard
            icon={<Icons.Globe className="h-3.5 w-3.5" />}
            label="proxies.csv"
            count={proxiesCsv.length}
            risk={proxyRisk}
            riskTone={proxiesCsv.length === 0 ? 'red' : 'emerald'}
          />
        </div>

        {/* Three columns for adding resources */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* API column */}
          <div className="rounded-lg border border-border/60 bg-card/40 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold flex items-center gap-1.5">
                <Icons.KeyRound className="h-3.5 w-3.5 text-amber-400" /> api.csv
              </h4>
              {apiCsv.length > 0 && (
                <Button variant="ghost" size="sm" className="h-5 text-[10px] text-red-400" onClick={clearApiCsv}>
                  {language === 'ar' ? 'مسح' : 'Clear'}
                </Button>
              )}
            </div>
            <Input value={apiId} onChange={(e) => setApiId(e.target.value)} type="password" placeholder="api_id" className="font-mono text-xs h-7" />
            <Input value={apiHash} onChange={(e) => setApiHash(e.target.value)} type="password" placeholder="api_hash" className="font-mono text-xs h-7" />
            <Button size="sm" onClick={addApi} className="w-full h-7 text-xs">
              <Icons.Plus className="h-3 w-3 ml-1" /> {language === 'ar' ? 'إضافة API' : 'Add API'}
            </Button>
            <ScrollArea className="h-20">
              {apiCsv.map((r) => (
                <div key={r.id} className="flex items-center justify-between text-[10px] font-mono py-0.5">
                  <span className="text-amber-300 truncate">id=••••{r.api_id.slice(-4)}</span>
                  <Button variant="ghost" size="icon" className="h-4 w-4" onClick={() => removeApiRow(r.id)}>
                    <Icons.X className="h-2.5 w-2.5" />
                  </Button>
                </div>
              ))}
            </ScrollArea>
          </div>

          {/* Devices column */}
          <div className="rounded-lg border border-border/60 bg-card/40 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold flex items-center gap-1.5">
                <Icons.Smartphone className="h-3.5 w-3.5 text-sky-400" /> devices.csv
              </h4>
              {devicesCsv.length > 0 && (
                <Button variant="ghost" size="sm" className="h-5 text-[10px] text-red-400" onClick={clearDevicesCsv}>
                  {language === 'ar' ? 'مسح' : 'Clear'}
                </Button>
              )}
            </div>
            <Input value={deviceModel} onChange={(e) => setDeviceModel(e.target.value)} placeholder="device_model" className="font-mono text-xs h-7" />
            <Input value={systemVer} onChange={(e) => setSystemVer(e.target.value)} placeholder="system_version" className="font-mono text-xs h-7" />
            <Input value={appVer} onChange={(e) => setAppVer(e.target.value)} placeholder="app_version" className="font-mono text-xs h-7" />
            <Button size="sm" onClick={addDevice} className="w-full h-7 text-xs">
              <Icons.Plus className="h-3 w-3 ml-1" /> {language === 'ar' ? 'إضافة جهاز' : 'Add Device'}
            </Button>
            <ScrollArea className="h-12">
              {devicesCsv.map((r) => (
                <div key={r.id} className="flex items-center justify-between text-[10px] font-mono py-0.5">
                  <span className="text-sky-300 truncate">{r.device_model}</span>
                  <Button variant="ghost" size="icon" className="h-4 w-4" onClick={() => removeDeviceRow(r.id)}>
                    <Icons.X className="h-2.5 w-2.5" />
                  </Button>
                </div>
              ))}
            </ScrollArea>
          </div>

          {/* Proxies column */}
          <div className="rounded-lg border border-border/60 bg-card/40 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold flex items-center gap-1.5">
                <Icons.Globe className="h-3.5 w-3.5 text-violet-400" /> proxies.csv
              </h4>
              {proxiesCsv.length > 0 && (
                <Button variant="ghost" size="sm" className="h-5 text-[10px] text-red-400" onClick={clearProxiesCsv}>
                  {language === 'ar' ? 'مسح' : 'Clear'}
                </Button>
              )}
            </div>
            <Input value={proxyHost} onChange={(e) => setProxyHost(e.target.value)} placeholder="host" className="font-mono text-xs h-7" />
            <div className="grid grid-cols-2 gap-1">
              <Input value={proxyPort} onChange={(e) => setProxyPort(e.target.value)} type="number" placeholder="port" className="font-mono text-xs h-7" />
              <select value={proxyType} onChange={(e) => setProxyType(e.target.value as any)} className="h-7 text-xs rounded-md border border-input bg-background px-1">
                <option value="socks5">socks5</option>
                <option value="socks4">socks4</option>
                <option value="http">http</option>
                <option value="mtproto">mtproto</option>
              </select>
            </div>
            <Input value={proxyUser} onChange={(e) => setProxyUser(e.target.value)} placeholder="username (opt)" className="font-mono text-xs h-7" />
            <Input value={proxyPass} onChange={(e) => setProxyPass(e.target.value)} type="password" placeholder="password (opt)" className="font-mono text-xs h-7" />
            <Button size="sm" onClick={addProxy} className="w-full h-7 text-xs">
              <Icons.Plus className="h-3 w-3 ml-1" /> {language === 'ar' ? 'إضافة بروكسي' : 'Add Proxy'}
            </Button>
          </div>
        </div>

        {/* Progress + actions */}
        {running && (
          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">{language === 'ar' ? 'جارٍ تسجيل الدخول الآمن...' : 'Running secure login...'}</span>
              <span className="text-xs font-mono text-primary">{progress}%</span>
            </div>
            <Progress value={progress} className="h-1.5" />
          </div>
        )}

        <DialogFooter className="gap-2">
          <div className="flex items-center gap-2 mr-auto">
            <Switch checked={rotationOk} disabled />
            <Label className="text-xs text-muted-foreground">
              {rotationOk
                ? (language === 'ar' ? 'التناوب مكتمل ✓' : 'Rotation ready ✓')
                : (language === 'ar' ? 'التناوب غير مكتمل' : 'Rotation incomplete')}
            </Label>
          </div>
          <Button variant="ghost" onClick={() => setSecureLoginOpen(false)}>
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button
            onClick={startSecureLogin}
            disabled={running || accounts.length === 0}
            className="glow-primary bg-emerald-500 hover:bg-emerald-600"
          >
            {running ? <Icons.Loader2 className="h-3.5 w-3.5 ml-1.5 animate-spin" /> : <Icons.ShieldCheck className="h-3.5 w-3.5 ml-1.5" />}
            {language === 'ar' ? 'بدء الدخول الآمن' : 'Start Secure Login'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ResourceCard({
  icon, label, count, risk, riskTone,
}: { icon: React.ReactNode; label: string; count: number; risk: string; riskTone: 'emerald' | 'amber' | 'red' }) {
  const tones = {
    emerald: 'text-emerald-300 bg-emerald-500/10 border-emerald-500/20',
    amber: 'text-amber-300 bg-amber-500/10 border-amber-500/20',
    red: 'text-red-300 bg-red-500/10 border-red-500/20',
  };
  return (
    <div className="rounded-lg border border-border/60 bg-card/40 px-3 py-2">
      <div className="flex items-center justify-between mb-1">
        <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
          {icon}
          <span className="font-mono">{label}</span>
        </span>
        <span className="text-base font-bold font-mono">{count}</span>
      </div>
      <Badge variant="outline" className={`h-4 text-[9px] px-1 ${tones[riskTone]}`}>{risk}</Badge>
    </div>
  );
}
