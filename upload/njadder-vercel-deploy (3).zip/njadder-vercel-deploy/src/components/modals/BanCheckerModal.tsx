'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

export function BanCheckerModal() {
  const { isBanCheckerOpen, setBanCheckerOpen, accounts, removeAccount, updateAccount, addLog, language } = useStore();
  const [mode, setMode] = useState<'live' | 'static'>('live');
  const [dryRun, setDryRun] = useState(true);
  const [delay, setDelay] = useState('2.0');
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [bannedList, setBannedList] = useState<{ phone: string; reason: string }[]>([]);

  const totalAccounts = accounts.length;

  const startCheck = async () => {
    if (totalAccounts === 0) {
      toast.error(language === 'ar' ? 'لا توجد حسابات للفحص' : 'No accounts to check');
      return;
    }
    setRunning(true);
    setProgress(0);
    setBannedList([]);
    addLog({
      level: 'command',
      message: `[njadder] LIVE ban check — ${totalAccounts} accounts, mode=${mode}, dry_run=${dryRun}, delay=${delay}s`,
    });

    const banned: { phone: string; reason: string }[] = [];

    for (let i = 0; i < totalAccounts; i++) {
      const acc = accounts[i];
      await new Promise((r) => setTimeout(r, 500));

      // Simulated check — 10% chance of being banned
      const isBanned = Math.random() < 0.1;
      if (isBanned) {
        const reason = 'USER_DEACTIVATED_BAN';
        banned.push({ phone: acc.phone, reason });
        addLog({
          level: 'error',
          message: `[✗] Account ${acc.phone}: ${reason} — banned account detected`,
        });
        if (!dryRun) {
          removeAccount(acc.id);
        } else {
          updateAccount(acc.id, { status: 'banned' });
        }
      } else {
        addLog({
          level: 'success',
          message: `[✓] Account ${acc.phone}: OK`,
        });
      }

      setProgress(Math.round(((i + 1) / totalAccounts) * 100));
    }

    setBannedList(banned);
    addLog({
      level: banned.length > 0 ? 'warning' : 'success',
      message: `[njadder] Ban check complete: found ${banned.length} banned accounts${dryRun ? ' (dry-run — none removed)' : ' (removed from phone.csv)'}`,
    });

    setRunning(false);
    if (banned.length === 0) {
      toast.success(language === 'ar' ? 'لا توجد حسابات محظورة ✓' : 'No banned accounts ✓');
    } else {
      toast.warning(language === 'ar' ? `تم العثور على ${banned.length} حساب محظور` : `Found ${banned.length} banned accounts`);
    }
  };

  return (
    <Dialog open={isBanCheckerOpen} onOpenChange={setBanCheckerOpen}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icons.Ban className="h-5 w-5 text-red-400" />
            {language === 'ar' ? 'فاحص الحظر المباشر' : 'Live Ban Checker'}
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
              <Icons.Sparkles className="h-2.5 w-2.5 ml-0.5" /> v1.2.1
            </Badge>
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'فحص حقيقي لكل حساب عبر تسجيل الدخول فعلياً. يكتشف USER_DEACTIVATED_BAN تلقائياً.'
              : 'Actually login to each account and detect USER_DEACTIVATED_BAN automatically.'}
          </DialogDescription>
        </DialogHeader>

        {/* Mode selector */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setMode('live')}
            className={`rounded-lg border p-3 text-right transition-all ${mode === 'live' ? 'border-emerald-500/50 bg-emerald-500/10' : 'border-border/60 bg-card/40 hover:bg-card'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <Icons.RadioTower className={`h-4 w-4 ${mode === 'live' ? 'text-emerald-400' : 'text-muted-foreground'}`} />
              {mode === 'live' && <Badge variant="outline" className="h-4 text-[9px] px-1 bg-emerald-500/10 text-emerald-400 border-emerald-500/20">RECOMMENDED</Badge>}
            </div>
            <h4 className="text-xs font-semibold mb-0.5">{language === 'ar' ? 'فحص مباشر' : 'LIVE check'}</h4>
            <p className="text-[10px] text-muted-foreground">
              {language === 'ar' ? 'تسجيل دخول فعلي لكل حساب' : 'Actually login each account'}
            </p>
          </button>
          <button
            onClick={() => setMode('static')}
            className={`rounded-lg border p-3 text-right transition-all ${mode === 'static' ? 'border-amber-500/50 bg-amber-500/10' : 'border-border/60 bg-card/40 hover:bg-card'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <Icons.Database className={`h-4 w-4 ${mode === 'static' ? 'text-amber-400' : 'text-muted-foreground'}`} />
            </div>
            <h4 className="text-xs font-semibold mb-0.5">{language === 'ar' ? 'فلتر ثابت' : 'STATIC filter'}</h4>
            <p className="text-[10px] text-muted-foreground">
              {language === 'ar' ? 'استخدام BanNumbers.csv فقط' : 'Just use BanNumbers.csv'}
            </p>
          </button>
        </div>

        {/* Options */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card/40 px-3 py-2.5">
            <div>
              <Label className="text-xs font-medium cursor-pointer">
                {language === 'ar' ? 'تشغيل جاف (Dry-run)' : 'Dry-run'}
              </Label>
              <p className="text-[10px] text-muted-foreground">
                {language === 'ar' ? 'عدم حذف المحظورين' : "Don't delete banned"}
              </p>
            </div>
            <Switch checked={dryRun} onCheckedChange={setDryRun} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">{language === 'ar' ? 'التأخير (ثانية)' : 'Delay (sec)'}</Label>
            <Input type="number" value={delay} onChange={(e) => setDelay(e.target.value)} className="font-mono text-xs" />
          </div>
        </div>

        {/* Account count info */}
        <div className="rounded-lg border border-sky-500/20 bg-sky-500/5 p-3 flex items-start gap-2">
          <Icons.Info className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground leading-relaxed">
            {totalAccounts === 0
              ? (language === 'ar' ? 'لا توجد حسابات. أضف حسابات أولاً من نافذة إدارة الحسابات.' : 'No accounts. Add accounts first from the Accounts manager.')
              : (language === 'ar'
                ? `سيتم فحص ${totalAccounts} حساب. الوقت المتوقع: ~${Math.ceil(totalAccounts * parseFloat(delay))} ثانية.`
                : `Will check ${totalAccounts} accounts. Estimated time: ~${Math.ceil(totalAccounts * parseFloat(delay))}s.`)}
          </p>
        </div>

        {/* Progress */}
        {running && (
          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">
                {language === 'ar' ? `فحص الحسابات... (${progress}%)` : `Checking accounts... (${progress}%)`}
              </span>
              <Icons.Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
            </div>
            <Progress value={progress} className="h-1.5" />
          </div>
        )}

        {/* Banned accounts list */}
        {bannedList.length > 0 && (
          <div className="rounded-lg border border-red-500/30 bg-red-500/5 p-3">
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1.5 text-red-300">
              <Icons.Ban className="h-3.5 w-3.5" />
              {language === 'ar' ? `الحسابات المحظورة (${bannedList.length})` : `Banned Accounts (${bannedList.length})`}
            </h4>
            <ScrollArea className="h-32">
              {bannedList.map((b, i) => (
                <div key={i} className="flex items-center justify-between text-xs font-mono py-0.5">
                  <span className="text-red-300">{b.phone}</span>
                  <Badge variant="outline" className="h-4 text-[9px] px-1 bg-red-500/10 text-red-300 border-red-500/20">
                    {b.reason}
                  </Badge>
                </div>
              ))}
            </ScrollArea>
          </div>
        )}

        <DialogFooter>
          <Button variant="ghost" onClick={() => setBanCheckerOpen(false)}>
            {language === 'ar' ? 'إغلاق' : 'Close'}
          </Button>
          <Button
            onClick={startCheck}
            disabled={running || totalAccounts === 0}
            className="glow-primary bg-red-500 hover:bg-red-600"
          >
            {running ? <Icons.Loader2 className="h-3.5 w-3.5 ml-1.5 animate-spin" /> : <Icons.Ban className="h-3.5 w-3.5 ml-1.5" />}
            {language === 'ar' ? 'بدء الفحص المباشر' : 'Start Live Check'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
