'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

export function ProxyModal() {
  const {
    isProxyOpen, setProxyOpen, config, updateConfig,
    proxyList, addProxy, removeProxy, clearProxies, setProxyStatus,
    addLog, language,
  } = useStore();

  const [newLine, setNewLine] = useState('');
  const [testing, setTesting] = useState(false);

  const handleOpenChange = (open: boolean) => setProxyOpen(open);

  const testConfigProxy = async () => {
    setTesting(true);
    addLog({ level: 'info', message: `[njadder] ${language === 'ar' ? 'فحص البروكسي:' : 'Testing proxy:'} ${config.proxy_type}://${config.proxy_host}:${config.proxy_port}` });
    await new Promise((r) => setTimeout(r, 1500));
    const ok = Math.random() > 0.3;
    if (ok) {
      addLog({ level: 'success', message: `[✓] ${language === 'ar' ? 'البروكسي يعمل. زمن الاستجابة: 142ms' : 'Proxy works. Latency: 142ms'}` });
      toast.success(language === 'ar' ? 'البروكسي يعمل' : 'Proxy works');
    } else {
      addLog({ level: 'error', message: `[✗] ${language === 'ar' ? 'فشل الاتصال بالبروكسي' : 'Proxy connection failed'}` });
      toast.error(language === 'ar' ? 'فشل الاتصال' : 'Connection failed');
    }
    setTesting(false);
  };

  const testAllFromList = async () => {
    for (const p of proxyList) {
      setProxyStatus(p.id, 'testing');
      await new Promise((r) => setTimeout(r, 300));
      const ok = Math.random() > 0.4;
      setProxyStatus(p.id, ok ? 'ok' : 'failed');
      addLog({
        level: ok ? 'success' : 'error',
        message: `[${ok ? '✓' : '✗'}] ${p.type}://${p.host}:${p.port} ${ok ? 'OK' : 'FAILED'}`,
      });
    }
    toast.success(language === 'ar' ? 'اكتمل الفحص' : 'Test completed');
  };

  const addLine = () => {
    if (!newLine.trim()) return;
    addProxy(newLine.trim());
    addLog({ level: 'info', message: `[+] ${language === 'ar' ? 'تمت إضافة بروكسي:' : 'Added proxy:'} ${newLine.trim()}` });
    setNewLine('');
  };

  const createTemplate = () => {
    const template = `# proxy.txt template — supported formats:
# socks5://host:port
# socks5://user:pass@host:port
# http://host:port
# host:port
# user:pass@host:port
# host:port:type

socks5://127.0.0.1:1080
socks5://user:pass@1.2.3.4:1080
http://10.0.0.1:8080
192.168.1.1:1080:socks5
`;
    const blob = new Blob([template], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'proxy.txt';
    a.click();
    URL.revokeObjectURL(url);
    toast.success(language === 'ar' ? 'تم تنزيل القالب' : 'Template downloaded');
  };

  return (
    <Dialog open={isProxyOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icons.ShieldCheck className="h-5 w-5 text-primary" />
            {language === 'ar' ? 'مدير البروكسي — طبقة الأمان' : 'Proxy Manager — Security Layer'}
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'إدارة بروكسي تيليجرام [NJaddingZone].proxy_* — يُطبّق تلقائياً على كل عميل pyrogram.'
              : 'Telegram proxy management [NJaddingZone].proxy_* — auto-applied to every pyrogram client.'}
          </DialogDescription>
        </DialogHeader>

        {/* Status overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <StatCard
            icon={<Icons.Power className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'الحالة' : 'Status'}
            value={config.proxy_enabled ? (language === 'ar' ? 'مفعّل' : 'ON') : (language === 'ar' ? 'معطّل' : 'OFF')}
            tone={config.proxy_enabled ? 'emerald' : 'muted'}
          />
          <StatCard
            icon={<Icons.Layers className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'النوع' : 'Type'}
            value={config.proxy_type}
            tone="sky"
          />
          <StatCard
            icon={<Icons.Globe className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'المضيف' : 'Host'}
            value={`${config.proxy_host}:${config.proxy_port}`}
            tone="violet"
          />
          <StatCard
            icon={<Icons.ListChecks className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'proxy.txt' : 'proxy.txt'}
            value={proxyList.length.toString()}
            tone="amber"
          />
        </div>

        <Tabs defaultValue="config" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="config" className="text-xs">
              <Icons.Settings2 className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'الإعدادات' : 'config.ini'}
            </TabsTrigger>
            <TabsTrigger value="file" className="text-xs">
              <Icons.FileText className="h-3.5 w-3.5 ml-1.5" />
              {language === 'ar' ? 'ملف البروكسي' : 'proxy.txt'}
            </TabsTrigger>
          </TabsList>

          {/* Config tab */}
          <TabsContent value="config" className="space-y-4 mt-4">
            <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card/40 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <Icons.Power className="h-4 w-4 text-primary" />
                <div>
                  <Label className="text-xs font-medium cursor-pointer">
                    {language === 'ar' ? 'تفعيل البروكسي (proxy_enabled)' : 'Enable Proxy (proxy_enabled)'}
                  </Label>
                  <p className="text-[10px] text-muted-foreground">
                    {language === 'ar' ? 'يُطبّق على كل Client(...)' : 'Applied to every Client()'}
                  </p>
                </div>
              </div>
              <Switch
                checked={config.proxy_enabled}
                onCheckedChange={(c) => updateConfig({ proxy_enabled: c })}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">{language === 'ar' ? 'النوع (proxy_type)' : 'Type (proxy_type)'}</Label>
                <Select value={config.proxy_type} onValueChange={(v) => updateConfig({ proxy_type: v as any })}>
                  <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="socks5">socks5</SelectItem>
                    <SelectItem value="socks4">socks4</SelectItem>
                    <SelectItem value="http">http</SelectItem>
                    <SelectItem value="mtproto">mtproto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">{language === 'ar' ? 'المنفذ' : 'Port'}</Label>
                <Input type="number" value={config.proxy_port} onChange={(e) => updateConfig({ proxy_port: e.target.value })} className="font-mono text-xs" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs font-medium">{language === 'ar' ? 'المضيف (proxy_host)' : 'Host (proxy_host)'}</Label>
                <Input value={config.proxy_host} onChange={(e) => updateConfig({ proxy_host: e.target.value })} className="font-mono text-xs" placeholder="127.0.0.1" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">{language === 'ar' ? 'اسم المستخدم' : 'Username'}</Label>
                <Input value={config.proxy_username} onChange={(e) => updateConfig({ proxy_username: e.target.value })} className="font-mono text-xs" placeholder="(optional)" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">{language === 'ar' ? 'كلمة المرور' : 'Password'}</Label>
                <Input type="password" value={config.proxy_password} onChange={(e) => updateConfig({ proxy_password: e.target.value })} className="font-mono text-xs" placeholder="(optional)" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={testConfigProxy} disabled={testing} className="glow-primary">
                {testing ? <Icons.Loader2 className="h-3.5 w-3.5 ml-1.5 animate-spin" /> : <Icons.Zap className="h-3.5 w-3.5 ml-1.5" />}
                {language === 'ar' ? 'فحص البروكسي' : 'Test Proxy'}
              </Button>
            </div>
          </TabsContent>

          {/* Proxy file tab */}
          <TabsContent value="file" className="space-y-3 mt-4">
            <div className="flex items-center gap-2">
              <Input
                value={newLine}
                onChange={(e) => setNewLine(e.target.value)}
                placeholder="socks5://host:port  أو  host:port:type"
                className="font-mono text-xs"
                onKeyDown={(e) => { if (e.key === 'Enter') addLine(); }}
              />
              <Button onClick={addLine} size="icon" className="shrink-0">
                <Icons.Plus className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={testAllFromList} disabled={proxyList.length === 0}>
                <Icons.Zap className="h-3.5 w-3.5 ml-1.5" />
                {language === 'ar' ? 'فحص الكل' : 'Test All'}
              </Button>
              <Button variant="outline" size="sm" onClick={createTemplate}>
                <Icons.FileDown className="h-3.5 w-3.5 ml-1.5" />
                {language === 'ar' ? 'تنزيل قالب' : 'Template'}
              </Button>
              {proxyList.length > 0 && (
                <Button variant="ghost" size="sm" onClick={clearProxies} className="text-red-400">
                  <Icons.Trash2 className="h-3.5 w-3.5 ml-1.5" />
                  {language === 'ar' ? 'مسح الكل' : 'Clear All'}
                </Button>
              )}
            </div>

            <ScrollArea className="h-64 rounded-lg border border-border/40 bg-[#0a0f1a]">
              {proxyList.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center p-6">
                  <Icons.FileText className="h-8 w-8 text-muted-foreground/40 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {language === 'ar' ? 'لا توجد بروكسيات بعد — أضف واحداً بالأعلى' : 'No proxies yet — add one above'}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border/30">
                  {proxyList.map((p) => (
                    <div key={p.id} className="flex items-center justify-between gap-2 px-3 py-2 hover:bg-white/2">
                      <div className="flex items-center gap-2 min-w-0">
                        <StatusDot status={p.status} />
                        <span className="font-mono text-[11px] truncate">
                          <span className="text-violet-400">{p.type}</span>://{p.host}<span className="text-muted-foreground">:{p.port}</span>
                          {p.username && <span className="text-muted-foreground/60">  ({p.username})</span>}
                        </span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => removeProxy(p.id)}>
                        <Icons.X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>

            <div className="rounded-lg border border-sky-500/20 bg-sky-500/5 p-3">
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                <strong className="text-sky-400">{language === 'ar' ? 'الصيغ المدعومة:' : 'Supported formats:'}</strong>
                <br />
                <code className="font-mono text-[10px]">socks5://host:port</code> · <code className="font-mono text-[10px]">socks5://user:pass@host:port</code> · <code className="font-mono text-[10px]">host:port</code> · <code className="font-mono text-[10px]">host:port:type</code>
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Badge variant="outline" className="text-[10px] font-mono mr-auto">[NJaddingZone].proxy_*</Badge>
          <Button onClick={() => setProxyOpen(false)} className="glow-primary">
            <Icons.Check className="h-3.5 w-3.5 ml-1.5" />
            {language === 'ar' ? 'تم' : 'Done'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StatCard({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone: 'emerald' | 'muted' | 'sky' | 'violet' | 'amber' }) {
  const tones: Record<string, string> = {
    emerald: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20',
    muted: 'bg-muted text-muted-foreground border-border',
    sky: 'bg-sky-500/10 text-sky-300 border-sky-500/20',
    violet: 'bg-violet-500/10 text-violet-300 border-violet-500/20',
    amber: 'bg-amber-500/10 text-amber-300 border-amber-500/20',
  };
  return (
    <div className={`rounded-lg border px-2.5 py-2 ${tones[tone]}`}>
      <div className="flex items-center gap-1 text-[10px] opacity-80">
        {icon}
        <span>{label}</span>
      </div>
      <div className="mt-0.5 text-xs font-mono font-semibold truncate">{value}</div>
    </div>
  );
}

function StatusDot({ status }: { status?: 'idle' | 'testing' | 'ok' | 'failed' }) {
  if (status === 'testing') return <Icons.Loader2 className="h-3 w-3 text-amber-400 animate-spin shrink-0" />;
  if (status === 'ok') return <Icons.CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />;
  if (status === 'failed') return <Icons.XCircle className="h-3 w-3 text-red-400 shrink-0" />;
  return <Icons.Circle className="h-3 w-3 text-muted-foreground/40 shrink-0" />;
}
