'use client';

import * as Icons from 'lucide-react';
import { categories, commands } from '@/lib/commands';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

export function Sidebar() {
  const { activeCategory, setCategory, language } = useStore();

  const totalCommands = commands.length;

  return (
    <aside className="hidden md:flex w-64 shrink-0 flex-col border-l border-border/40 bg-sidebar/50 backdrop-blur-sm">
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-border/40">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-soft-pulse" />
          <span className="text-xs font-semibold text-muted-foreground">
            {language === 'ar' ? 'الفئات' : 'Categories'}
          </span>
        </div>
        <Badge variant="secondary" className="text-[10px] font-mono">{totalCommands}</Badge>
      </div>

      <ScrollArea className="flex-1 px-2 py-2">
        <nav className="flex flex-col gap-1">
          {categories.map((cat) => {
            const count = commands.filter((c) => c.category === cat.id).length;
            const Icon = (Icons as any)[cat.icon] || Icons.Square;
            const active = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={cn(
                  'group relative flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
                  'hover:bg-accent/60',
                  active && 'bg-gradient-to-l from-primary/20 to-primary/5 text-primary border border-primary/30'
                )}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className={cn(
                    'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors',
                    active ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground group-hover:text-foreground'
                  )}>
                    <Icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0">
                    <div className="truncate text-xs leading-tight">
                      {language === 'ar' ? cat.labelAr : cat.label}
                    </div>
                  </div>
                </div>
                <span className={cn(
                  'text-[10px] font-mono px-1.5 py-0.5 rounded',
                  active ? 'bg-primary/20 text-primary' : 'text-muted-foreground/60'
                )}>
                  {count}
                </span>
                {active && (
                  <span className="absolute -left-2 top-1/2 -translate-y-1/2 h-6 w-1 rounded-full bg-primary" />
                )}
              </button>
            );
          })}
        </nav>
      </ScrollArea>

      <div className="border-t border-border/40 px-4 py-3">
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground/70">
          <Icons.Crown className="h-3.5 w-3.5 text-amber-400" />
          <span className="truncate">{language === 'ar' ? 'النسخة الذهبية v6.0' : 'Golden Build v6.0'}</span>
        </div>
        <p className="mt-1 text-[10px] text-muted-foreground/60 font-mono truncate">
          @NMDDER_DEV · @NMDDER_SUPPORT
        </p>
      </div>
    </aside>
  );
}

export function MobileCategoryBar() {
  const { activeCategory, setCategory, language } = useStore();
  return (
    <div className="md:hidden border-b border-border/40 bg-sidebar/50 backdrop-blur-sm">
      <ScrollArea className="w-full overflow-x-auto">
        <div className="flex gap-1.5 px-3 py-2 min-w-max">
          {categories.map((cat) => {
            const Icon = (Icons as any)[cat.icon] || Icons.Square;
            const active = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={cn(
                  'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs whitespace-nowrap transition-colors',
                  active ? 'bg-primary text-primary-foreground' : 'bg-muted/50 text-muted-foreground hover:bg-muted'
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {language === 'ar' ? cat.labelAr : cat.label}
              </button>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}
