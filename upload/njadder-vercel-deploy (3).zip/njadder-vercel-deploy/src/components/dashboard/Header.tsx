'use client';

import { Activity, Globe, LogOut, Settings, Shield, ShieldCheck, Users, Ban } from 'lucide-react';
import { useSession, signOut } from 'next-auth/react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { PWAStatusButton } from '@/components/pwa/PWAStatusButton';

export function Header() {
  const {
    language, toggleLanguage, setConfigOpen, setProxyOpen, setAccountsOpen,
    setSecureLoginOpen, setBanCheckerOpen, accounts, config, runningTasks,
  } = useStore();
  const { data: session } = useSession();

  const activeTasks = runningTasks.filter((t) => t.status === 'running').length;
  const loggedInAccounts = accounts.filter((a) => a.status === 'logged_in').length;
  const proxyOn = config.proxy_enabled;

  const userInitials = session?.user?.email?.slice(0, 2).toUpperCase() ?? '??';
  const userName = session?.user?.name || session?.user?.email || (language === 'ar' ? 'مستخدم' : 'User');

  return (
    <header className="sticky top-0 z-30 border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-between px-4 md:px-6 gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl bg-gradient-to-br from-[#229ED9] to-[#2AABEE] flex items-center justify-center glow-primary">
            <svg viewBox="0 0 24 24" className="h-6 w-6 text-white" fill="currentColor">
              <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
            </svg>
          </div>
          <div className="min-w-0">
            <h1 className="text-base md:text-lg font-bold leading-tight tracking-tight truncate">
              {language === 'ar' ? 'njadder — أداة تيليجرام الموحدة' : 'njadder — Unified Telegram Tool'}
            </h1>
            <p className="text-[10px] md:text-xs text-muted-foreground truncate">
              v1.2.1 Professional Edition · {language === 'ar' ? 'المطور' : 'Dev'}: <span className="text-primary font-mono">@NMDDER_DEV</span>
            </p>
          </div>
        </div>

        {/* Status indicators */}
        <div className="hidden lg:flex items-center gap-2">
          <StatusPill
            icon={<Users className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'الحسابات' : 'Accounts'}
            value={`${loggedInAccounts}/${accounts.length}`}
            tone="sky"
          />
          <StatusPill
            icon={<Shield className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'البروكسي' : 'Proxy'}
            value={proxyOn ? (language === 'ar' ? 'مفعّل' : 'ON') : (language === 'ar' ? 'معطّل' : 'OFF')}
            tone={proxyOn ? 'emerald' : 'muted'}
          />
          <StatusPill
            icon={<Activity className="h-3.5 w-3.5" />}
            label={language === 'ar' ? 'المهام' : 'Tasks'}
            value={activeTasks.toString()}
            tone={activeTasks > 0 ? 'amber' : 'muted'}
          />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="text-xs font-semibold"
            title="Switch language"
          >
            <Globe className="h-4 w-4 ml-1.5" />
            {language === 'ar' ? 'EN' : 'ع'}
          </Button>
          <PWAStatusButton />
          {/* NEW v1.2.1 quick actions */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSecureLoginOpen(true)}
            title={language === 'ar' ? 'دخول آمن (CSV Rotation)' : 'Secure Login (CSV)'}
            className="text-emerald-400 hover:text-emerald-300"
          >
            <ShieldCheck className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setBanCheckerOpen(true)}
            title={language === 'ar' ? 'فاحص الحظر المباشر' : 'Live Ban Checker'}
            className="text-red-400 hover:text-red-300"
          >
            <Ban className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setAccountsOpen(true)} title={language === 'ar' ? 'الحسابات' : 'Accounts'}>
            <Users className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setProxyOpen(true)} title={language === 'ar' ? 'مدير البروكسي' : 'Proxy Manager'}>
            <Shield className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setConfigOpen(true)} title={language === 'ar' ? 'الإعدادات' : 'Settings'}>
            <Settings className="h-4 w-4" />
          </Button>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-9 px-1.5 gap-2 hover:bg-accent" title={userName as string}>
                <Avatar className="h-7 w-7">
                  <AvatarFallback className="bg-gradient-to-br from-[#229ED9] to-[#2AABEE] text-white text-xs font-bold">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden sm:inline text-xs font-medium max-w-[120px] truncate">
                  {userName}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{session?.user?.name || (language === 'ar' ? 'مستخدم' : 'User')}</p>
                  <p className="text-xs leading-none text-muted-foreground truncate">{session?.user?.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-red-400 focus:text-red-300 focus:bg-red-500/10 cursor-pointer"
                onClick={() => signOut({ callbackUrl: '/' })}
              >
                <LogOut className="h-3.5 w-3.5 ml-2" />
                {language === 'ar' ? 'تسجيل الخروج' : 'Sign out'}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}

function StatusPill({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: 'sky' | 'emerald' | 'amber' | 'muted' | 'red';
}) {
  const tones: Record<string, string> = {
    sky: 'bg-sky-500/10 text-sky-300 border-sky-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-300 border-amber-500/20',
    muted: 'bg-muted text-muted-foreground border-border',
    red: 'bg-red-500/10 text-red-300 border-red-500/20',
  };
  return (
    <div className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs ${tones[tone]}`}>
      {icon}
      <span className="text-muted-foreground/80">{label}</span>
      <Badge variant="outline" className="px-1.5 py-0 h-4 text-[10px] border-transparent bg-transparent">{value}</Badge>
    </div>
  );
}

