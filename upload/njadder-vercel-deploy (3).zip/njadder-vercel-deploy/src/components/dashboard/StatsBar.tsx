'use client';

import * as Icons from 'lucide-react';
import { categories, commands } from '@/lib/commands';
import { useStore } from '@/lib/store';

export function StatsBar() {
  const { language, accounts, config, runningTasks } = useStore();

  const total = commands.length;
  const newFeatures = commands.filter((c) => c.newFeature).length;
  const danger = commands.filter((c) => c.danger).length;
  const premium = commands.filter((c) => c.premium).length;
  const activeTasks = runningTasks.filter((t) => t.status === 'running').length;
  const activeAccounts = accounts.filter((a) => a.status === 'logged_in').length;
  const proxyOn = config.proxy_enabled;

  const stats = [
    { label: language === 'ar' ? 'إجمالي الأوامر' : 'Total Commands', value: total, icon: Icons.Command, tone: 'sky' },
    { label: language === 'ar' ? 'الفئات' : 'Categories', value: categories.length, icon: Icons.FolderTree, tone: 'violet' },
    { label: language === 'ar' ? 'ميزات جديدة v1.2' : 'New v1.2 Features', value: newFeatures, icon: Icons.Sparkles, tone: 'emerald' },
    { label: language === 'ar' ? 'محفوفة بالمخاطر' : 'Risky', value: danger, icon: Icons.AlertTriangle, tone: 'red' },
    { label: language === 'ar' ? 'الحسابات النشطة' : 'Active Accounts', value: activeAccounts, icon: Icons.UserCheck, tone: 'amber' },
    { label: language === 'ar' ? 'مهام نشطة' : 'Running Tasks', value: activeTasks, icon: Icons.Activity, tone: proxyOn ? 'pink' : 'muted' },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 p-3 md:p-4 border-b border-border/40 bg-card/20">
      {stats.map((s) => {
        const Icon = s.icon;
        const tones: Record<string, string> = {
          sky: 'text-sky-400 bg-sky-500/10',
          violet: 'text-violet-400 bg-violet-500/10',
          amber: 'text-amber-400 bg-amber-500/10',
          red: 'text-red-400 bg-red-500/10',
          emerald: 'text-emerald-400 bg-emerald-500/10',
          pink: 'text-pink-400 bg-pink-500/10',
          muted: 'text-muted-foreground bg-muted',
        };
        return (
          <div key={s.label} className="rounded-lg border border-border/40 bg-card/40 px-2.5 py-2 flex items-center gap-2">
            <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-md ${tones[s.tone]}`}>
              <Icon className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <div className="text-[10px] text-muted-foreground truncate">{s.label}</div>
              <div className="text-sm font-bold font-mono">{s.value}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
