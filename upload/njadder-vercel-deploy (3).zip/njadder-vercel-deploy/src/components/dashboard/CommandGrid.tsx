'use client';

import * as Icons from 'lucide-react';
import { useMemo, useState } from 'react';
import { categories, commands, getCommandsByCategory, type Command } from '@/lib/commands';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CommandRunner } from './CommandRunner';

export function CommandGrid() {
  const { activeCategory, language, search, setSearch } = useStore();
  const [selected, setSelected] = useState<Command | null>(null);

  const cat = categories.find((c) => c.id === activeCategory)!;
  const list = useMemo(() => {
    let l = getCommandsByCategory(activeCategory);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      l = commands.filter((c) =>
        c.name.toLowerCase().includes(q) ||
        c.nameAr.includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.descriptionAr.includes(q) ||
        String(c.id) === q
      );
    }
    return l;
  }, [activeCategory, search]);

  const Icon = (Icons as any)[cat?.icon] || Icons.Square;

  if (selected) {
    return <CommandRunner command={selected} onClose={() => setSelected(null)} />;
  }

  return (
    <div className="flex flex-1 flex-col min-w-0">
      {/* Category header */}
      <div className="border-b border-border/40 px-4 md:px-6 py-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary/30 to-primary/10 border border-primary/30">
              <Icon className="h-5 w-5 text-primary" />
            </span>
            <div>
              <h2 className="text-lg md:text-xl font-bold tracking-tight">
                {language === 'ar' ? cat.labelAr : cat.label}
              </h2>
              <p className="text-xs text-muted-foreground">
                {list.length} {language === 'ar' ? 'أمر متاح' : 'commands available'}
              </p>
            </div>
          </div>

          <div className="relative w-full sm:w-64">
            <Icons.Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={language === 'ar' ? 'ابحث عن أمر...' : 'Search commands...'}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-9"
            />
          </div>
        </div>
      </div>

      {/* Command grid */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-grid">
      {list.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-20">
            <Icons.SearchX className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-sm text-muted-foreground">
              {language === 'ar' ? 'لا توجد أوامر مطابقة' : 'No matching commands'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {list.map((cmd) => {
              const CmdIcon = (Icons as any)[cmd.icon] || Icons.Square;
              return (
                <button
                  key={cmd.id}
                  onClick={() => setSelected(cmd)}
                  className={cn(
                    'group relative text-right rounded-xl border bg-card/60 hover:bg-card transition-all overflow-hidden',
                    'border-border/60 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5',
                    cmd.danger && 'hover:border-red-500/40 hover:shadow-red-500/5'
                  )}
                >
                  <div className="absolute top-0 right-0 left-0 h-0.5 bg-gradient-to-l from-primary/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2.5">
                      <span className={cn(
                        'flex h-9 w-9 items-center justify-center rounded-lg transition-colors',
                        cmd.danger
                          ? 'bg-red-500/10 text-red-400 group-hover:bg-red-500/20'
                          : cmd.premium
                          ? 'bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20'
                          : 'bg-primary/10 text-primary group-hover:bg-primary/20'
                      )}>
                        <CmdIcon className="h-4.5 w-4.5" />
                      </span>
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] font-mono text-muted-foreground/60">#{cmd.id}</span>
                        {cmd.newFeature && (
                          <Badge variant="outline" className="h-4 text-[9px] px-1 gap-0.5 bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                            <Icons.Sparkles className="h-2.5 w-2.5" /> NEW
                          </Badge>
                        )}
                        {cmd.premium && (
                          <Badge variant="outline" className="h-4 text-[9px] px-1 gap-0.5 bg-amber-500/10 text-amber-400 border-amber-500/20">
                            <Icons.Crown className="h-2.5 w-2.5" /> PRO
                          </Badge>
                        )}
                        {cmd.danger && (
                          <Badge variant="outline" className="h-4 text-[9px] px-1 bg-red-500/10 text-red-400 border-red-500/20">
                            !
                          </Badge>
                        )}
                      </div>
                    </div>

                    <h3 className="text-sm font-semibold mb-1 line-clamp-1">
                      {language === 'ar' ? cmd.nameAr : cmd.name}
                    </h3>
                    <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed">
                      {language === 'ar' ? cmd.descriptionAr : cmd.description}
                    </p>

                    {cmd.params && cmd.params.length > 0 && (
                      <div className="mt-2.5 flex items-center gap-1 text-[10px] text-muted-foreground/70">
                        <Icons.Settings2 className="h-3 w-3" />
                        {cmd.params.length} {language === 'ar' ? 'مدخل' : 'inputs'}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
