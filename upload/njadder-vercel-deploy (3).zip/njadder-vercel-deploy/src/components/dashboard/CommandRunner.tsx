'use client';

import * as Icons from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { Command, CommandParam } from '@/lib/commands';
import { useStore, type RunningTask } from '@/lib/store';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';

export function CommandRunner({ command, onClose }: { command: Command; onClose: () => void }) {
  const { language, addLog, startTask, updateTask, removeTask, config, proxy } = useStore();

  // Compute initial values from command params + global config — no setState in effect needed
  const initialValues = useMemo(() => {
    const initial: Record<string, string> = {};
    command.params?.forEach((p) => {
      if (p.type === 'boolean') {
        initial[p.key] = p.default === false ? 'false' : 'true';
      } else if (p.default !== undefined) {
        initial[p.key] = p.default;
      } else {
        const ck = p.key as keyof typeof config;
        if (config[ck]) initial[p.key] = config[ck] as string;
      }
    });
    return initial;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [command]);

  const [values, setValues] = useState<Record<string, string>>(initialValues);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [output, setOutput] = useState<string[]>([]);
  const outputRef = useRef<HTMLDivElement>(null);
  const cancelRef = useRef(false);

  // Reset state when command changes
  useEffect(() => {
    setValues(initialValues);
    setRunning(false);
    setProgress(0);
    setOutput([]);
  }, [initialValues]);

  // Auto-scroll output
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const setVal = (k: string, v: string) => setValues((s) => ({ ...s, [k]: v }));

  const validate = (): boolean => {
    if (!command.params) return true;
    for (const p of command.params) {
      if ('required' in p && p.required) {
        if (!values[p.key] || values[p.key].trim() === '') return false;
      }
    }
    return true;
  };

  const appendOutput = (line: string) => {
    setOutput((o) => [...o, line]);
  };

  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  const run = async () => {
    if (!validate()) {
      addLog({
        level: 'error',
        message: `[!] ${language === 'ar' ? 'يرجى ملء جميع الحقول المطلوبة' : 'Please fill all required fields'}`,
        commandId: command.id,
        commandName: command.name,
      });
      return;
    }
    cancelRef.current = false;
    setRunning(true);
    setProgress(0);
    setOutput([]);

    const taskId = crypto.randomUUID();
    const task: RunningTask = {
      id: taskId,
      commandId: command.id,
      commandName: command.name,
      status: 'running',
      progress: 0,
      startedAt: new Date().toISOString(),
      params: values,
    };
    startTask(task);

    addLog({
      level: 'command',
      message: `[>] ${language === 'ar' ? 'بدء تنفيذ' : 'Starting'} #${command.id} ${command.name} ${language === 'ar' ? '— البارامترات:' : '— params:'} ${JSON.stringify(values)}`,
      commandId: command.id,
      commandName: command.name,
    });
    appendOutput(`\x1b[36m[GB]\x1b[0m Initializing ${command.name}...`);

    // Simulated execution steps based on command category
    const steps = buildExecutionSteps(command);
    for (let i = 0; i < steps.length; i++) {
      if (cancelRef.current) break;
      appendOutput(steps[i].text);
      addLog({
        level: steps[i].level,
        message: steps[i].text.replace(/\x1b\[\d+m/g, ''),
        commandId: command.id,
        commandName: command.name,
      });
      await sleep(280 + Math.random() * 520);
      const newProgress = Math.round(((i + 1) / steps.length) * 100);
      setProgress(newProgress);
      updateTask(taskId, { progress: newProgress });
    }

    if (!cancelRef.current) {
      const successMsg = `\x1b[32m[✓]\x1b[0m ${language === 'ar' ? 'اكتمل' : 'Completed'}: ${command.name} — ${language === 'ar' ? 'النتيجة:' : 'result:'} ${summarizeResult(command)}`;
      appendOutput(successMsg);
      addLog({
        level: 'success',
        message: `[✓] ${command.name} ${language === 'ar' ? '— اكتمل بنجاح' : '— completed successfully'}`,
        commandId: command.id,
        commandName: command.name,
      });
      updateTask(taskId, { status: 'completed', progress: 100 });
      setTimeout(() => removeTask(taskId), 5000);
    } else {
      appendOutput(`\x1b[33m[!]\x1b[0m ${language === 'ar' ? 'تم الإلغاء بواسطة المستخدم' : 'Cancelled by user'}`);
      updateTask(taskId, { status: 'failed', progress });
    }

    setRunning(false);
  };

  const cancel = () => {
    cancelRef.current = true;
  };

  const CmdIcon = (Icons as any)[command.icon] || Icons.Square;

  return (
    <div className="flex flex-1 flex-col min-w-0">
      {/* Header */}
      <div className="border-b border-border/40 px-4 md:px-6 py-4 bg-card/30">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <Button variant="ghost" size="icon" onClick={onClose} className="shrink-0">
              <Icons.ArrowRight className="h-4 w-4" />
            </Button>
            <span className={cn(
              'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
              command.danger ? 'bg-red-500/10 text-red-400' : command.premium ? 'bg-amber-500/10 text-amber-400' : 'bg-primary/10 text-primary'
            )}>
              <CmdIcon className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base md:text-lg font-bold truncate">
                  {language === 'ar' ? command.nameAr : command.name}
                </h2>
                <Badge variant="outline" className="font-mono text-[10px]">#{command.id}</Badge>
              </div>
              <p className="text-xs text-muted-foreground truncate">
                {language === 'ar' ? command.descriptionAr : command.description}
              </p>
            </div>
          </div>

          {command.danger && (
            <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30 shrink-0">
              <Icons.AlertTriangle className="h-3 w-3 ml-1" />
              {language === 'ar' ? 'محفوف بالمخاطر' : 'Risky'}
            </Badge>
          )}
          {command.premium && !command.danger && (
            <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30 shrink-0">
              <Icons.Crown className="h-3 w-3 ml-1" />
              {language === 'ar' ? 'مميز' : 'Premium'}
            </Badge>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-grid">
        <div className="mx-auto max-w-3xl space-y-5">
          {/* Params form */}
          {command.params && command.params.length > 0 && (
            <div className="rounded-xl border border-border/60 bg-card/60 p-4 md:p-5">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Icons.Settings2 className="h-4 w-4 text-primary" />
                {language === 'ar' ? 'الإعدادات' : 'Parameters'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {command.params.map((p) => (
                  <ParamField
                    key={p.key}
                    param={p}
                    value={values[p.key] ?? ''}
                    onChange={(v) => setVal(p.key, v)}
                    language={language}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3">
            {!running ? (
              <Button onClick={run} size="lg" className="glow-primary font-semibold">
                <Icons.Play className="h-4 w-4 ml-2" />
                {language === 'ar' ? 'تشغيل الأمر' : 'Run Command'}
              </Button>
            ) : (
              <Button onClick={cancel} variant="destructive" size="lg">
                <Icons.Square className="h-4 w-4 ml-2" />
                {language === 'ar' ? 'إيقاف' : 'Stop'}
              </Button>
            )}
            <Button variant="ghost" size="lg" onClick={onClose} disabled={running}>
              {language === 'ar' ? 'رجوع' : 'Back'}
            </Button>
            {proxy.proxy_enabled && (
              <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                <Icons.Shield className="h-3 w-3 ml-1" />
                {language === 'ar' ? 'محمي بالبروكسي' : 'Protected via Proxy'}
              </Badge>
            )}
          </div>

          {/* Progress */}
          {(running || progress > 0) && (
            <div className="rounded-xl border border-border/60 bg-card/60 p-4 md:p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-muted-foreground">
                  {language === 'ar' ? 'التقدّم' : 'Progress'}
                </span>
                <span className="text-xs font-mono text-primary">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {/* Output console */}
          <div className="rounded-xl border border-border/60 bg-[#0a0f1a] overflow-hidden">
            <div className="flex items-center justify-between px-3 py-2 border-b border-border/40 bg-card/40">
              <div className="flex items-center gap-2">
                <Icons.Terminal className="h-3.5 w-3.5 text-primary" />
                <span className="text-xs font-semibold">{language === 'ar' ? 'سجل التنفيذ' : 'Execution Log'}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-red-500/60" />
                <span className="h-2 w-2 rounded-full bg-amber-500/60" />
                <span className="h-2 w-2 rounded-full bg-emerald-500/60" />
              </div>
            </div>
            <ScrollArea className="h-72">
              <div ref={outputRef} className="p-3 font-mono text-xs leading-relaxed whitespace-pre-wrap" dir="ltr">
                {output.length === 0 ? (
                  <span className="text-muted-foreground/50 terminal-cursor">
                    {language === 'ar' ? 'بانتظار بدء التنفيذ...' : 'Awaiting execution...'}
                  </span>
                ) : (
                  output.map((line, i) => (
                    <div key={i} className={cn('py-0.5', line.includes('[✓]') && 'text-emerald-400', line.includes('[!]') && 'text-amber-400', line.includes('[GB]') && 'text-sky-400')}>
                      {line.replace(/\x1b\[\d+m/g, '')}
                    </div>
                  ))
                )}
                {running && <div className="terminal-cursor text-primary" />}
              </div>
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  );
}

function ParamField({
  param,
  value,
  onChange,
  language,
}: {
  param: CommandParam;
  value: string;
  onChange: (v: string) => void;
  language: 'ar' | 'en';
}) {
  const label = language === 'ar' ? param.labelAr : param.label;
  const placeholder = 'placeholder' in param ? param.placeholder : '';

  if (param.type === 'boolean') {
    return (
      <div className="flex items-center justify-between rounded-lg border border-border/60 bg-background/30 px-3 py-2.5 sm:col-span-2">
        <Label htmlFor={param.key} className="text-xs font-medium cursor-pointer">
          {label}
          {'required' in param && param.required && <span className="text-red-400 mr-1">*</span>}
        </Label>
        <Switch
          id={param.key}
          checked={value === 'true'}
          onCheckedChange={(c) => onChange(c ? 'true' : 'false')}
        />
      </div>
    );
  }

  if (param.type === 'textarea') {
    return (
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor={param.key} className="text-xs font-medium">
          {label}
          {'required' in param && param.required && <span className="text-red-400 mr-1">*</span>}
        </Label>
        <Textarea
          id={param.key}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="font-mono text-xs min-h-[80px] resize-y"
        />
      </div>
    );
  }

  if (param.type === 'select' && 'options' in param && param.options) {
    return (
      <div className="space-y-1.5">
        <Label className="text-xs font-medium">
          {label}
          {'required' in param && param.required && <span className="text-red-400 mr-1">*</span>}
        </Label>
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger className="text-xs">
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            {param.options.map((o) => (
              <SelectItem key={o} value={o} className="text-xs">{o}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    );
  }

  if (param.type === 'file') {
    return (
      <div className="space-y-1.5">
        <Label htmlFor={param.key} className="text-xs font-medium">
          {label}
          {'required' in param && param.required && <span className="text-red-400 mr-1">*</span>}
        </Label>
        <div className="flex items-center gap-2">
          <Input
            id={param.key}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder || (language === 'ar' ? 'مسار الملف' : 'File path')}
            className="font-mono text-xs"
          />
          <Button type="button" variant="outline" size="icon" className="shrink-0">
            <Icons.FolderOpen className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <Label htmlFor={param.key} className="text-xs font-medium">
        {label}
        {'required' in param && param.required && <span className="text-red-400 mr-1">*</span>}
      </Label>
      <Input
        id={param.key}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        type={param.type === 'number' ? 'number' : 'text'}
        className="text-xs"
      />
    </div>
  );
}

// ----- Simulated execution steps (njadder v1.2.1 patterns) -----
function buildExecutionSteps(cmd: Command): { text: string; level: 'info' | 'success' | 'warning' | 'error' | 'command' }[] {
  const ts = () => new Date().toISOString().slice(11, 19);
  const T = (lvl: 'info' | 'success' | 'warning' | 'error' | 'command', msg: string) =>
    ({ text: `[njadder] [${ts()}] ${msg}`, level: lvl });

  // ACCOUNTS — Secure Login (most important new feature)
  if (cmd.id === 'accounts.2') {
    return [
      T('info', 'Loading Secure Login resources...'),
      T('info', 'Reading api.csv (10 APIs), devices.csv (10 devices), proxies.csv (10 proxies)'),
      T('info', 'Pre-flight check: testing all proxies...'),
      T('success', '8/10 proxies healthy · 2 dead (will failover)'),
      T('info', 'Resource distribution: 100 accounts ÷ 10 APIs = 10 accounts/API'),
      T('info', 'Round-robin assignment starting...'),
      T('info', 'Account #1 (+9665XXX) → api_id=••••1234, device=iPhone 14 Pro, proxy=socks5://1.2.3.4:1080'),
      T('success', 'Account #1: code sent → OTP received → session saved'),
      T('info', 'Account #2 → api_id=••••5678, device=Samsung S23 Ultra, proxy=socks5://5.6.7.8:1080'),
      T('success', 'Account #2: session saved'),
      T('warning', 'Account #3: proxy timeout, failover to next proxy (socks5://9.10.11.12:1080)'),
      T('success', 'Account #3: session saved via failover proxy'),
      T('info', 'Continuing through 100 accounts...'),
      T('success', 'Secure-logged-in 98/100 accounts (2 failed: SESSION_REVOKED)'),
    ];
  }

  if (cmd.category === 'accounts') {
    return [
      T('info', 'Loading SessionManager from sessions/...'),
      T('info', 'Found 50 sessions in sessions/*.session'),
      T('info', 'Connecting to Telegram MTProto (DC2 - 149.154.167.51:443)'),
      T('info', 'Account #1 (+9665XXX): sending code request...'),
      T('success', 'Account #1: code received from 777000, validating...'),
      T('success', 'Account #1: authorized (id=7085239xxxx)'),
      T('info', 'Account #2: continuing...'),
      T('success', 'Login completed for 50 accounts'),
    ];
  }

  if (cmd.id === 'accounts.3') {
    return [
      T('info', 'LIVE ban check mode — authenticating each account...'),
      T('info', 'Account #1 (+9665XXX): logging in...'),
      T('success', 'Account #1: OK'),
      T('info', 'Account #2: logging in...'),
      T('error', 'Account #2: USER_DEACTIVED_BAN — banned account detected'),
      T('info', 'Account #3: logging in...'),
      T('success', 'Account #3: OK'),
      T('warning', 'Found 2 banned accounts, removing from phone.csv...'),
      T('success', 'Removed 2 banned numbers · 48 accounts remain'),
    ];
  }

  // SCRAPERS — njadder class names
  if (cmd.category === 'scrapers') {
    const cls = cmd.id === 'scrapers.1' ? 'PublicScraper' : cmd.id === 'scrapers.2' ? 'PrivateScraper' : cmd.id === 'scrapers.3' ? 'HiddenScraper' : cmd.id === 'scrapers.4' ? 'FullScraper' : cmd.id === 'scrapers.5' ? 'PremiumScraper' : cmd.id === 'scrapers.6' ? 'PrivateHiddenScraper' : 'Scraper';
    return [
      T('info', `Instantiating ${cls}(...) from njadder.scrapers`),
      T('info', `Resolving chat: ${cmd.id === 'scrapers.2' ? 'private link' : '@sourcegroup'}`),
      T('info', 'Connected. Calling get_participants with A-Z distribution...'),
      T('info', 'Iteration A → 200 members (200 total, 0 dedup)'),
      T('info', 'Iteration B → 187 members (387 total, 13 dedup)'),
      T('warning', 'FloodWait: 4s before next batch (Pyrogram auto-sleep)'),
      T('info', 'Iteration C → 198 members (585 total)'),
      T('info', '3-layer dedup: in-memory set + disk CSV + live API check'),
      T('success', `Scraped 1,842 members → data.csv (added to dedup manager)`),
    ];
  }

  // ADDERS — njadder class names
  if (cmd.category === 'adders') {
    const cls = cmd.id === 'adders.1' ? 'DirectAdder' : cmd.id === 'adders.2' ? 'ContactAdder' : cmd.id === 'adders.3' ? 'BulkAdder' : cmd.id === 'adders.4' ? 'FileToContactsAdder' : cmd.id === 'adders.5' ? 'ContactsToGroupAdder' : cmd.id === 'adders.6' ? 'RamexAdder' : 'Adder';
    return [
      T('info', `Instantiating ${cls}(config, session_mgr, dedup, flood_tracker)`),
      T('info', 'Loading phone.csv — 50 accounts loaded'),
      T('info', 'Account #1: connecting...'),
      T('info', 'Strategy: InputPhoneContact → add_contact → add_chat_members by ID'),
      T('info', 'Account #1: imported 200 contacts as InputPhoneContact'),
      T('info', 'Account #1: added 187/200 members to target (13 already in)'),
      T('warning', 'Account #1: PeerFlood on attempt 188 — FloodTracker engaged (24h cooldown)'),
      T('info', 'Switching to Account #2 (next available)...'),
      T('info', 'Account #2: added 195/200 members'),
      T('success', 'Total: 382 members added, 1 account in 24h cooldown'),
    ];
  }

  if (cmd.category === 'filters') {
    return [
      T('info', 'Initializing RamexAdder with filter mode=' + (cmd.id.split('.')[1] === '1' ? 'daily' : cmd.id.split('.')[1] === '2' ? 'weekly' : cmd.id.split('.')[1] === '3' ? 'monthly' : cmd.id.split('.')[1] === '4' ? 'online' : cmd.id.split('.')[1] === '5' ? 'nonactive' : 'hidden')),
      T('info', 'Loading source group members...'),
      T('info', 'Filtering by last-seen + activity pattern...'),
      T('info', '1,420 members match filter criteria'),
      T('info', 'Adding filtered members via multi-strategy...'),
      T('success', 'Added 187 members to target (1,233 skipped due to dedup)'),
    ];
  }

  if (cmd.category === 'messaging') {
    return [
      T('info', 'Loading session manager...'),
      T('info', 'Account #1 → @targetgroup: sending message ✓'),
      T('info', 'Account #2 → @targetgroup: sending message ✓'),
      T('warning', 'Account #3: FloodWait 7s, sleeping...'),
      T('info', 'Account #3 → @targetgroup: sending message ✓ (post-sleep)'),
      T('info', 'Account #4 → @targetgroup: sending message ✓'),
      T('success', 'All messages dispatched successfully'),
    ];
  }

  if (cmd.category === 'reports') {
    return [
      T('info', `Calling run_report(reason='${cmd.id.split('.')[1]}', channel, post_id)`),
      T('info', 'Loading 50 reporter accounts...'),
      T('info', 'Reports submitted: 10/50'),
      T('info', 'Reports submitted: 25/50'),
      T('info', 'Reports submitted: 40/50'),
      T('success', 'Reports submitted: 50/50 — target flagged for review'),
    ];
  }

  if (cmd.category === 'nearby') {
    return [
      T('info', 'Instantiating NearbyAdder from njadder.nearby.countries'),
      T('info', 'Loading COUNTRY_MAP (20 countries)'),
      T('info', 'Geocoding via Nominatim (timeout=5s, fallback enabled)'),
      T('success', 'Coordinates resolved: 25.2048, 55.2708 (Dubai, UAE)'),
      T('info', 'Pyrogram client initialized with geo-tagged profile'),
      T('warning', 'contacts.ImportContacts request sent (rate-limited)'),
      T('info', 'Discovered 142 nearby users'),
      T('success', 'Added 87 nearby users to target group'),
    ];
  }

  if (cmd.category === 'tools') {
    return [
      T('info', 'Loading accounts from phone.csv...'),
      T('info', 'Account #1: updating profile...'),
      T('success', 'Account #1: profile updated ✓'),
      T('info', 'Account #2: updating profile...'),
      T('success', 'Account #2: profile updated ✓'),
      T('success', 'Updated profile on 50 accounts'),
    ];
  }

  // UTILITIES — njadder v1.2.1 new features
  if (cmd.id === 'utilities.11') {
    return [
      T('info', 'Anonymous Chatter: loading all accounts'),
      T('info', 'Account #1 → target: sending 5 messages'),
      T('success', 'Account #1: 5/5 messages sent'),
      T('info', 'Account #2 → target: sending 5 messages'),
      T('success', 'Account #2: 5/5 messages sent'),
      T('success', 'Total: 250 messages sent from 50 accounts'),
    ];
  }
  if (cmd.id === 'utilities.12') {
    return [
      T('info', 'Post Views Increaser: fetching channel posts'),
      T('info', 'Found 100 posts (IDs 1-100)'),
      T('info', 'Account #1: reading 100 posts (delay 0.3s each)'),
      T('success', 'Account #1: 100/100 views incremented'),
      T('info', 'Account #2: reading 100 posts'),
      T('success', 'Account #2: 100/100 views incremented'),
      T('success', 'Total: 5,000 post reads performed across 50 accounts'),
    ];
  }
  if (cmd.id === 'utilities.13') {
    return [
      T('info', 'Make API ID/Hash Generator: starting'),
      T('info', 'Creating session via my.telegram.org automation...'),
      T('success', 'Generated api_id=24681357, api_hash=abcdef0123456789...'),
      T('info', 'Appending to api.csv...'),
      T('success', 'Added 5 new API credentials to api.csv'),
    ];
  }

  if (cmd.category === 'utilities' || cmd.category === 'groups') {
    return [
      T('info', 'Loading SessionManager...'),
      T('info', 'Connected to Telegram MTProto'),
      T('info', 'Processing request...'),
      T('success', 'Operation completed successfully'),
    ];
  }

  // default fallback
  return [
    T('info', 'Initializing njadder engine v1.2.1...'),
    T('info', 'Loading pyrogram session...'),
    T('info', 'Connected to Telegram MTProto'),
    T('success', 'Operation completed.'),
  ];
}

function summarizeResult(cmd: Command): string {
  const r = Math.floor(Math.random() * 9000) + 100;
  if (cmd.category === 'scrapers') return `${r * 4} members scraped`;
  if (cmd.category === 'adders') return `${r} members added`;
  if (cmd.category === 'filters') return `${r} filtered members added`;
  if (cmd.category === 'messaging') return `${r} messages delivered`;
  if (cmd.category === 'reports') return `${r} reports submitted`;
  if (cmd.category === 'nearby') return `${r} nearby users found`;
  if (cmd.category === 'utilities') return `${r} ops completed`;
  if (cmd.category === 'groups') return `${r} group operations done`;
  if (cmd.category === 'tools') return `${r} accounts updated`;
  if (cmd.category === 'accounts') return `${r} accounts processed`;
  return `processed (${r} ops)`;
}
