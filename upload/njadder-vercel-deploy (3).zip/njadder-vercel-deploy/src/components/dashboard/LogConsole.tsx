'use client';

import * as Icons from 'lucide-react';
import { useEffect, useRef } from 'react';
import { useStore, type LogLevel } from '@/lib/store';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

const levelConfig: Record<LogLevel, { color: string; icon: string }> = {
  info: { color: 'text-sky-400', icon: 'ℹ' },
  success: { color: 'text-emerald-400', icon: '✓' },
  warning: { color: 'text-amber-400', icon: '!' },
  error: { color: 'text-red-400', icon: '✗' },
  command: { color: 'text-violet-400', icon: '>' },
};

export function LogConsole() {
  const { logs, clearLogs, language, runningTasks } = useStore();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const fmtTime = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString('en-GB', { hour12: false });
    } catch {
      return '--:--:--';
    }
  };

  const activeTasks = runningTasks.filter((t) => t.status === 'running');

  return (
    <div className="flex flex-col h-full bg-[#0a0f1a] border-t border-border/40">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 px-3 py-2 border-b border-border/40 bg-card/40">
        <div className="flex items-center gap-2">
          <Icons.Terminal className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-semibold">{language === 'ar' ? 'سجل النظام' : 'System Log'}</span>
          <Badge variant="outline" className="h-4 text-[9px] px-1 font-mono">{logs.length}</Badge>
          {activeTasks.length > 0 && (
            <Badge variant="outline" className="h-4 text-[9px] px-1 bg-amber-500/10 text-amber-400 border-amber-500/20">
              <Icons.Loader2 className="h-2.5 w-2.5 ml-0.5 animate-spin" />
              {activeTasks.length} {language === 'ar' ? 'نشط' : 'active'}
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" onClick={clearLogs} className="h-6 text-[10px] text-muted-foreground">
          <Icons.Trash2 className="h-3 w-3 ml-1" />
          {language === 'ar' ? 'مسح' : 'Clear'}
        </Button>
      </div>

      {/* Active tasks (compact) */}
      {activeTasks.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-3 py-1.5 border-b border-border/40 bg-card/20">
          {activeTasks.map((t) => (
            <Badge key={t.id} variant="outline" className="text-[10px] bg-violet-500/10 text-violet-300 border-violet-500/20">
              <Icons.Loader2 className="h-2.5 w-2.5 ml-1 animate-spin" />
              #{t.commandId} {t.commandName} · {t.progress}%
            </Badge>
          ))}
        </div>
      )}

      {/* Log entries */}
      <ScrollArea className="flex-1 min-h-0">
        <div ref={scrollRef} className="px-3 py-2 font-mono text-[11px] leading-relaxed space-y-0.5">
          {logs.length === 0 ? (
            <div className="text-muted-foreground/50 py-8 text-center">
              <Icons.ScrollText className="h-8 w-8 mx-auto mb-2 opacity-40" />
              <p>{language === 'ar' ? 'لا توجد سجلات بعد' : 'No logs yet'}</p>
            </div>
          ) : (
            logs.slice(-150).map((log) => {
              const cfg = levelConfig[log.level];
              return (
                <div key={log.id} className="flex gap-2 hover:bg-white/2 rounded px-1 py-0.5">
                  <span className="text-muted-foreground/40 shrink-0">{fmtTime(log.timestamp)}</span>
                  <span className={cn('shrink-0 w-3', cfg.color)}>{cfg.icon}</span>
                  <span className="text-foreground/90 break-all">
                    {log.message}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
