'use client';

import * as Icons from 'lucide-react';
import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

type Mode = 'signin' | 'signup';

export function AuthModal() {
  const { isAuthOpen, setAuthOpen, language } = useStore() as any;
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [inlineError, setInlineError] = useState<string | null>(null);
  const [inlineSuccess, setInlineSuccess] = useState<string | null>(null);

  const t = language === 'ar' ? ar : en;

  const resetState = () => {
    setInlineError(null);
    setInlineSuccess(null);
  };

  const submit = async () => {
    resetState();
    if (!email.trim() || !password) {
      setInlineError(t.requiredError);
      toast.error(t.requiredError);
      return;
    }
    setLoading(true);
    try {
      if (mode === 'signup') {
        // 1. Create account
        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: email.trim(), password, name: name.trim() || undefined }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          const errMsg = data.error || t.signupFailed;
          setInlineError(errMsg);
          toast.error(errMsg);
          setLoading(false);
          // If email already exists, suggest switching to sign-in tab
          if (res.status === 409) {
            setTimeout(() => {
              setMode('signin');
              resetState();
            }, 1800);
          }
          return;
        }
        setInlineSuccess(t.signupOk);
        toast.success(t.signupOk);
      }

      // 2. Sign in (with redirect — refreshes the page and session)
      // Note: this never returns — browser redirects to callbackUrl.
      await signIn('credentials', {
        email: email.trim(),
        password,
        callbackUrl: '/',
        redirect: true,
      });
    } catch (err: any) {
      const errMsg = err?.message || t.networkError;
      setInlineError(errMsg);
      toast.error(errMsg);
      setLoading(false);
    }
  };

  const switchMode = (newMode: Mode) => {
    setMode(newMode);
    resetState();
  };

  return (
    <Dialog
      open={isAuthOpen}
      onOpenChange={(open) => {
        if (!loading) {
          setAuthOpen(open);
          if (!open) {
            setTimeout(resetState, 200);
          }
        }
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#229ED9] to-[#2AABEE]">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="currentColor">
                <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
              </svg>
            </div>
            {language === 'ar' ? 'تسجيل الدخول إلى njadder' : 'Sign in to njadder'}
          </DialogTitle>
          <DialogDescription>
            {language === 'ar'
              ? 'سجّل دخولك أو أنشئ حساباً جديداً للوصول إلى لوحة التحكم.'
              : 'Sign in or create a new account to access the dashboard.'}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={mode} onValueChange={(v) => switchMode(v as Mode)} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin" className="text-xs" disabled={loading}>
              {language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
            </TabsTrigger>
            <TabsTrigger value="signup" className="text-xs" disabled={loading}>
              {language === 'ar' ? 'إنشاء حساب' : 'Sign Up'}
            </TabsTrigger>
          </TabsList>

          {/* Inline error message */}
          {inlineError && (
            <div className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 p-2.5 flex items-start gap-2 animate-in fade-in slide-in-from-top-1 duration-300">
              <Icons.AlertCircle className="h-3.5 w-3.5 text-red-400 shrink-0 mt-0.5" />
              <p className="text-xs text-red-300 leading-relaxed">{inlineError}</p>
            </div>
          )}

          {/* Inline success message */}
          {inlineSuccess && (
            <div className="mt-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-2.5 flex items-start gap-2 animate-in fade-in slide-in-from-top-1 duration-300">
              <Icons.CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <p className="text-xs text-emerald-300 leading-relaxed">{inlineSuccess}</p>
            </div>
          )}

          {/* Sign In */}
          <TabsContent value="signin" className="space-y-3 mt-4">
            <div className="space-y-1.5">
              <Label htmlFor="signin-email" className="text-xs font-medium">
                {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              </Label>
              <div className="relative">
                <Icons.Mail className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signin-email"
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); resetState(); }}
                  placeholder="you@example.com"
                  className="text-xs pr-8"
                  onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
                  autoComplete="email"
                  disabled={loading}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signin-password" className="text-xs font-medium">
                {language === 'ar' ? 'كلمة المرور' : 'Password'}
              </Label>
              <div className="relative">
                <Icons.Lock className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signin-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); resetState(); }}
                  placeholder="••••••••"
                  className="text-xs pr-8 pl-8"
                  onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
                  autoComplete="current-password"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
                >
                  {showPassword ? <Icons.EyeOff className="h-3.5 w-3.5" /> : <Icons.Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>
          </TabsContent>

          {/* Sign Up */}
          <TabsContent value="signup" className="space-y-3 mt-4">
            <div className="space-y-1.5">
              <Label htmlFor="signup-name" className="text-xs font-medium">
                {language === 'ar' ? 'الاسم (اختياري)' : 'Name (optional)'}
              </Label>
              <div className="relative">
                <Icons.User className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signup-name"
                  type="text"
                  value={name}
                  onChange={(e) => { setName(e.target.value); resetState(); }}
                  placeholder={language === 'ar' ? 'اسمك' : 'Your name'}
                  className="text-xs pr-8"
                  disabled={loading}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-email" className="text-xs font-medium">
                {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              </Label>
              <div className="relative">
                <Icons.Mail className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signup-email"
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); resetState(); }}
                  placeholder="you@example.com"
                  className="text-xs pr-8"
                  autoComplete="email"
                  disabled={loading}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-password" className="text-xs font-medium">
                {language === 'ar' ? 'كلمة المرور (8+ أحرف)' : 'Password (8+ chars)'}
              </Label>
              <div className="relative">
                <Icons.Lock className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signup-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); resetState(); }}
                  placeholder="••••••••"
                  className="text-xs pr-8 pl-8"
                  autoComplete="new-password"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
                >
                  {showPassword ? <Icons.EyeOff className="h-3.5 w-3.5" /> : <Icons.Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {password && password.length < 8 && (
                <p className="text-[10px] text-amber-400 flex items-center gap-1">
                  <Icons.AlertTriangle className="h-3 w-3" />
                  {language === 'ar' ? `تحتاج ${8 - password.length} أحرف أخرى` : `${8 - password.length} more chars needed`}
                </p>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="rounded-lg border border-sky-500/20 bg-sky-500/5 p-2.5 flex items-start gap-2">
          <Icons.ShieldCheck className="h-3.5 w-3.5 text-sky-400 shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            {language === 'ar'
              ? '🔒 كلمة المرور مشفّرة بـ bcrypt. الجلسة محفوظة في JWT cookie.'
              : '🔒 Password hashed with bcrypt. Session stored as JWT cookie.'}
          </p>
        </div>

        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => setAuthOpen(false)}
            disabled={loading}
          >
            {language === 'ar' ? 'إلغاء' : 'Cancel'}
          </Button>
          <Button onClick={submit} disabled={loading} className="glow-primary min-w-[140px]">
            {loading ? (
              <>
                <Icons.Loader2 className="h-3.5 w-3.5 ml-1.5 animate-spin" />
                {language === 'ar' ? 'جارٍ المعالجة...' : 'Processing...'}
              </>
            ) : mode === 'signin' ? (
              <>
                <Icons.LogIn className="h-3.5 w-3.5 ml-1.5" />
                {language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
              </>
            ) : (
              <>
                <Icons.UserPlus className="h-3.5 w-3.5 ml-1.5" />
                {language === 'ar' ? 'إنشاء الحساب' : 'Create Account'}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const ar = {
  requiredError: 'يرجى إدخال البريد الإلكتروني وكلمة المرور',
  signupFailed: 'فشل إنشاء الحساب',
  signupOk: 'تم إنشاء الحساب ✓ جارٍ تسجيل الدخول...',
  signinFailed: 'فشل تسجيل الدخول',
  signinDone: 'تم تسجيل الدخول ✓',
  signupDone: 'تم إنشاء الحساب وتسجيل الدخول ✓',
  networkError: 'خطأ في الشبكة — تحقق من اتصالك بالإنترنت',
};

const en = {
  requiredError: 'Please enter email and password',
  signupFailed: 'Failed to create account',
  signupOk: 'Account created ✓ Signing in...',
  signinFailed: 'Sign in failed',
  signinDone: 'Signed in ✓',
  signupDone: 'Account created and signed in ✓',
  networkError: 'Network error — check your connection',
};
