'use client';

import * as Icons from 'lucide-react';
import { useStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function AuthGate() {
  const { language, setAuthOpen } = useStore();
  const t = language === 'ar' ? ar : en;

  return (
    <div className="min-h-screen bg-background bg-grid flex flex-col">
      {/* Top bar */}
      <header className="border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <div className="relative h-10 w-10 overflow-hidden rounded-xl bg-gradient-to-br from-[#229ED9] to-[#2AABEE] flex items-center justify-center glow-primary">
              <svg viewBox="0 0 24 24" className="h-6 w-6 text-white" fill="currentColor">
                <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-base md:text-lg font-bold tracking-tight">
                {language === 'ar' ? 'njadder — أداة تيليجرام الموحدة' : 'njadder — Unified Telegram Tool'}
              </h1>
              <p className="text-[10px] md:text-xs text-muted-foreground">
                v1.2.1 Professional Edition · <span className="font-mono text-primary">@NMDDER_DEV</span>
              </p>
            </div>
          </div>
          <Button onClick={() => setAuthOpen(true)} className="glow-primary">
            <Icons.LogIn className="h-4 w-4 ml-1.5" />
            {language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
          </Button>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          {/* Logo */}
          <div className="flex justify-center">
            <div className="relative h-20 w-20 rounded-2xl bg-gradient-to-br from-[#229ED9] to-[#2AABEE] flex items-center justify-center glow-primary">
              <svg viewBox="0 0 24 24" className="h-12 w-12 text-white" fill="currentColor">
                <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
              </svg>
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-l from-foreground via-primary to-foreground bg-clip-text text-transparent">
              {language === 'ar' ? 'لوحة تحكم njadder الموحدة' : 'njadder Unified Dashboard'}
            </h2>
            <p className="text-sm md:text-base text-muted-foreground max-w-xl mx-auto leading-relaxed">
              {language === 'ar'
                ? 'أداة تيليجرام الاحترافية — 88 أمر، Secure Login، Live Ban Checker، مدير بروكسي، وكل ما تحتاجه لإدارة الحسابات.'
                : 'Professional Telegram tool — 88 commands, Secure Login, Live Ban Checker, Proxy Manager, and everything you need to manage accounts.'}
            </p>
          </div>

          {/* Feature badges */}
          <div className="flex flex-wrap justify-center gap-2 max-w-xl mx-auto">
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/20">
              <Icons.ShieldCheck className="h-3 w-3 ml-1" />
              {t.secureLogin}
            </Badge>
            <Badge variant="outline" className="bg-red-500/10 text-red-300 border-red-500/20">
              <Icons.Ban className="h-3 w-3 ml-1" />
              {t.banChecker}
            </Badge>
            <Badge variant="outline" className="bg-sky-500/10 text-sky-300 border-sky-500/20">
              <Icons.Shield className="h-3 w-3 ml-1" />
              {t.proxyManager}
            </Badge>
            <Badge variant="outline" className="bg-amber-500/10 text-amber-300 border-amber-500/20">
              <Icons.Crown className="h-3 w-3 ml-1" />
              {t.v121}
            </Badge>
            <Badge variant="outline" className="bg-violet-500/10 text-violet-300 border-violet-500/20">
              <Icons.Sparkles className="h-3 w-3 ml-1" />
              {t.pwa}
            </Badge>
          </div>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <Button size="lg" onClick={() => setAuthOpen(true)} className="glow-primary">
              <Icons.UserPlus className="h-4 w-4 ml-2" />
              {language === 'ar' ? 'ابدأ الآن — أنشئ حساباً' : 'Get Started — Sign Up'}
            </Button>
            <Button size="lg" variant="outline" onClick={() => setAuthOpen(true)}>
              <Icons.LogIn className="h-4 w-4 ml-2" />
              {language === 'ar' ? 'لدي حساب بالفعل' : 'I already have an account'}
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto pt-8">
            <Stat number="88" label={language === 'ar' ? 'أمر' : 'Commands'} />
            <Stat number="10" label={language === 'ar' ? 'فئات' : 'Categories'} />
            <Stat number="20" label={language === 'ar' ? 'دولة' : 'Countries'} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 py-4 px-4 text-center">
        <p className="text-[11px] text-muted-foreground">
          {language === 'ar'
            ? 'مدمجة من opthree.py + ramexfour.py + ts.py · المطور: '
            : 'Merged from opthree.py + ramexfour.py + ts.py · Dev: '}
          <span className="font-mono text-primary">@NMDDER_DEV</span>
          {' · '}
          <span className="font-mono text-muted-foreground">@NMDDER_SUPPORT</span>
        </p>
      </footer>
    </div>
  );
}

function Stat({ number, label }: { number: string; label: string }) {
  return (
    <div className="rounded-lg border border-border/40 bg-card/40 px-3 py-2">
      <div className="text-xl font-bold font-mono text-primary">{number}</div>
      <div className="text-[10px] text-muted-foreground">{label}</div>
    </div>
  );
}

const ar = {
  secureLogin: 'دخول آمن',
  banChecker: 'فاحص الحظر',
  proxyManager: 'مدير بروكسي',
  v121: 'v1.2.1 Professional',
  pwa: 'يعمل بدون إنترنت',
};

const en = {
  secureLogin: 'Secure Login',
  banChecker: 'Ban Checker',
  proxyManager: 'Proxy Manager',
  v121: 'v1.2.1 Professional',
  pwa: 'Works Offline (PWA)',
};
