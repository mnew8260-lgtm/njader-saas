import type { Metadata, Viewport } from "next";
import { Cairo, Geist, Geist_Mono, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { PWAProvider } from "@/components/pwa/PWAProvider";
import { SessionProvider } from "@/components/auth/SessionProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
});

const jetMono = JetBrains_Mono({
  variable: "--font-jet-mono",
  subsets: ["latin"],
  weight: ["400", "500", "700"],
});

export const metadata: Metadata = {
  metadataBase: new URL("http://localhost:3000"),
  title: "njadder — Unified Telegram Tool (v1.2.1)",
  description: "لوحة تحكم njadder v1.2.1 — أداة تيليجرام الموحدة. 88 أمر، Secure Login، Live Ban Checker، مدير بروكسي. تعمل بدون إنترنت (PWA).",
  keywords: ["njadder", "Telegram", "Master Tool", "Pyrogram", "Dashboard", "NMDDER", "PWA", "Secure Login"],
  authors: [{ name: "@NMDDER_DEV" }],
  manifest: "/manifest.webmanifest",
  applicationName: "njadder",
  appleWebApp: {
    capable: true,
    title: "njadder",
    statusBarStyle: "black-translucent",
  },
  formatDetection: {
    telephone: false,
    email: false,
    address: false,
  },
  icons: {
    icon: [
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16.png", sizes: "16x16", type: "image/png" },
      { url: "/icon.svg", sizes: "any", type: "image/svg+xml" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    shortcut: ["/favicon-32.png"],
  },
  openGraph: {
    title: "njadder — Unified Telegram Tool (v1.2.1)",
    description: "Unified dashboard for 88 Telegram automation commands. Works offline (PWA).",
    type: "website",
    images: [{ url: "/dashboard-initial.png", width: 1280, height: 1439 }],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0e1621" },
    { media: "(prefers-color-scheme: light)", color: "#229ED9" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning className="dark">
      <head>
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="njadder" />
        <meta name="application-name" content="njadder" />
        <meta name="msapplication-TileColor" content="#0e1621" />
        <meta name="msapplication-tap-highlight" content="no" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" href="/favicon-32.png" type="image/png" sizes="32x32" />
        <link rel="icon" href="/favicon-16.png" type="image/png" sizes="16x16" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="mask-icon" href="/icon.svg" color="#229ED9" />
        <link rel="manifest" href="/manifest.webmanifest" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${cairo.variable} ${jetMono.variable} antialiased bg-background text-foreground font-arabic`}
      >
        <SessionProvider>
          {children}
          <PWAProvider />
        </SessionProvider>
        <Toaster />
      </body>
    </html>
  );
}
