'use client';

import { useSession } from 'next-auth/react';
import { Header } from '@/components/dashboard/Header';
import { Sidebar, MobileCategoryBar } from '@/components/dashboard/Sidebar';
import { StatsBar } from '@/components/dashboard/StatsBar';
import { CommandGrid } from '@/components/dashboard/CommandGrid';
import { LogConsole } from '@/components/dashboard/LogConsole';
import { ConfigModal } from '@/components/modals/ConfigModal';
import { ProxyModal } from '@/components/modals/ProxyModal';
import { AccountsModal } from '@/components/modals/AccountsModal';
import { SecureLoginModal } from '@/components/modals/SecureLoginModal';
import { BanCheckerModal } from '@/components/modals/BanCheckerModal';
import { AuthModal } from '@/components/auth/AuthModal';
import { AuthGate } from '@/components/auth/AuthGate';
import { useState } from 'react';
import { ChevronUp, Terminal as TerminalIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStore } from '@/lib/store';

function DashboardContent() {
  const { language } = useStore();
  const [consoleOpen, setConsoleOpen] = useState(true);

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <MobileCategoryBar />

      <div className="flex flex-1 min-h-0">
        <Sidebar />

        <main className="flex flex-1 flex-col min-w-0">
          <StatsBar />
          <div className="flex-1 min-h-0 overflow-hidden">
            <CommandGrid />
          </div>
        </main>
      </div>

      {/* Floating log console — collapsible bottom drawer */}
      <div className={`border-t border-border/60 bg-[#0a0f1a] transition-all duration-300 ${consoleOpen ? 'h-56' : 'h-9'}`}>
        <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/40 cursor-pointer" onClick={() => setConsoleOpen((v) => !v)}>
          <div className="flex items-center gap-2">
            <TerminalIcon className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs font-semibold">{language === 'ar' ? 'سجل النظام المباشر' : 'Live System Log'}</span>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <ChevronUp className={`h-3.5 w-3.5 transition-transform ${consoleOpen ? '' : 'rotate-180'}`} />
          </Button>
        </div>
        {consoleOpen && (
          <div className="h-[calc(100%-2rem)]">
            <LogConsole />
          </div>
        )}
      </div>

      <ConfigModal />
      <ProxyModal />
      <AccountsModal />
      <SecureLoginModal />
      <BanCheckerModal />
      <AuthModal />
    </div>
  );
}

export default function Home() {
  const { data: session, status } = useSession();

  // Show loading while session is being fetched
  if (status === 'loading') {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-background gap-4">
        <div className="relative h-12 w-12">
          <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-[#229ED9] to-[#2AABEE] animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="h-7 w-7 text-white" fill="currentColor">
              <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
            </svg>
          </div>
        </div>
        <p className="text-xs text-muted-foreground animate-soft-pulse">njadder — v1.2.1</p>
      </div>
    );
  }

  // Not authenticated → show the auth gate (landing + login button)
  if (!session) {
    return (
      <>
        <AuthGate />
        <AuthModal />
      </>
    );
  }

  // Authenticated → show dashboard
  return <DashboardContent />;
}
