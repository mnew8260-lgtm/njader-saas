import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type LogLevel = 'info' | 'success' | 'warning' | 'error' | 'command';
export type LogEntry = {
  id: string;
  timestamp: string;
  level: LogLevel;
  message: string;
  commandId?: string;
  commandName?: string;
};

// njadder config.ini [NJaddingZone] section — pure standard library, no pydantic
export type AppConfig = {
  api_id: string;
  api_hash: string;
  startingaccount: string;
  endaccount: string;
  enterstop: string;
  togroup: string;
  fromgroup: string;
  phone: string;
  proxy_enabled: boolean;
  proxy_type: 'socks5' | 'socks4' | 'http' | 'mtproto';
  proxy_host: string;
  proxy_port: string;
  proxy_username: string;
  proxy_password: string;
  support_group: string;
};

export type ProxyConfig = AppConfig; // alias — proxy fields live inside AppConfig for njadder

export type ProxyEntry = {
  id: string;
  line: string;
  type: string;
  host: string;
  port: number;
  username?: string;
  password?: string;
  status?: 'idle' | 'testing' | 'ok' | 'failed';
};

// Per-account CSV rotation resources for Secure Login (njadder v1.2.1)
export type ApiCredential = { id: string; api_id: string; api_hash: string };
export type DeviceInfo = { id: string; device_model: string; system_version: string; app_version: string };
export type ProxyCsvRow = { id: string; type: string; host: string; port: number; username: string; password: string };

export type Account = {
  id: string;
  phone: string;
  session: string;
  status: 'logged_in' | 'logged_out' | 'banned' | 'limited' | 'pending' | 'not_logged_in';
  firstName?: string;
  lastName?: string;
  username?: string;
  api_id?: string;          // which API was used (for secure login)
  device_model?: string;   // which device was used (for secure login)
  proxy?: string;           // which proxy was used (host:port)
  addedAt: string;
  lastActivity?: string;
};

export type RunningTask = {
  id: string;
  commandId: string;
  commandName: string;
  status: 'running' | 'completed' | 'failed' | 'paused';
  progress: number;
  startedAt: string;
  params?: Record<string, string>;
};

type State = {
  // UI
  activeCategory: string;
  selectedCommandId: string | null;
  isConfigOpen: boolean;
  isProxyOpen: boolean;
  isAccountsOpen: boolean;
  isSecureLoginOpen: boolean;
  isBanCheckerOpen: boolean;
  isAuthOpen: boolean;          // auth modal (sign in / sign up)
  search: string;
  language: 'ar' | 'en';

  // Data
  config: AppConfig;
  proxyList: ProxyEntry[];       // standalone proxy.txt (legacy)
  apiCsv: ApiCredential[];       // api.csv (njadder secure login)
  devicesCsv: DeviceInfo[];      // devices.csv
  proxiesCsv: ProxyCsvRow[];     // proxies.csv (per-account)
  accounts: Account[];
  logs: LogEntry[];
  runningTasks: RunningTask[];

  // Actions
  setCategory: (id: string) => void;
  selectCommand: (id: string | null) => void;
  setConfigOpen: (open: boolean) => void;
  setProxyOpen: (open: boolean) => void;
  setAccountsOpen: (open: boolean) => void;
  setSecureLoginOpen: (open: boolean) => void;
  setBanCheckerOpen: (open: boolean) => void;
  setAuthOpen: (open: boolean) => void;
  setSearch: (s: string) => void;
  toggleLanguage: () => void;
  updateConfig: (c: Partial<AppConfig>) => void;
  // Legacy proxy.txt
  addProxy: (line: string) => void;
  removeProxy: (id: string) => void;
  clearProxies: () => void;
  setProxyStatus: (id: string, status: ProxyEntry['status']) => void;
  // njadder CSV resources
  addApiRow: (row: Omit<ApiCredential, 'id'>) => void;
  removeApiRow: (id: string) => void;
  clearApiCsv: () => void;
  addDeviceRow: (row: Omit<DeviceInfo, 'id'>) => void;
  removeDeviceRow: (id: string) => void;
  clearDevicesCsv: () => void;
  addProxyCsvRow: (row: Omit<ProxyCsvRow, 'id'>) => void;
  removeProxyCsvRow: (id: string) => void;
  clearProxiesCsv: () => void;
  setProxyCsvStatus: (id: string, status: ProxyEntry['status']) => void;
  // Accounts
  addAccount: (a: Account) => void;
  removeAccount: (id: string) => void;
  clearAccounts: () => void;
  updateAccount: (id: string, patch: Partial<Account>) => void;
  // Logs
  addLog: (entry: Omit<LogEntry, 'id' | 'timestamp'>) => void;
  clearLogs: () => void;
  // Tasks
  startTask: (t: RunningTask) => void;
  updateTask: (id: string, patch: Partial<RunningTask>) => void;
  removeTask: (id: string) => void;
};

// njadder v1.2.1 default config (mirrors njadder/config.py _DEFAULTS)
const defaultConfig: AppConfig = {
  api_id: '0',
  api_hash: 'YOUR_API_HASH_HERE',
  startingaccount: '1',
  endaccount: '50',
  enterstop: '1000000',
  togroup: '',
  fromgroup: '',
  phone: '',
  proxy_enabled: false,
  proxy_type: 'socks5',
  proxy_host: '127.0.0.1',
  proxy_port: '1080',
  proxy_username: '',
  proxy_password: '',
  support_group: '@NMDDER_SUPPORT',
};

function genId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export const useStore = create<State>()(
  persist(
    (set) => ({
      activeCategory: 'accounts',
      selectedCommandId: null,
      isConfigOpen: false,
      isProxyOpen: false,
      isAccountsOpen: false,
      isSecureLoginOpen: false,
      isBanCheckerOpen: false,
      isAuthOpen: false,
      search: '',
      language: 'ar',

      config: defaultConfig,
      proxyList: [],
      apiCsv: [],
      devicesCsv: [],
      proxiesCsv: [],
      accounts: [],
      logs: [
        { id: 'init', timestamp: new Date().toISOString(), level: 'info', message: '[njadder] تم تهيئة لوحة التحكم بنجاح. الإصدار v1.2.1 — Professional Edition.' },
        { id: 'init2', timestamp: new Date().toISOString(), level: 'info', message: '[njadder] أداة تيليجرام الموحدة | المطور: @NMDDER_DEV | الدعم: @NMDDER_SUPPORT' },
        { id: 'init3', timestamp: new Date().toISOString(), level: 'command', message: '[njadder] مدمجة من opthree.py + ramexfour.py + ts.py (+5 خدمات جديدة + فاحص حظر مباشر)' },
        { id: 'init4', timestamp: new Date().toISOString(), level: 'info', message: '[njadder] إجمالي الأوامر: 88 موزعة على 10 فئات. اختر فئة من القائمة الجانبية للبدء.' },
      ],
      runningTasks: [],

      setCategory: (id) => set({ activeCategory: id, selectedCommandId: null, search: '' }),
      selectCommand: (id) => set({ selectedCommandId: id }),
      setConfigOpen: (open) => set({ isConfigOpen: open }),
      setProxyOpen: (open) => set({ isProxyOpen: open }),
      setAccountsOpen: (open) => set({ isAccountsOpen: open }),
      setSecureLoginOpen: (open) => set({ isSecureLoginOpen: open }),
      setBanCheckerOpen: (open) => set({ isBanCheckerOpen: open }),
      setAuthOpen: (open) => set({ isAuthOpen: open }),
      setSearch: (s) => set({ search: s }),
      toggleLanguage: () => set((st) => ({ language: st.language === 'ar' ? 'en' : 'ar' })),
      updateConfig: (c) => set((st) => ({ config: { ...st.config, ...c } })),

      // Legacy proxy.txt
      addProxy: (line) =>
        set((st) => {
          const parsed = parseProxyLine(line);
          if (!parsed) return st;
          return { proxyList: [...st.proxyList, { id: genId(), line, ...parsed, status: 'idle' }] };
        }),
      removeProxy: (id) => set((st) => ({ proxyList: st.proxyList.filter((p) => p.id !== id) })),
      clearProxies: () => set({ proxyList: [] }),
      setProxyStatus: (id, status) =>
        set((st) => ({ proxyList: st.proxyList.map((p) => (p.id === id ? { ...p, status } : p)) })),

      // njadder api.csv (per-account API credentials)
      addApiRow: (row) => set((st) => ({ apiCsv: [...st.apiCsv, { ...row, id: genId() }] })),
      removeApiRow: (id) => set((st) => ({ apiCsv: st.apiCsv.filter((r) => r.id !== id) })),
      clearApiCsv: () => set({ apiCsv: [] }),

      // njadder devices.csv (per-account device spoofing)
      addDeviceRow: (row) => set((st) => ({ devicesCsv: [...st.devicesCsv, { ...row, id: genId() }] })),
      removeDeviceRow: (id) => set((st) => ({ devicesCsv: st.devicesCsv.filter((r) => r.id !== id) })),
      clearDevicesCsv: () => set({ devicesCsv: [] }),

      // njadder proxies.csv (per-account proxy)
      addProxyCsvRow: (row) => set((st) => ({ proxiesCsv: [...st.proxiesCsv, { ...row, id: genId(), status: 'idle' as const }] })),
      removeProxyCsvRow: (id) => set((st) => ({ proxiesCsv: st.proxiesCsv.filter((r) => r.id !== id) })),
      clearProxiesCsv: () => set({ proxiesCsv: [] }),
      setProxyCsvStatus: (id, status) =>
        set((st) => ({ proxiesCsv: st.proxiesCsv.map((r) => (r.id === id ? { ...r, status } : r)) })),

      // Accounts
      addAccount: (a) => set((st) => ({ accounts: [...st.accounts, a] })),
      removeAccount: (id) => set((st) => ({ accounts: st.accounts.filter((a) => a.id !== id) })),
      clearAccounts: () => set({ accounts: [] }),
      updateAccount: (id, patch) =>
        set((st) => ({ accounts: st.accounts.map((a) => (a.id === id ? { ...a, ...patch } : a)) })),

      // Logs
      addLog: (entry) =>
        set((st) => ({
          logs: [...st.logs, { id: genId(), timestamp: new Date().toISOString(), ...entry }].slice(-300),
        })),
      clearLogs: () => set({ logs: [] }),

      // Tasks
      startTask: (t) => set((st) => ({ runningTasks: [...st.runningTasks, t] })),
      updateTask: (id, patch) =>
        set((st) => ({ runningTasks: st.runningTasks.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
      removeTask: (id) => set((st) => ({ runningTasks: st.runningTasks.filter((t) => t.id !== id) })),
    }),
    {
      name: 'njadder-v1.2.1-state',
      partialize: (s) => ({
        config: s.config,
        proxyList: s.proxyList,
        apiCsv: s.apiCsv,
        devicesCsv: s.devicesCsv,
        proxiesCsv: s.proxiesCsv,
        accounts: s.accounts,
        language: s.language,
      }),
    }
  )
);

function parseProxyLine(line: string): { type: string; host: string; port: number; username?: string } | null {
  try {
    let scheme = 'socks5';
    let username = '';
    let host = '';
    let port = 0;
    let rest = line.trim();
    if (!rest || rest.startsWith('#')) return null;
    if (rest.includes('://')) {
      const [s, r] = rest.split('://', 2);
      scheme = s.toLowerCase();
      rest = r;
    }
    if (rest.includes('@')) {
      const atIdx = rest.lastIndexOf('@');
      const auth = rest.substring(0, atIdx);
      rest = rest.substring(atIdx + 1);
      if (auth.includes(':')) {
        username = auth.split(':', 2)[0];
      } else {
        username = auth;
      }
    }
    const parts = rest.split(':');
    if (parts.length < 2) return null;
    host = parts[0].trim();
    port = parseInt(parts[1].trim(), 10);
    if (isNaN(port) || port < 1 || port > 65535) return null;
    return { type: scheme, host, port, username };
  } catch {
    return null;
  }
}
