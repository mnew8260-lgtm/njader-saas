"""Abstract base for adders with common logic.

The two key protected methods are:

- :meth:`_add_to_group_safe` — direct ``add_chat_members`` with full
  exception handling. Used by adders that already have peer resolution
  (e.g. contacts that are already in the user's contact list).

- :meth:`_add_member_safe_v44` — the "v44" multi-strategy pipeline
  used when adding scraped members whose peer info may be stale. The
  pipeline is **lean by default**: it tries the cheapest operation
  first (``add_chat_members`` by ID — one API call) and only falls
  back to the more invasive strategies (``add_contact``,
  ``import_contacts``) when ``PeerIdInvalid`` is raised.

Each strategy returns a ``(ok: bool, reason: str)`` tuple; the caller
propagates the reason through :meth:`_handle_error` for classification.
"""
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from pyrogram import Client
from pyrogram.errors import (
    ChatAdminRequired,
    FloodWait,
    PeerFlood,
    PeerIdInvalid,
    UserAlreadyParticipant,
    UserBannedInChannel,
    UserChannelsTooMuch,
    UserKicked,
    UserPrivacyRestricted,
)

from ..config import Config
from ..core import (
    DedupManager,
    ErrorCounter,
    FloodTracker,
    OpReport,
    SessionManager,
)
from ..core.flood import INTER_ACCOUNT_PEERFLOOD_COOLDOWN
from ..core.helpers import classify_error, extract_flood_seconds, smart_delay

log = logging.getLogger(__name__)

# How many pending deletes to accumulate before flushing them in a
# single delete_contacts call. Trades contact-list growth for far
# fewer API calls (and thus much lower PeerFlood risk).
DELETE_BATCH_SIZE = 10


@dataclass
class OperationResult:
    """Result of an adder operation."""

    success: int = 0
    skipped: int = 0
    errors: int = 0
    flooded_accounts: list[str] = field(default_factory=list)
    report_path: str = ""
    errors_per_account: dict[str, ErrorCounter] = field(default_factory=dict)

    def add_account(self, phone: str, counter: ErrorCounter) -> None:
        """Record the per-account error counter for this run."""
        self.errors_per_account[phone] = counter


class BaseAdder(ABC):
    """Abstract base for all adders."""

    def __init__(
        self,
        settings: Config,
        session_mgr: SessionManager,
        dedup: DedupManager,
        flood_tracker: FloodTracker | None = None,
    ) -> None:
        self.settings = settings
        self.session_mgr = session_mgr
        self.dedup = dedup
        self.flood_tracker = flood_tracker or FloodTracker()
        # Pending delete_contacts IDs — flushed every DELETE_BATCH_SIZE.
        self._pending_deletes: list[int] = []

    @abstractmethod
    async def run(self, *args: Any, **kwargs: Any) -> OperationResult:
        """Execute the adder operation. Subclasses must implement."""
        ...

    # ------------------------------------------------------------------
    # Direct add (when peer is already resolvable)
    # ------------------------------------------------------------------

    async def _add_to_group_safe(
        self,
        app: Client,
        target_chat_id: int,
        user_id: int,
    ) -> tuple[bool, str]:
        """Attempt to add a user to a group with full error handling.

        Returns ``(True, "OK")`` on success or
        ``(True, "already_member")`` if the user is already in the group
        (counted as success so the caller can mark them done).
        """
        try:
            await app.add_chat_members(target_chat_id, int(user_id))
            return (True, "OK")
        except UserAlreadyParticipant:
            return (True, "already_member")
        except UserPrivacyRestricted:
            return (False, "UserPrivacyRestricted")
        except UserChannelsTooMuch:
            return (False, "UserChannelsTooMuch")
        except UserBannedInChannel:
            return (False, "UserBannedInChannel")
        except ChatAdminRequired:
            return (False, "ChatAdminRequired")
        except UserKicked:
            try:
                await app.unban_chat_member(target_chat_id, int(user_id))
                await asyncio.sleep(1)
                await app.add_chat_members(target_chat_id, int(user_id))
                return (True, "OK (unbanned)")
            except Exception as e:
                return (False, f"USER_KICKED: {type(e).__name__}")
        except FloodWait as e:
            return (False, f"FloodWait {e.value}s")
        except PeerFlood:
            return (False, "PeerFlood")
        except PeerIdInvalid:
            return (False, "PeerIdInvalid")
        except Exception as e:
            return (False, type(e).__name__)

    async def _add_to_contacts_safe(
        self,
        app: Client,
        member: dict[str, Any],
    ) -> tuple[bool, str]:
        """Add a member as a contact using three strategies.

        Strategies (in order):
        1. ``InputPhoneContact`` — forces peer resolution via phone.
        2. ``add_contact`` by user id.
        3. ``resolve_peer`` by username → ``add_contact``.
        """
        uid = member.get("user_id", 0)
        fname = member.get("first_name", "") or "Contact"
        lname = member.get("last_name", "") or ""
        uname = member.get("username", "")
        phone = member.get("phone_number", "") or member.get("phone", "") or ""

        # Strategy 1: InputPhoneContact (forces peer resolution).
        if phone:
            try:
                from pyrogram.types import InputPhoneContact

                contacts = await app.import_contacts(
                    [InputPhoneContact(phone=phone, first_name=fname, last_name=lname)]
                )
                if contacts and (contacts.users or contacts.imported):
                    return (True, "OK (phone)")
            except FloodWait as e:
                return (False, f"FloodWait {e.value}s")
            except PeerFlood:
                return (False, "PeerFlood")
            except Exception:
                pass  # fall through to next strategy

        # Strategy 2: add_contact by user_id.
        try:
            await app.add_contact(int(uid), fname, last_name=lname)
            return (True, "OK (id)")
        except UserPrivacyRestricted:
            return (False, "UserPrivacyRestricted")
        except (FloodWait, PeerFlood):
            pass
        except Exception:
            pass

        # Strategy 3: resolve via username then add_contact.
        if uname:
            try:
                await app.resolve_peer(uname)
                await asyncio.sleep(0.5)
                await app.add_contact(int(uid), fname, last_name=lname)
                return (True, "OK (username)")
            except UserPrivacyRestricted:
                return (False, "UserPrivacyRestricted")
            except FloodWait as e:
                return (False, f"FloodWait {e.value}s")
            except PeerFlood:
                return (False, "PeerFlood")
            except Exception as e:
                return (False, type(e).__name__)

        return (False, "PeerIdInvalid (no phone, no username)")

    # ------------------------------------------------------------------
    # Lean v44 multi-strategy pipeline
    # ------------------------------------------------------------------

    async def _add_member_safe_v44(
        self,
        app: Client,
        target_chat_id: int,
        user_id: int,
        member_info: dict[str, Any] | None = None,
    ) -> tuple[bool, str]:
        """Lean v44 strategy — tries the cheapest operation first.

        Order:
        1. ``add_chat_members(target, user_id)`` — 1 API call. Works
           for the vast majority of scraped members.
        2. If ``PeerIdInvalid``: ``get_users(user_id)`` (force peer
           refresh) then retry ``add_chat_members``. — 2 API calls.
        3. If still failing: ``add_contact`` + ``add_chat_members`` +
           ``delete_contacts`` (batched). — 2 API calls + batched del.
        4. If phone available: ``import_contacts`` + retry. — 2 calls.
        5. If username available: ``resolve_peer`` + retry by uname.
        """
        name = ""
        uname = ""
        phone = ""
        if member_info:
            name = (member_info.get("first_name", "") or "").strip()
            uname = (member_info.get("username", "") or "").strip().lstrip("@")
            phone = (
                member_info.get("phone_number", "")
                or member_info.get("phone", "")
                or ""
            ).strip()

        # Strategy 1: direct add by ID — cheapest path (1 API call).
        ok, reason = await self._v44_add_by_id(app, target_chat_id, user_id)
        if ok:
            return (True, reason)
        # Hard-stop reasons (don't fall through).
        if reason in (
            "UserPrivacyRestricted", "UserChannelsTooMuch", "PeerFlood",
            "UserBannedInChannel", "ChatAdminRequired",
        ) or reason.startswith(("FloodWait", "USER_KICKED")):
            return (False, reason)

        # Strategy 2: get_users refresh + retry by ID (2 API calls).
        if reason == "PeerIdInvalid":
            ok, reason = await self._v44_get_users_retry(
                app, target_chat_id, user_id, reason
            )
            if ok:
                return (True, reason)
            if not reason.startswith("PeerIdInvalid"):
                # Different error — fall through to next strategy only
                # if it's still a peer-resolution issue.
                if reason not in ("", "cannot_add_user"):
                    return (False, reason)

        # Strategy 3: add_contact then add_chat_members (2 API calls).
        ok, contact_reason = await self._v44_add_contact_first(
            app, target_chat_id, user_id, name
        )
        if ok:
            return (True, contact_reason)
        if contact_reason.startswith(("FloodWait", "PeerFlood", "UserPrivacy")):
            return (False, contact_reason)

        # Strategy 4: import_contacts (phone-based) + retry.
        if phone:
            ok, phone_reason = await self._v44_phone_import_then_add(
                app, target_chat_id, user_id, phone, name
            )
            if ok:
                return (True, phone_reason)
            if phone_reason.startswith(("FloodWait", "PeerFlood")):
                return (False, phone_reason)

        # Strategy 5: resolve by username then add by username.
        if uname:
            ok, uname_reason = await self._v44_add_by_username(
                app, target_chat_id, uname
            )
            if ok:
                return (True, uname_reason)
            return (False, uname_reason)

        return (False, f"cannot_add_user ({contact_reason or reason})")

    # -- v44 sub-strategies ------------------------------------------------

    async def _v44_add_by_id(
        self, app: Client, target_chat_id: int, user_id: int
    ) -> tuple[bool, str]:
        """Strategy 1: add_chat_members by user_id (cheapest)."""
        try:
            await app.add_chat_members(target_chat_id, int(user_id))
            return (True, "OK (id)")
        except UserAlreadyParticipant:
            return (True, "already_participant")
        except UserPrivacyRestricted:
            return (False, "UserPrivacyRestricted")
        except UserChannelsTooMuch:
            return (False, "UserChannelsTooMuch")
        except PeerFlood:
            return (False, "PeerFlood")
        except UserBannedInChannel:
            return (False, "UserBannedInChannel")
        except ChatAdminRequired:
            return (False, "ChatAdminRequired")
        except FloodWait as e:
            return (False, f"FloodWait {e.value}s")
        except UserKicked:
            return await self._v44_recover_from_kick(app, target_chat_id, user_id)
        except PeerIdInvalid:
            return (False, "PeerIdInvalid")
        except Exception as e:
            return (False, type(e).__name__)

    async def _v44_get_users_retry(
        self,
        app: Client,
        target_chat_id: int,
        user_id: int,
        prev_reason: str,
    ) -> tuple[bool, str]:
        """Strategy 2: get_users (forces peer refresh) then retry add."""
        try:
            user = await app.get_users(int(user_id))
            if not user:
                return (False, "PeerIdInvalid")
        except FloodWait as e:
            return (False, f"FloodWait {e.value}s")
        except PeerFlood:
            return (False, "PeerFlood")
        except Exception as e:
            return (False, f"{type(e).__name__}")
        # Retry add_chat_members.
        try:
            await app.add_chat_members(target_chat_id, int(user_id))
            return (True, "OK (get_users+id)")
        except UserAlreadyParticipant:
            return (True, "already_participant")
        except PeerIdInvalid:
            return (False, "PeerIdInvalid")
        except Exception as e:
            return (False, f"{type(e).__name__}")

    async def _v44_add_contact_first(
        self,
        app: Client,
        target_chat_id: int,
        user_id: int,
        name: str,
    ) -> tuple[bool, str]:
        """Strategy 3: add_contact then add_chat_members."""
        try:
            await app.add_contact(int(user_id), name or "Contact", last_name="")
            await asyncio.sleep(0.3)
        except UserPrivacyRestricted:
            return (False, "UserPrivacyRestricted")
        except FloodWait as e:
            return (False, f"FloodWait {e.value}s")
        except PeerFlood:
            return (False, "PeerFlood")
        except Exception:
            pass  # fall through to the add_chat_members attempt
        # Now retry add_chat_members.
        try:
            await app.add_chat_members(target_chat_id, int(user_id))
            self._queue_delete(user_id)
            return (True, "OK (contact+id)")
        except UserAlreadyParticipant:
            self._queue_delete(user_id)
            return (True, "already_participant")
        except Exception as e:
            return (False, f"{type(e).__name__}")

    async def _v44_phone_import_then_add(
        self,
        app: Client,
        target_chat_id: int,
        user_id: int,
        phone: str,
        name: str,
    ) -> tuple[bool, str]:
        """Strategy 4: import phone as contact, then add to group."""
        try:
            from pyrogram.types import InputPhoneContact

            await app.import_contacts(
                [
                    InputPhoneContact(
                        phone=phone,
                        first_name=name or "Contact",
                        last_name="",
                    )
                ]
            )
            await asyncio.sleep(0.5)
        except FloodWait as e:
            return (False, f"FloodWait {e.value}s")
        except PeerFlood:
            return (False, "PeerFlood")
        except Exception:
            pass
        # Retry add_chat_members.
        try:
            await app.add_chat_members(target_chat_id, int(user_id))
            self._queue_delete(user_id)
            return (True, "OK (phone+id)")
        except UserAlreadyParticipant:
            self._queue_delete(user_id)
            return (True, "already_participant")
        except Exception as e:
            return (False, f"{type(e).__name__}")

    async def _v44_add_by_username(
        self, app: Client, target_chat_id: int, uname: str
    ) -> tuple[bool, str]:
        """Strategy 5: resolve_peer by username, then add by username."""
        try:
            await app.resolve_peer(uname)
            await asyncio.sleep(0.5)
            await app.add_chat_members(target_chat_id, uname)
            return (True, "OK (username)")
        except UserAlreadyParticipant:
            return (True, "already_participant")
        except Exception as e:
            return (False, f"{type(e).__name__}")

    async def _v44_recover_from_kick(
        self, app: Client, target_chat_id: int, user_id: int
    ) -> tuple[bool, str]:
        """Sub-strategy: unban a previously-kicked user, then re-add."""
        try:
            await app.unban_chat_member(target_chat_id, int(user_id))
            await asyncio.sleep(1)
            await app.add_chat_members(target_chat_id, int(user_id))
            return (True, "OK (unbanned)")
        except Exception as e:
            return (False, f"USER_KICKED: {type(e).__name__}")

    # -- Batched delete_contacts ------------------------------------------

    def _queue_delete(self, user_id: int) -> None:
        """Queue ``user_id`` for batched delete_contacts."""
        self._pending_deletes.append(int(user_id))

    async def _flush_deletes(self, app: Client) -> None:
        """Flush any pending delete_contacts calls in a single batch."""
        if not self._pending_deletes:
            return
        # Deduplicate while preserving order.
        ids = list(dict.fromkeys(self._pending_deletes))
        self._pending_deletes.clear()
        try:
            await app.delete_contacts(ids)
            log.debug("Flushed %d delete_contacts", len(ids))
        except Exception as e:
            log.debug("delete_contacts batch failed: %s", e)

    # ------------------------------------------------------------------
    # Error handling & delay
    # ------------------------------------------------------------------

    async def _handle_error(
        self,
        reason: str,
        counter: ErrorCounter,
        phone: str,
        max_wait: int = 1800,
    ) -> bool:
        """Handle an error reason — return ``True`` if the loop should break.

        Smart thresholds:
        - PeerFlood → always break (account is rate-limited). The
          caller is responsible for marking the account as flooded via
          :class:`FloodTracker`.
        - FloodWait > ``max_wait`` → break (too long to wait).
        - ChatAdminRequired → break (no permission to add).
        - Otherwise → defer to :meth:`ErrorCounter.should_stop`.
        """
        kind = classify_error(reason)
        counter.add(kind)

        if "PeerFlood" in reason:
            log.error("%s: PeerFlood — stopping this account", phone)
            await self.flood_tracker.mark_flooded(phone)
            return True

        if "FloodWait" in reason:
            wait = extract_flood_seconds(reason) or 5
            log.warning("%s: FloodWait %ds", phone, wait)
            if wait > max_wait:
                log.error("%s: FloodWait too long — stopping", phone)
                return True
            await asyncio.sleep(wait)

        if "ChatAdminRequired" in reason:
            log.error("%s: admin required — stopping", phone)
            return True

        return counter.should_stop()

    async def _delay(self, delay: float, action_type: str = "add_member") -> None:
        """Apply a smart delay between actions."""
        await smart_delay(delay if delay > 0 else 1.0, action_type)
