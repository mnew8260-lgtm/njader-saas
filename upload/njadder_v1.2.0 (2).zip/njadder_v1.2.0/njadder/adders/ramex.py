"""Ramex adder: unified scraper + adder with multiple filter modes."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.enums import UserStatus
from pyrogram.errors import UserAlreadyParticipant

from ..config import Config
from ..core import DedupManager, ErrorCounter, OpReport, SessionManager, load_phones, progress_bar
from .base import BaseAdder, OperationResult

log = logging.getLogger(__name__)

# Modes from ramexfour.py
MODES = {"all", "hidden", "daily", "weekly", "monthly", "online", "nonactive"}


class RamexAdder(BaseAdder):
    """Unified ramex adder — scrape + add in one step.

    Modes:
    - 'all': add all members from source
    - 'hidden': scrape from chat history (hidden members)
    - 'daily': filter users seen today
    - 'weekly': filter users seen this week
    - 'monthly': filter users seen this month
    - 'online': only online users
    - 'nonactive': inactive users
    """

    async def run(
        self,
        source_group: str,
        target_group: str,
        max_per_account: int = 50,
        delay: float = 2.0,
        phones: list[str] | None = None,
        mode: str = "all",
    ) -> OperationResult:
        """Execute the ramex adder operation."""
        if mode not in MODES:
            log.error("Invalid mode '%s'. Valid: %s", mode, MODES)
            return OperationResult()

        if phones is None:
            phones = load_phones()
        if not phones:
            log.error("No phones available")
            return OperationResult()

        report = OpReport(f"ramex_{mode}")
        result = OperationResult()
        log.info("Starting RamexAdder (mode=%s): %d accounts", mode, len(phones))

        for idx, phone in enumerate(phones):
            log.info("Account %d/%d: %s", idx + 1, len(phones), phone)
            counter = ErrorCounter()
            added = 0
            skipped = 0

            try:
                async with self.session_mgr.acquire(phone) as app:
                    added, skipped = await self._process_account(
                        app=app, phone=phone,
                        source=source_group, target=target_group,
                        mode=mode,
                        max_per_account=max_per_account,
                        delay=delay, counter=counter, report=report,
                    )
            except Exception as e:
                log.error("%s: account failed: %s", phone, e)
                result.errors += 1

            result.success += added
            result.skipped += skipped
            result.add_account(phone, counter)
            log.info("%s: +%d added, %d skipped", phone, added, skipped)

        result.report_path = str(report.path)
        log.info("RamexAdder (%s) complete: %d added", mode, result.success)
        return result

    async def _process_account(
        self, app, phone, source, target, mode, max_per_account, delay, counter, report,
    ) -> tuple[int, int]:
        """Process a single account."""
        # Join both groups
        for grp in (source, target):
            try:
                await app.join_chat(grp)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("%s: failed to join %s: %s", phone, grp, e)
                return (0, 0)

        try:
            src_chat = await app.get_chat(source)
            tgt_chat = await app.get_chat(target)
        except Exception as e:
            log.error("%s: failed to resolve chats: %s", phone, e)
            return (0, 0)

        # Get existing target group members
        existing_members = set()
        try:
            async for m in app.get_chat_members(tgt_chat.id):
                if hasattr(m, "user") and hasattr(m.user, "id"):
                    existing_members.add(m.user.id)
        except Exception as e:
            log.warning("%s: get_chat_members failed: %s", phone, e)

        added = 0
        skipped = 0
        now = datetime.utcnow()

        if mode == "hidden":
            # Scrape from chat history
            try:
                async for msg in app.get_chat_history(src_chat.id, limit=500):
                    if not msg.from_user:
                        continue
                    user = msg.from_user
                    if user.id in existing_members or self.dedup.is_done(user.id):
                        skipped += 1
                        continue

                    ok, reason = await self._add_member_safe_v44(
                        app, tgt_chat.id, user.id,
                        {"first_name": user.first_name or "", "username": user.username or ""},
                    )
                    if ok:
                        added += 1
                        existing_members.add(user.id)
                        await self.dedup.mark_done(
                            user.id, user.first_name or "", user.last_name or "", user.username or "",
                        )
                        await report.log(
                            account=phone, user_id=user.id,
                            first=user.first_name or "", last=user.last_name or "",
                            username=user.username or "", status="added",
                        )
                    else:
                        skipped += 1
                        await report.log(
                            account=phone, user_id=user.id,
                            first=user.first_name or "", last=user.last_name or "",
                            username=user.username or "",
                            status="skipped", error_type=reason,
                        )
                        if await self._handle_error(reason, counter, phone):
                            break

                    if added >= max_per_account:
                        break
                    await self._delay(delay)
            except Exception as e:
                log.error("%s: hidden scrape failed: %s", phone, e)
        else:
            # Filter-based adders
            try:
                async for member in app.get_chat_members(src_chat.id):
                    user = member.user
                    if user.id in existing_members or self.dedup.is_done(user.id):
                        skipped += 1
                        continue

                    # Apply filter
                    if not self._matches_filter(user, mode, now):
                        continue

                    ok, reason = await self._add_member_safe_v44(
                        app, tgt_chat.id, user.id,
                        {"first_name": user.first_name or "", "username": user.username or ""},
                    )
                    if ok:
                        added += 1
                        existing_members.add(user.id)
                        await self.dedup.mark_done(
                            user.id, user.first_name or "", user.last_name or "", user.username or "",
                        )
                        await report.log(
                            account=phone, user_id=user.id,
                            first=user.first_name or "", last=user.last_name or "",
                            username=user.username or "", status="added",
                        )
                    else:
                        skipped += 1
                        await report.log(
                            account=phone, user_id=user.id,
                            first=user.first_name or "", last=user.last_name or "",
                            username=user.username or "",
                            status="skipped", error_type=reason,
                        )
                        if await self._handle_error(reason, counter, phone):
                            break

                    if added >= max_per_account:
                        break
                    await self._delay(delay)
            except Exception as e:
                log.error("%s: filter scrape failed: %s", phone, e)

        return (added, skipped)

    def _matches_filter(self, user, mode: str, now: datetime) -> bool:
        """Check if user matches the filter mode."""
        status = getattr(user.status, "value", None) if user.status else None
        last_seen = getattr(user.status, "last_online_date", None) if user.status else None

        if mode == "all":
            return True
        if mode == "online":
            return status == "online"
        if mode == "nonactive":
            if not last_seen:
                return True
            return (now - last_seen).days > 30
        if mode == "daily":
            return bool(last_seen) and (now - last_seen).days <= 1
        if mode == "weekly":
            return bool(last_seen) and (now - last_seen).days <= 7
        if mode == "monthly":
            return bool(last_seen) and (now - last_seen).days <= 30
        return True
