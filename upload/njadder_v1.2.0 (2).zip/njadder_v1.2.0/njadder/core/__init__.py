"""Core utilities and managers.

Public API:
    :class:`Config`           — config.ini wrapper (re-exported from ..config).
    :class:`SessionManager`   — per-phone Pyrogram session manager.
    :class:`DedupManager`     — 3-layer deduplication.
    :class:`ErrorCounter`     — smart error-threshold tracker.
    :class:`OpReport`         — CSV report generator.
    :class:`NjadderError`    — base exception for the package.
    + helpers: ``load_phones``, ``smart_delay``, ``progress_bar``,
               ``classify_error``, ``extract_flood_seconds``, ``chunk_list``.
"""
from __future__ import annotations

from .dedup import DedupManager
from .errors import (
    ConfigError,
    DataFileError,
    ErrorCounter,
    NjadderError,
    SessionError,
)
from .flood import FloodTracker
from .helpers import (
    chunk_list,
    classify_error,
    extract_flood_seconds,
    load_phones,
    progress_bar,
    smart_delay,
)
from .report import OpReport
from .secure_login import (
    build_secure_client_kwargs,
    check_all_proxies_before_start,
    get_api_for_account,
    get_device_for_account,
    get_working_proxy_for_account,
    print_resource_summary,
)
from .session import SessionManager

__all__ = [
    "ConfigError",
    "DataFileError",
    "DedupManager",
    "ErrorCounter",
    "FloodTracker",
    "NjadderError",
    "OpReport",
    "SessionError",
    "SessionManager",
    "build_secure_client_kwargs",
    "check_all_proxies_before_start",
    "chunk_list",
    "classify_error",
    "extract_flood_seconds",
    "get_api_for_account",
    "get_device_for_account",
    "get_working_proxy_for_account",
    "load_phones",
    "print_resource_summary",
    "progress_bar",
    "smart_delay",
]
