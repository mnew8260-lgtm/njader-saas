"""CSV utilities: clean, filter, deduplicate phone.csv.

Plus VCF extraction, phone-number validation, dedup cleanup, and
group-operations helpers (auto group maker, limit checker, group
chat cloner).
"""
from __future__ import annotations

import asyncio
import csv
import logging
import os
import random
import string
from pathlib import Path
from typing import Any

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# phone.csv maintenance
# ---------------------------------------------------------------------------

def csv_blank_remover(phone_file: str = "phone.csv") -> None:
    """Remove blank lines from ``phone_file`` (atomic write)."""
    p = Path(phone_file)
    if not p.exists():
        p.touch()
        print(f"[i] Created empty {phone_file}")
        return
    with open(p, "r", encoding="utf-8") as f:
        lines = f.readlines()
    clean = [line for line in lines if line.strip()]
    if len(lines) != len(clean):
        tmp = p.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(clean)
        os.replace(str(tmp), str(p))
        print(f"[+] Removed {len(lines) - len(clean)} blank lines")
    else:
        print("[i] No blank lines found")


def auto_remove(phone_file: str = "phone.csv", ban_file: str = "BanNumbers.csv") -> None:
    """Remove banned numbers (listed in ``ban_file``) from ``phone_file``."""
    p_phone = Path(phone_file)
    p_ban = Path(ban_file)
    if not p_phone.exists():
        print(f"[!] {phone_file} not found")
        return
    if not p_ban.exists():
        p_ban.touch()
        print(f"[i] No {ban_file} found — created empty. 0 banned numbers removed.")
        return
    with open(p_phone, "r", encoding="utf-8") as f:
        phones = {line.strip() for line in f if line.strip()}
    with open(p_ban, "r", encoding="utf-8") as f:
        banned = {line.strip().replace(",", "") for line in f if line.strip()}
    keep = phones - banned
    tmp = p_phone.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for ph in keep:
            f.write(ph + "\n")
    os.replace(str(tmp), str(p_phone))
    print(f"[+] Removed {len(phones) - len(keep)} banned numbers")


def ban_filter(phone_file: str = "phone.csv", ban_file: str = "BanNumbers.csv") -> int:
    """Run :func:`auto_remove` and report before/after counts."""
    p = Path(phone_file)
    if not p.exists():
        print(f"[!] {phone_file} not found")
        return 0
    with open(p, "r", encoding="utf-8") as f:
        before = sum(1 for line in f if line.strip())
    auto_remove(phone_file, ban_file)
    with open(p, "r", encoding="utf-8") as f:
        after = sum(1 for line in f if line.strip())
    print(f"[i] Before: {before}, After: {after}, Removed: {before - after}")
    return before - after


def specific_acc_remove(phone_file: str = "phone.csv") -> None:
    """Interactive removal of one phone number from ``phone_file``."""
    p = Path(phone_file)
    if not p.exists():
        print(f"[!] {phone_file} not found")
        return
    target = input("Enter phone number to remove: ").strip()
    if not target:
        return
    with open(p, "r", encoding="utf-8") as f:
        lines = f.readlines()
    keep = [line for line in lines if target not in line]
    tmp = p.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.writelines(keep)
    os.replace(str(tmp), str(p))
    print(f"[+] Removed {len(lines) - len(keep)} lines")


# ---------------------------------------------------------------------------
# LIVE Ban Check (NEW v1.2.1) — actually authenticate each account
# ---------------------------------------------------------------------------

async def check_banned_accounts_live(
    session_mgr: SessionManager,
    phone_file: str = "phone.csv",
    ban_file: str = "BanNumbers.csv",
    delay: float = 2.0,
    auto_remove_banned: bool = True,
) -> int:
    """Actually check each account by attempting to authenticate.

    For each phone in ``phone.csv``:
    1. Try to start the session and call ``get_me()``.
    2. If we get a ban error (UserDeactivated, UserDeactivatedBan, etc.),
       mark the phone as banned.
    3. If we succeed, mark the phone as healthy.
    4. Banned phones are appended to ``ban_file`` and removed from
       ``phone_file`` (with a backup to ``phone.csv.bak.<timestamp>``).

    Args:
        session_mgr: Shared session manager.
        phone_file: Path to phone.csv.
        ban_file: Path to BanNumbers.csv (will be created/appended).
        delay: Delay between accounts (seconds).
        auto_remove_banned: If True, remove banned phones from phone.csv
            automatically. If False, only report them.

    Returns:
        Number of banned accounts detected.
    """
    import asyncio as _a
    import csv as _csv
    import shutil
    from datetime import datetime

    try:
        from pyrogram.errors import (
            AuthKeyUnregistered,
            SessionRevoked,
            UserBannedInChannel,
            UserDeactivated,
            UserDeactivatedBan,
        )
        BAN_ERRORS = (
            UserDeactivated,
            UserDeactivatedBan,
            AuthKeyUnregistered,
            SessionRevoked,
            UserBannedInChannel,
        )
    except ImportError:
        log.error("pyrogram not installed — cannot check bans live")
        return 0

    p = Path(phone_file)
    if not p.exists():
        print(f"[!] {phone_file} not found")
        return 0

    phones = load_phones(phone_file)
    if not phones:
        print(f"[!] No phones in {phone_file}")
        return 0

    print()
    print("=" * 60)
    print("  LIVE BAN CHECKER — actually authenticates each account")
    print("=" * 60)
    print(f"  Total accounts: {len(phones)}")
    print(f"  Estimated time: ~{len(phones) * delay:.0f}s ({delay}s/account)")
    print(f"  Ban list file:  {ban_file}")
    print(f"  Auto-remove:    {'YES' if auto_remove_banned else 'NO (dry-run)'}")
    print("=" * 60)
    print()
    confirm = input("  Start ban check? [y/N]: ").strip().lower()
    if not confirm.startswith("y"):
        print("[i] Aborted")
        return 0

    print()
    banned: list[str] = []
    healthy: list[str] = []
    skipped_unknown: list[str] = []

    for idx, phone in enumerate(phones, 1):
        print(f"  [{idx}/{len(phones)}] {phone} ...", end=" ", flush=True)
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                name = (me.first_name or "?")
                print(f"OK ({name})")
                healthy.append(phone)
        except BAN_ERRORS as e:
            err_name = type(e).__name__
            print(f"BANNED ({err_name})")
            banned.append(phone)
        except Exception as e:
            err_name = type(e).__name__
            msg_upper = str(e).upper()
            if "FLOOD" in msg_upper or "TIMEOUT" in msg_upper or "CONNECTION" in msg_upper:
                print(f"NETWORK/FLOOD ({err_name}) — skip")
                skipped_unknown.append(phone)
            else:
                # Any other error — likely also banned or auth-failed.
                print(f"ERROR ({err_name})")
                # If the message includes "ban" or "deactivated", treat as banned.
                if "BAN" in msg_upper or "DEACTIVAT" in msg_upper:
                    banned.append(phone)
                else:
                    skipped_unknown.append(phone)

        if delay > 0:
            await _a.sleep(delay)

    # Summary.
    print()
    print("=" * 60)
    print("  BAN CHECK SUMMARY")
    print("=" * 60)
    print(f"  Total checked:  {len(phones)}")
    print(f"  Healthy:        {len(healthy)}")
    print(f"  BANNED:         {len(banned)}")
    print(f"  Skipped (net):  {len(skipped_unknown)}")
    print("=" * 60)

    if not banned:
        print()
        print("[i] No banned accounts detected. phone.csv unchanged.")
        return 0

    print()
    print("  Banned numbers:")
    for ph in banned:
        print(f"    - {ph}")
    print()

    if not auto_remove_banned:
        print("[i] Auto-remove disabled — phone.csv unchanged.")
        print(f"[i] To remove them manually, add these to {ban_file} and re-run [3].")
        return len(banned)

    # 1) Append banned phones to ban_file (no duplicates).
    ban_path = Path(ban_file)
    existing_banned: set[str] = set()
    if ban_path.exists():
        with open(ban_path, "r", encoding="utf-8") as f:
            for line in f:
                ph = line.strip().replace(",", "")
                if ph:
                    existing_banned.add(ph)

    new_banned = [ph for ph in banned if ph not in existing_banned]
    if new_banned:
        with open(ban_path, "a", encoding="utf-8") as f:
            for ph in new_banned:
                f.write(ph + "\n")
        print(f"[+] Appended {len(new_banned)} new banned numbers → {ban_file}")

    # 2) Backup phone.csv.
    backup = p.with_suffix(f".csv.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        shutil.copy2(p, backup)
        print(f"[+] Backed up {phone_file} → {backup}")
    except Exception as e:
        print(f"[!] Backup failed: {e} — aborting (no changes made)")
        return 0

    # 3) Rewrite phone.csv — keep healthy + skipped, remove banned.
    keep = healthy + skipped_unknown
    try:
        tmp = p.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            w = _csv.writer(f)
            for ph in keep:
                w.writerow([ph])
        import os as _os
        _os.replace(str(tmp), str(p))
        print(f"[+] Removed {len(banned)} banned accounts from {phone_file}")
        print(f"[+] Kept {len(keep)} accounts (healthy={len(healthy)}, skipped={len(skipped_unknown)})")
    except Exception as e:
        print(f"[!] Failed to rewrite {phone_file}: {e} — restoring from backup")
        shutil.copy2(backup, p)
        return 0

    return len(banned)


# ---------------------------------------------------------------------------
# VCF (vCard) extraction
# ---------------------------------------------------------------------------

def extract_vcf_to_numbers(
    vcf_path: str,
    out_path: str = "numbers.csv",
) -> int:
    """Extract phone numbers from a vCard (.vcf) file to a CSV.

    The output CSV has a single ``numbers`` column. Requires the
    optional ``vobject`` dependency (``pip install vobject``).
    """
    try:
        import vobject  # type: ignore[import]
    except ImportError:
        log.error("vobject not installed — run: pip install vobject")
        return 0

    p = Path(vcf_path)
    if not p.exists():
        log.error("VCF file not found: %s", vcf_path)
        return 0

    try:
        with open(p, "r", encoding="utf-8") as f:
            data = f.read()
    except Exception as e:
        log.error("Failed to read %s: %s", vcf_path, e)
        return 0

    numbers: list[str] = []
    try:
        for vcard in vobject.readComponents(data):
            if "tel" in vcard.contents:
                for tel in vcard.tel_list:
                    numbers.append(tel.value)
    except Exception as e:
        log.error("vobject parse error: %s", e)
        return 0

    with open(out_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["numbers"])
        for n in numbers:
            w.writerow([n])

    log.info("Extracted %d numbers → %s", len(numbers), out_path)
    return len(numbers)


# ---------------------------------------------------------------------------
# Phone-number validation (via Telegram API)
# ---------------------------------------------------------------------------

async def check_numbers(
    session_mgr: SessionManager,
    numbers_csv: str = "numbers.csv",
    out_csv: str = "filternumbers.csv",
    delay: float = 3.0,
) -> int:
    """Check which phone numbers are registered on Telegram.

    Uses the first account in ``phone.csv`` to call
    ``contacts.ResolvePhone`` for each number in ``numbers_csv``.
    Valid numbers are appended to ``filternumbers.csv``.

    Returns:
        Count of valid numbers.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv — needed to authenticate")
        return 0

    numbers_path = Path(numbers_csv)
    if not numbers_path.exists():
        log.error("%s not found", numbers_csv)
        return 0

    numbers: list[str] = []
    with open(numbers_path, "r", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows:
        log.error("%s is empty", numbers_csv)
        return 0
    # Skip a header row if the first cell is non-numeric.
    first_val = (rows[0][0] if rows[0] else "").strip()
    try:
        int(first_val.replace("+", "").replace("-", "").replace(" ", ""))
    except ValueError:
        rows = rows[1:]
    for row in rows:
        if row and row[0].strip():
            numbers.append(row[0].strip())

    from pyrogram.raw import functions

    valid = 0
    async with session_mgr.acquire(phones[0]) as app:
        for num in numbers:
            try:
                result = await app.invoke(
                    functions.contacts.ResolvePhone(phone=num)
                )
                if result and result.users:
                    valid += 1
                    with open(out_csv, "a", encoding="utf-8", newline="") as f:
                        csv.writer(f).writerow([num])
                    log.info("%s: valid (user_id=%s)", num, result.users[0].id)
                else:
                    log.info("%s: not a Telegram user", num)
            except Exception as e:
                log.warning("%s: %s", num, e)
            await asyncio.sleep(delay)

    log.info("Validation complete: %d valid / %d total", valid, len(numbers))
    return valid


# ---------------------------------------------------------------------------
# data.csv cleanup: delete already-done rows
# ---------------------------------------------------------------------------

def delete_already_filter(
    data_csv: str = "data.csv",
    done_csv: str = "done.csv",
) -> int:
    """Remove rows from ``data.csv`` whose user_id is already in ``done.csv``.

    Returns:
        Number of rows removed.
    """
    data_path = Path(data_csv)
    done_path = Path(done_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0
    if not done_path.exists():
        log.warning("%s not found — nothing to filter", done_csv)
        return 0

    # Load done user_ids.
    done_ids: set[str] = set()
    with open(done_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            uid = str(row.get("user_id", "") or "").strip()
            if uid:
                done_ids.add(uid)

    if not done_ids:
        log.info("done.csv has no user_ids — nothing to filter")
        return 0

    # Filter data.csv rows.
    kept_rows: list[dict[str, Any]] = []
    removed = 0
    fieldnames: list[str] = []
    with open(data_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or ["user_id"]
        for row in reader:
            uid = str(row.get("user_id", "") or "").strip()
            if uid in done_ids:
                removed += 1
            else:
                kept_rows.append(row)

    # Atomic rewrite.
    tmp = data_path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(kept_rows)
    os.replace(str(tmp), str(data_path))

    log.info("Removed %d already-done rows from %s", removed, data_csv)
    return removed


# ---------------------------------------------------------------------------
# Auto Group Maker — create supergroups with random usernames
# ---------------------------------------------------------------------------

def _random_username(length: int = 12) -> str:
    """Generate a random alphanumeric username of ``length`` chars."""
    return "".join(
        random.choice(string.ascii_letters + string.digits) for _ in range(length)
    )


async def auto_group_maker(
    session_mgr: SessionManager,
    per_account: int = 5,
    delay: float = 1.0,
) -> int:
    """Create ``per_account`` supergroups per account.

    Each group is given a random 12-character alphanumeric username.
    Returns the total number of groups created.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    created = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                for _ in range(per_account):
                    username = _random_username()
                    try:
                        await app.create_supergroup(username)
                        created += 1
                        log.info("%s: created supergroup %s", phone, username)
                        await smart_delay(delay, "fast")
                    except Exception as e:
                        log.warning("%s: create group failed: %s", phone, e)
                        break  # Move to next account on FloodWait-like errors.
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("auto_group_maker complete: %d groups created", created)
    return created


# ---------------------------------------------------------------------------
# Limit Checker & Remover (via @spambot)
# ---------------------------------------------------------------------------

SPAMBOT_USERNAME = "spambot"

# Known spambot response messages used for state-machine logic.
_NO_LIMIT_MSG = (
    "Good news, no limits are currently applied to your account. "
    "You're free as a bird!"
)
_HARSH_MSG = (
    "Unfortunately, some phone numbers may trigger a harsh response from "
    "our anti-spam systems."
)
_LIMITED_MSG_PREFIX = "Hello"

# Message sent to spambot's "describe what happened" prompt.
_COMplaint_TEXT = (
    "I'm a developer testing my application. I never sent any spam "
    "and would never do that. Please remove the limit."
)


async def limit_check_and_remove(session_mgr: SessionManager) -> int:
    """Check + auto-attempt to remove Telegram limits via @spambot.

    For each account: sends ``/start`` to @spambot, reads the
    response, and walks the spambot menu to submit a complaint.

    Returns:
        Number of accounts successfully processed (not necessarily
        unlimited — see logs for the per-account outcome).
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    processed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                ok = await _spambot_walk(app, phone)
                if ok:
                    processed += 1
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    log.info("limit_check_and_remove: %d/%d processed", processed, len(phones))
    return processed


async def _spambot_walk(app, phone: str) -> bool:
    """Walk @spambot's conversation flow for a single account."""
    try:
        await app.send_message(SPAMBOT_USERNAME, "/start")
        await asyncio.sleep(1.0)
        # Get latest message
        async for msg in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
            text = msg.text or ""
            break
        else:
            text = ""
        log.info("%s: spambot says: %s", phone, text[:80])

        if _NO_LIMIT_MSG in text:
            await app.send_message(SPAMBOT_USERNAME, "Cool, thanks")
            log.info("%s: no limit — all clear", phone)
            return True

        if _HARSH_MSG in text or "limited" in text.lower():
            # Submit a complaint automatically.
            await app.send_message(SPAMBOT_USERNAME, "This is a mistake")
            await asyncio.sleep(1.0)
            async for m2 in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                t2 = m2.text or ""
                break
            if "submit a complaint" in t2.lower():
                await app.send_message(SPAMBOT_USERNAME, "Yes")
                await asyncio.sleep(1.0)
                async for m3 in app.get_chat_history(SPAMBOT_USERNAME, limit=1):
                    t3 = m3.text or ""
                    break
                if "Please confirm" in t3 or "never send" in t3.lower():
                    await app.send_message(SPAMBOT_USERNAME, "No, I'll never do any of this!")
                    await asyncio.sleep(1.0)
                    await app.send_message(SPAMBOT_USERNAME, _COMplaint_TEXT)
                    log.info("%s: complaint submitted", phone)
                    return True
            log.warning("%s: limit detected but flow not followed", phone)
            return True

        log.info("%s: spambot returned unhandled response", phone)
        return True
    except Exception as e:
        log.error("%s: spambot walk failed: %s", phone, e)
        return False


# ---------------------------------------------------------------------------
# Group Chat Cloner — copy messages from one group to another
# ---------------------------------------------------------------------------

async def group_chat_cloner(
    session_mgr: SessionManager,
    source_group: str,
    target_group: str,
    num_messages: int = 100,
    delay: float = 2.0,
) -> int:
    """Clone the latest ``num_messages`` from ``source_group`` to ``target_group``.

    Uses ``app.copy_message`` so the messages arrive without a
    "forwarded from" tag.

    Args:
        session_mgr: Shared session manager.
        source_group: @username or link of the group to copy from.
        target_group: @username or link of the destination group.
        num_messages: How many recent messages to copy.
        delay: Delay between copies.

    Returns:
        Number of messages successfully copied.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    copied = 0
    # Use only the first account for cloning (others may not have
    # access to source group).
    phone = phones[0]
    try:
        async with session_mgr.acquire(phone) as app:
            from pyrogram.errors import UserAlreadyParticipant

            # Join both groups.
            for grp in (source_group, target_group):
                try:
                    await app.join_chat(grp)
                except UserAlreadyParticipant:
                    pass
                except Exception as e:
                    log.error("Failed to join %s: %s", grp, e)
                    return 0

            try:
                src = await app.get_chat(source_group)
                tgt = await app.get_chat(target_group)
            except Exception as e:
                log.error("Failed to resolve chats: %s", e)
                return 0

            # Collect message IDs (in chronological order).
            msg_ids: list[int] = []
            async for msg in app.get_chat_history(src.id, limit=num_messages):
                msg_ids.append(msg.id)
            msg_ids.reverse()  # oldest first

            for mid in msg_ids:
                try:
                    await app.copy_message(tgt.id, src.id, mid)
                    copied += 1
                    log.info("Copied msg %d → %s", mid, target_group)
                    await smart_delay(delay, "send_message")
                except Exception as e:
                    log.warning("Copy msg %d failed: %s", mid, e)
    except Exception as e:
        log.error("%s: clone failed: %s", phone, e)

    log.info("group_chat_cloner complete: %d copied", copied)
    return copied


# ---------------------------------------------------------------------------
# Live-group filter: remove rows from data.csv that are already in a target group
# ---------------------------------------------------------------------------

async def filter_data_csv_against_group(
    session_mgr: SessionManager,
    target_group: str,
    data_csv: str = "data.csv",
) -> int:
    """Remove rows from ``data.csv`` whose ``user_id`` is already a member
    of ``target_group``.

    This is the **live API filter** (vs. :func:`delete_already_filter`
    which uses ``done.csv``). It connects to Telegram, fetches the
    current members of the target group, and removes any matching
    rows from ``data.csv``.

    Args:
        session_mgr: Shared session manager (uses the first account).
        target_group: @username or chat ID of the target group.
        data_csv: Path to the data CSV file (default: ``data.csv``).

    Returns:
        Number of rows removed from ``data.csv``.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv — at least one needed to read group")
        return 0

    data_path = Path(data_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0

    from pyrogram.errors import UserAlreadyParticipant

    # Use only the first account — fetching members is a one-shot.
    phone = phones[0]
    try:
        async with session_mgr.acquire(phone) as app:
            # Join the target group first (so we can read its members).
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("Failed to join %s: %s", target_group, e)
                return 0

            try:
                chat = await app.get_chat(target_group)
            except Exception as e:
                log.error("Failed to resolve %s: %s", target_group, e)
                return 0

            # Fetch existing members (live API).
            existing_ids: set[str] = set()
            try:
                async for member in app.get_chat_members(chat_id=chat.id):
                    if hasattr(member, "user") and hasattr(member.user, "id"):
                        existing_ids.add(str(member.user.id))
            except Exception as e:
                log.error("get_chat_members failed: %s", e)
                return 0
            log.info("Found %d existing members in %s", len(existing_ids), target_group)

            # Read data.csv, filter, and rewrite.
            kept: list[dict[str, Any]] = []
            removed = 0
            fieldnames: list[str] = []
            with open(data_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                fieldnames = reader.fieldnames or ["user_id"]
                for row in reader:
                    uid = str(row.get("user_id", "") or "").strip()
                    if uid in existing_ids:
                        removed += 1
                    else:
                        kept.append(row)

            tmp = data_path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(kept)
            os.replace(str(tmp), str(data_path))

            log.info("Filtered %d rows from %s", removed, data_csv)
            return removed
    except Exception as e:
        log.error("%s: filter failed: %s", phone, e)
        return 0


# ---------------------------------------------------------------------------
# Single-account filter adder: add members from data.csv to a target group
# using ONE chosen account (by username).
# ---------------------------------------------------------------------------

async def single_filter_adder(
    session_mgr: SessionManager,
    target_group: str,
    account_index: int = 1,
    max_adds: int = 50,
    delay: float = 2.0,
    data_csv: str = "data.csv",
) -> int:
    """Add members from ``data.csv`` to ``target_group`` using a single account.

    The user picks which account to use by ``account_index`` (1-based).
    Members are added by **username** (not user_id) — this matches the
    behavior of the legacy ``singlefilteradderrr`` function.

    Args:
        session_mgr: Shared session manager.
        target_group: @username or link of the destination group.
        account_index: 1-based row index into ``phone.csv``.
        max_adds: Maximum members to add (default 50).
        delay: Delay between adds.
        data_csv: Path to the data CSV (default: ``data.csv``).

    Returns:
        Number of members added.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    if account_index < 1 or account_index > len(phones):
        log.error("account_index %d is out of range (1..%d)", account_index, len(phones))
        return 0

    phone = phones[account_index - 1]
    log.info("Using account %d: %s", account_index, phone)

    data_path = Path(data_csv)
    if not data_path.exists():
        log.error("%s not found", data_csv)
        return 0

    # Read all members from data.csv.
    members: list[dict[str, Any]] = []
    with open(data_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            uname = (row.get("username") or "").strip().lstrip("@")
            if uname:
                members.append(
                    {
                        "username": uname,
                        "first_name": (row.get("first_name") or "").strip(),
                        "last_name": (row.get("last_name") or "").strip(),
                    }
                )
    log.info("Loaded %d members from %s", len(members), data_csv)

    from pyrogram.errors import (
        ChatAdminRequired,
        FloodWait,
        PeerFlood,
        UserAlreadyParticipant,
        UserBannedInChannel,
        UserChannelsTooMuch,
        UserPrivacyRestricted,
        RPCError,
    )

    added = 0
    flood = peer = banned = stop_count = 0
    try:
        async with session_mgr.acquire(phone) as app:
            # Join target group.
            try:
                await app.join_chat(target_group)
            except UserAlreadyParticipant:
                pass
            except Exception as e:
                log.error("%s: failed to join %s: %s", phone, target_group, e)
                return 0
            try:
                chat = await app.get_chat(target_group)
            except Exception as e:
                log.error("%s: failed to resolve %s: %s", phone, target_group, e)
                return 0

            for member in members:
                if stop_count >= max_adds:
                    log.info("Reached limit: %d adds", max_adds)
                    break
                if flood >= 5 or peer >= 5 or banned >= 5:
                    log.warning("Too many errors — stopping (flood=%d, peer=%d, banned=%d)", flood, peer, banned)
                    break

                uname = member["username"]
                try:
                    await app.add_chat_members(chat.id, uname)
                    added += 1
                    stop_count += 1
                    log.info(
                        "%s: +%s added (%d/%d)",
                        phone, member["first_name"] or uname, stop_count, max_adds,
                    )
                    await smart_delay(delay, "add_member")
                except FloodWait as e:
                    flood += 1
                    log.warning("%s: FloodWait %ds", phone, e.value)
                    await asyncio.sleep(min(e.value, 60))
                except PeerFlood:
                    peer += 1
                    log.error("%s: PeerFlood", phone)
                    break
                except UserBannedInChannel:
                    banned += 1
                    log.warning("%s: UserBannedInChannel (%s)", phone, uname)
                except (UserPrivacyRestricted, UserChannelsTooMuch):
                    pass  # Skip silently — common, not an error.
                except RPCError as e:
                    log.warning("%s: %s", phone, type(e).__name__)
                except Exception as e:
                    log.error("%s: add %s failed: %s", phone, uname, e)
    except Exception as e:
        log.error("%s: account failed: %s", phone, e)

    log.info("single_filter_adder complete: %d added (stop=%d, flood=%d, peer=%d)", added, stop_count, flood, peer)
    return added


# ---------------------------------------------------------------------------
# Import VCF as contacts (addtocontactbyimp)
# ---------------------------------------------------------------------------

async def import_vcf_as_contacts(
    session_mgr: SessionManager,
    vcf_path: str,
    max_per_account: int = 50,
    delay: float = 2.0,
) -> int:
    """Import contacts from a VCF (vCard) file using all accounts.

    Reads the .vcf file, splits the contacts into chunks (one per
    account), and imports each chunk via :meth:`Client.import_contacts`.

    Requires the optional ``vobject`` dependency.

    Args:
        session_mgr: Shared session manager.
        vcf_path: Path to the .vcf file.
        max_per_account: Max contacts to import per account.
        delay: Delay between accounts.

    Returns:
        Total number of contacts imported.
    """
    try:
        import vobject  # type: ignore[import]
        from pyrogram.types import InputPhoneContact
    except ImportError:
        log.error("vobject not installed — run: pip install vobject")
        return 0

    p_path = Path(vcf_path)
    if not p_path.exists():
        log.error("VCF file not found: %s", vcf_path)
        return 0

    # Parse all vCards.
    contacts: list[dict[str, str]] = []
    try:
        with open(p_path, "r", encoding="utf-8") as f:
            data = f.read()
        for vcard in vobject.readComponents(data):
            if "tel" not in vcard.contents:
                continue
            fname = ""
            lname = ""
            if "n" in vcard.contents:
                n = vcard.contents["n"].value
                fname = getattr(n, "given", "") or ""
                lname = getattr(n, "family", "") or ""
            elif "fn" in vcard.contents:
                fname = vcard.contents["fn"].value or ""
            for tel in vcard.tel_list:
                contacts.append(
                    {
                        "phone": tel.value,
                        "first_name": fname or "Contact",
                        "last_name": lname,
                    }
                )
    except Exception as e:
        log.error("VCF parse error: %s", e)
        return 0

    if not contacts:
        log.error("No phone numbers found in %s", vcf_path)
        return 0

    log.info("Loaded %d contacts from %s", len(contacts), vcf_path)

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Chunk contacts across accounts.
    per = max(1, len(contacts) // len(phones))
    chunks = [contacts[i * per:(i + 1) * per] for i in range(len(phones))]
    remainder = contacts[len(phones) * per:]
    if chunks and remainder:
        chunks[-1].extend(remainder)

    imported_total = 0
    for idx, phone in enumerate(phones, 1):
        chunk = chunks[idx - 1] if idx - 1 < len(chunks) else []
        if not chunk:
            continue
        # Cap to max_per_account.
        chunk = chunk[:max_per_account]
        try:
            async with session_mgr.acquire(phone) as app:
                input_contacts = [
                    InputPhoneContact(
                        phone=c["phone"],
                        first_name=c["first_name"],
                        last_name=c["last_name"],
                    )
                    for c in chunk
                ]
                try:
                    result = await app.import_contacts(input_contacts)
                    n = len(result.imported) if result and result.imported else 0
                    imported_total += n
                    log.info("%s: imported %d contacts", phone, n)
                except Exception as e:
                    log.error("%s: import failed: %s", phone, e)
                await smart_delay(delay, "fast")
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("import_vcf_as_contacts complete: %d imported", imported_total)
    return imported_total


# ---------------------------------------------------------------------------
# Anonymous chatter (anonychatter) — send N messages to a chat from each account
# ---------------------------------------------------------------------------

async def anonymous_chatter(
    session_mgr: SessionManager,
    target_chat: str,
    message: str,
    num_per_account: int = 5,
    delay: float = 2.0,
) -> int:
    """Send ``num_per_account`` copies of ``message`` to ``target_chat``
    from each account in ``phone.csv``.

    Useful for inflating chat activity (e.g., making a new group look
    active) without revealing who sent each message.

    Args:
        session_mgr: Shared session manager.
        target_chat: Target @username or chat ID.
        message: The message text to repeat.
        num_per_account: How many messages each account should send.
        delay: Delay between sends.

    Returns:
        Total number of messages sent.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    from pyrogram.errors import UserAlreadyParticipant

    sent_total = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(target_chat)
                except UserAlreadyParticipant:
                    pass
                for i in range(num_per_account):
                    try:
                        await app.send_message(target_chat, message)
                        sent_total += 1
                        log.info("%s: msg %d/%d", phone, i + 1, num_per_account)
                        await smart_delay(delay, "send_message")
                    except Exception as e:
                        log.error("%s: send %d failed: %s", phone, i + 1, e)
                        break
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

    log.info("anonymous_chatter complete: %d sent", sent_total)
    return sent_total


# ---------------------------------------------------------------------------
# Auto Contact Delete (NEW v1.2.0)
# ---------------------------------------------------------------------------

async def auto_contact_delete(
    session_mgr: SessionManager,
    delay: float = 1.5,
    batch_size: int = 100,
) -> int:
    """Delete ALL contacts from every account in phone.csv.

    This iterates each account's contact list (limited to Telegram's
    contact-list endpoint, ~few thousand contacts per account) and removes
    every contact via the raw ``DeleteContact`` request, in batches.

    Args:
        session_mgr: Shared session manager.
        delay: Delay between accounts (after one account's contacts are
            fully cleared).
        batch_size: Number of contacts to delete per RPC request. Telegram
            allows up to ~100 per request.

    Returns:
        Total number of contacts deleted across all accounts.
    """
    from pyrogram.raw import functions, types

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    log.info("Auto-deleting contacts from %d accounts", len(phones))
    grand_total = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] %s: starting contact wipe", idx, len(phones), phone)
        try:
            async with session_mgr.acquire(phone) as app:
                # 1) Fetch the full contact list (this is a one-shot RPC).
                result = await app.invoke(functions.contacts.GetContacts())
                users = getattr(result, "users", []) or []
                if not users:
                    log.info("%s: no contacts to delete", phone)
                    continue

                # 2) Delete in batches of `batch_size` (max 100 per request).
                user_ids: list[int] = [u.id for u in users if getattr(u, "id", None)]
                if not user_ids:
                    continue

                deleted_here = 0
                for chunk_start in range(0, len(user_ids), batch_size):
                    chunk = user_ids[chunk_start: chunk_start + batch_size]
                    # Build InputUser list — use bare InputUser with id+access_hash.
                    input_users = []
                    for uid in chunk:
                        # Find the matching User object to get access_hash.
                        u = next((x for x in users if getattr(x, "id", None) == uid), None)
                        if u is None:
                            continue
                        access_hash = getattr(u, "access_hash", None)
                        if access_hash is None:
                            continue
                        input_users.append(
                            types.InputUser(id=uid, access_hash=access_hash)
                        )

                    if not input_users:
                        continue

                    try:
                        await app.invoke(
                            functions.contacts.DeleteContacts(id=input_users)
                        )
                        deleted_here += len(input_users)
                        log.info(
                            "%s: deleted %d/%d contacts (batch %d)",
                            phone, deleted_here, len(user_ids),
                            chunk_start // batch_size + 1,
                        )
                        # Small inter-batch delay to avoid FloodWait.
                        await smart_delay(1.0, "fast")
                    except Exception as e:
                        err_name = type(e).__name__
                        msg_upper = str(e).upper()
                        if "FLOOD" in msg_upper:
                            log.warning("%s: FloodWait during contact delete — pausing", phone)
                            # Extract wait seconds if possible.
                            try:
                                wait = int("".join(c for c in str(e) if c.isdigit()) or "30")
                            except Exception:
                                wait = 30
                            wait = min(wait, 60)
                            import asyncio as _a
                            await _a.sleep(wait)
                            # Retry once.
                            try:
                                await app.invoke(
                                    functions.contacts.DeleteContacts(id=input_users)
                                )
                                deleted_here += len(input_users)
                            except Exception as e2:
                                log.error("%s: retry failed: %s", phone, e2)
                        else:
                            log.error("%s: batch delete failed: %s", phone, err_name)

                grand_total += deleted_here
                log.info(
                    "%s: contact wipe complete — %d deleted",
                    phone, deleted_here,
                )
                await smart_delay(delay, "fast")
        except Exception as e:
            log.error("[%d/%d] %s: account-level failure: %s", idx, len(phones), phone, e)

    log.info("auto_contact_delete complete: %d contacts removed across %d accounts",
             grand_total, len(phones))
    return grand_total


# ---------------------------------------------------------------------------
# Post Views Increaser (NEW v1.2.0)
# ---------------------------------------------------------------------------

async def post_views_increaser(
    session_mgr: SessionManager,
    chat_link: str,
    max_post_id: int,
    delay_between_accounts: float = 2.0,
    delay_between_posts: float = 0.3,
) -> int:
    """Increase post views on a Telegram channel by reading posts.

    For each account, this iterates post IDs 1..max_post_id and calls
    ``messages.ReadHistory`` on the channel peer with that max_id, which
    marks the post as "read by this account" → Telegram increments the
    view counter.

    Args:
        session_mgr: Shared session manager.
        chat_link: Channel @username, t.me link, or invite link.
        max_post_id: Maximum post ID to read up to (start is always 1).
        delay_between_accounts: Pause between switching accounts.
        delay_between_posts: Pause between post IDs within one account.

    Returns:
        Total number of "post reads" performed across all accounts.
    """
    from pyrogram.raw import functions, types

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    if max_post_id < 1:
        log.error("max_post_id must be ≥ 1")
        return 0

    log.info(
        "Post Views Increaser: %d accounts × %d posts on %s",
        len(phones), max_post_id, chat_link,
    )

    grand_total = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] %s: starting view-increment pass",
                 idx, len(phones), phone)
        reads_this_account = 0
        try:
            async with session_mgr.acquire(phone) as app:
                # Resolve the chat link to a proper InputPeer (channel or chat).
                try:
                    chat = await app.get_chat(chat_link)
                except Exception as e:
                    log.error("%s: cannot resolve chat %s — %s", phone, chat_link, e)
                    continue

                chat_id = chat.id
                chat_type = chat.type.value if hasattr(chat.type, "value") else str(chat.type)

                # Build the right InputPeer for the raw RPC.
                if "channel" in chat_type.lower() or "supergroup" in chat_type.lower():
                    # Resolve to InputChannel.
                    try:
                        peer_input = await app.resolve_peer(chat_id)
                        # peer_input should be InputPeerChannel → convert to channel form.
                        if isinstance(peer_input, types.InputPeerChannel):
                            channel_input = types.InputChannel(
                                id=peer_input.channel_id,
                                access_hash=peer_input.access_hash,
                            )
                        elif isinstance(peer_input, types.InputChannel):
                            channel_input = peer_input
                        else:
                            log.error("%s: resolved peer is not a channel: %s",
                                      phone, type(peer_input).__name__)
                            continue
                    except Exception as e:
                        log.error("%s: resolve_peer failed: %s", phone, e)
                        continue
                else:
                    # For regular groups / private chats — use ReadHistory with the chat peer.
                    channel_input = None
                    try:
                        peer_input = await app.resolve_peer(chat_id)
                    except Exception as e:
                        log.error("%s: resolve_peer failed: %s", phone, e)
                        continue

                # Walk post IDs 1..max_post_id and mark each as read.
                # We use messages.ReadHistory for channels (with the channel peer)
                # which increments view counts.
                for post_id in range(1, max_post_id + 1):
                    try:
                        if channel_input is not None:
                            # Channels/supergroups: use channels.ReadHistory.
                            await app.invoke(
                                functions.channels.ReadHistory(
                                    channel=channel_input,
                                    max_id=post_id,
                                )
                            )
                        else:
                            # Regular chats/groups: use messages.ReadHistory.
                            await app.invoke(
                                functions.messages.ReadHistory(
                                    peer=peer_input,
                                    max_id=post_id,
                                )
                            )
                        reads_this_account += 1
                    except Exception as e:
                        err_name = type(e).__name__
                        msg_upper = str(e).upper()
                        if "FLOOD" in msg_upper:
                            log.warning(
                                "%s: FloodWait on post %d — pausing 30s",
                                phone, post_id,
                            )
                            import asyncio as _a
                            try:
                                wait = int("".join(c for c in str(e) if c.isdigit()) or "30")
                            except Exception:
                                wait = 30
                            await _a.sleep(min(wait, 60))
                            # Retry once.
                            try:
                                if channel_input is not None:
                                    await app.invoke(
                                        functions.channels.ReadHistory(
                                            channel=channel_input,
                                            max_id=post_id,
                                        )
                                    )
                                else:
                                    await app.invoke(
                                        functions.messages.ReadHistory(
                                            peer=peer_input,
                                            max_id=post_id,
                                        )
                                    )
                                reads_this_account += 1
                            except Exception as e2:
                                log.error("%s: post %d retry failed: %s",
                                          phone, post_id, e2)
                        elif "MESSAGE_ID_INVALID" in msg_upper or "HISTORY_START" in msg_upper:
                            # Post doesn't exist — skip silently.
                            pass
                        else:
                            log.debug("%s: post %d: %s", phone, post_id, err_name)

                    # Inter-post delay (very small).
                    if delay_between_posts > 0:
                        import asyncio as _a
                        await _a.sleep(delay_between_posts)

                log.info(
                    "%s: pass complete — %d/%d posts read",
                    phone, reads_this_account, max_post_id,
                )
                grand_total += reads_this_account
                await smart_delay(delay_between_accounts, "fast")
        except Exception as e:
            log.error("[%d/%d] %s: account-level failure: %s",
                      idx, len(phones), phone, e)

    log.info("post_views_increaser complete: %d total reads across %d accounts",
             grand_total, len(phones))
    return grand_total


# ---------------------------------------------------------------------------
# Make API ID and Hash Generator (NEW v1.2.0)
# ---------------------------------------------------------------------------

def make_api_id_hash_generator(
    out_csv: str = "api.csv",
    interactive: bool = True,
    append: bool = False,
) -> int:
    """Generate or collect api_id / api_hash pairs and write them to ``api.csv``.

    This is a HUMAN-IN-THE-LOOP helper, NOT an automated API-key creator.
    Telegram does not allow programmatic creation of api_id/api_hash pairs —
    you must register each manually at https://my.telegram.org → API Dev Tools.

    In **interactive** mode (default):
    1. Print step-by-step instructions for my.telegram.org.
    2. For each entry: prompt user to paste api_id + api_hash + label.
    3. Validate format (api_id: 5-12 digit integer, api_hash: 32-char hex).
    4. Write all valid pairs to ``api.csv`` with columns: api_id,api_hash,session_name.

    In **non-interactive** mode:
    1. Generate N placeholder pairs (with "REPLACE_ME" markers) so the user can
       fill them in later in a text editor.
    2. This is useful when preparing a template for a team.

    Args:
        out_csv: Output CSV file path.
        interactive: If True (default), prompt user for real values.
        append: If True, append to existing file; else overwrite.

    Returns:
        Number of API pairs written to ``out_csv``.
    """
    import csv as _csv

    API_ID_RE = "^[0-9]{5,12}$"
    API_HASH_RE = "^[0-9a-fA-F]{32}$"

    def _validate_api_id(s: str) -> bool:
        import re
        return bool(re.match(API_ID_RE, s or ""))

    def _validate_api_hash(s: str) -> bool:
        import re
        return bool(re.match(API_HASH_RE, s or ""))

    print()
    print("=" * 60)
    print("  API ID + HASH GENERATOR / COLLECTOR")
    print("=" * 60)
    print()
    print("This tool helps you populate api.csv with REAL api_id/api_hash")
    print("pairs — one per Telegram account. Each pair must be obtained")
    print("from https://my.telegram.org → API Dev Tools.")
    print()
    print("FORMAT:")
    print("  api_id     → 5-12 digit integer (e.g., '35923747')")
    print("  api_hash   → 32-char hex string (e.g., '6de1cf34ed1e68d94615ba7b45391dde')")
    print()
    print("OUTPUT:  " + out_csv + "  (columns: api_id,api_hash,session_name)")
    print()

    pairs: list[tuple[str, str, str]] = []

    if not interactive:
        # Template mode — write N placeholder rows.
        try:
            n = int(input("How many placeholder rows? [10]: ").strip() or "10")
        except (ValueError, EOFError, KeyboardInterrupt):
            n = 10
        for i in range(1, n + 1):
            pairs.append(("REPLACE_ME_API_ID_" + str(i),
                          "REPLACE_ME_API_HASH_" + str(i),
                          "session_" + str(i)))
        print(f"[i] Generated {n} placeholder rows → {out_csv}")
        print(f"[i] Open {out_csv} in a text editor and replace the REPLACE_ME_* values.")
    else:
        # Interactive mode — walk the user through entering real pairs.
        print("STEP-BY-STEP:")
        print("  1. Open https://my.telegram.org in your browser.")
        print("  2. Login with your phone number (the account you want the API for).")
        print("  3. Click 'API development tools'.")
        print("  4. Fill in any app name + short name (use 'njadder_<account_num>').")
        print("  5. Copy the api_id and api_hash that appear.")
        print("  6. Paste them below when prompted.")
        print()
        print("Type 'done' at any prompt to finish and save.")
        print()

        while True:
            label = input(f"Account label [session_{len(pairs) + 1}]: ").strip()
            if label.lower() == "done":
                break
            if not label:
                label = f"session_{len(pairs) + 1}"

            api_id_input = input("  api_id: ").strip()
            if api_id_input.lower() == "done":
                break
            if not _validate_api_id(api_id_input):
                print(f"  [!] Invalid api_id format (need 5-12 digits) — try again.")
                continue

            api_hash_input = input("  api_hash: ").strip()
            if api_hash_input.lower() == "done":
                break
            if not _validate_api_hash(api_hash_input):
                print(f"  [!] Invalid api_hash format (need 32 hex chars) — try again.")
                continue

            pairs.append((api_id_input, api_hash_input, label))
            print(f"  [+] Added pair #{len(pairs)}: api_id={api_id_input} → {label}")
            print()

    if not pairs:
        print("[!] No pairs to write — nothing saved.")
        return 0

    # Write to CSV.
    mode = "a" if append else "w"
    try:
        with open(out_csv, mode, encoding="utf-8", newline="") as f:
            w = _csv.writer(f)
            if mode == "w":
                w.writerow(["api_id", "api_hash", "session_name"])
            for api_id, api_hash, label in pairs:
                w.writerow([api_id, api_hash, label])
        print()
        print(f"[+] Wrote {len(pairs)} API pair(s) to {out_csv}")
        if append:
            print(f"    (appended to existing file)")
        else:
            print(f"    (file overwritten)")
    except Exception as e:
        print(f"[!] Failed to write {out_csv}: {e}")
        return 0

    print()
    print("NEXT STEPS:")
    print(f"  1. Use SECURE LOGIN from the Accounts menu — it reads {out_csv} automatically.")
    print(f"  2. Each account will be logged in with its own unique API pair.")
    print(f"  3. This significantly reduces PeerFlood risk on multi-account setups.")
    return len(pairs)

