#!/usr/bin/env python3
"""Entry point for ``python -m njadder``.

Supports a small set of CLI flags:
- ``--config PATH``: override the config.ini path.
- ``--log PATH``: override the log file path (default: njadder.log).
- ``--no-color``: disable colored output.
- ``-v`` / ``--verbose``: enable DEBUG logging for the ``njadder`` logger.
- ``--version``: print the version and exit.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import traceback

from . import __version__

_DEFAULT_LOG_FILE = "njadder.log"


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="njadder",
        description="Professional Telegram automation suite.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to config.ini (default: ./config.ini or $NJADDER_CONFIG).",
    )
    parser.add_argument(
        "--log",
        type=str,
        default=_DEFAULT_LOG_FILE,
        help=f"Path to the log file (default: {_DEFAULT_LOG_FILE}).",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored terminal output.",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable DEBUG-level logging for the njadder package.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"njadder {__version__}",
    )
    return parser


def setup_logging(
    log_file: str = _DEFAULT_LOG_FILE,
    verbose: bool = False,
) -> None:
    """Configure root logging + silence noisy upstream loggers."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )

    # Silence Pyrogram / Telethon's noisy internal loggers.
    for noisy in (
        "pyrogram",
        "pyrogram.session",
        "pyrogram.session.auth",
        "pyrogram.session.session",
        "pyrogram.connection",
        "pyrogram.connection.connection",
        "pyrogram.dispatcher",
        "pyrogram.crypto",
        "pyrogram.crypto.aes",
        "telethon",
        "telethon.crypto",
        "telethon.crypto.aes",
    ):
        lg = logging.getLogger(noisy)
        lg.disabled = True
        lg.propagate = False

    # Pyrogram sometimes logs the cosmetic "Cannot operate on a closed
    # database" warning through the asyncio logger (level ERROR).
    # Suppress those specific messages — they don't affect functionality.
    class _ClosedDatabaseFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            try:
                msg = record.getMessage()
            except Exception:
                return True
            # Drop the noisy pyrogram background-task warnings.
            if "Cannot operate on a closed database" in msg:
                return False
            if "Task exception was never retrieved" in msg:
                return False
            return True

    asyncio_log = logging.getLogger("asyncio")
    asyncio_log.addFilter(_ClosedDatabaseFilter())

    # Install a custom asyncio exception handler that swallows the
    # cosmetic "Cannot operate on a closed database" errors from
    # pyrogram's background update handlers. Real exceptions are still
    # logged (at WARNING level) — we just suppress the noisy cosmetic
    # ones to keep the log readable.
    def _silent_async_exception_handler(loop, context):
        exc = context.get("exception")
        if exc is not None:
            msg_text = str(exc)
            if "Cannot operate on a closed database" in msg_text:
                return  # Swallow — purely cosmetic.
            # For everything else, log at WARNING (default is to crash).
            log.warning(
                "Asyncio background task error: %s",
                context.get("message", str(exc)),
            )
            return
        # No exception object — fall back to default behavior.
        loop.default_exception_handler(context)

    try:
        # Python 3.10-3.13: global asyncio exception handler.
        asyncio.set_exception_handler(_silent_async_exception_handler)
    except (RuntimeError, AttributeError):
        # RuntimeError: no running loop yet (Python 3.10-3.13).
        # AttributeError: set_exception_handler removed in Python 3.14+.
        # In 3.14+, we'll set the handler per-loop instead.
        try:
            # Python 3.14+: get the running loop (if any) and set on it.
            running_loop = asyncio.get_running_loop()
            running_loop.set_exception_handler(_silent_async_exception_handler)
        except (RuntimeError, AttributeError):
            # No running loop at startup — that's fine. The menu will
            # create its own loop via asyncio.run() later, and any
            # cosmetic "Cannot operate on a closed database" warnings
            # will simply be logged (noisy but harmless).
            pass

    # Re-enable our own logger and set its level.
    njadder_log = logging.getLogger("njadder")
    njadder_log.disabled = False
    njadder_log.setLevel(level)


def main(argv: list[str] | None = None) -> int:
    """Program entry point. Returns the process exit code."""
    parser = _build_arg_parser()
    args = parser.parse_args(argv)

    if args.no_color:
        os.environ["NO_COLOR"] = "1"

    setup_logging(log_file=args.log, verbose=args.verbose)

    if args.config:
        # Tell the Config singleton to use the explicit path.
        os.environ["NJADDER_CONFIG"] = args.config

    try:
        from .ui.menu import main_menu

        main_menu()
        return 0
    except KeyboardInterrupt:
        print("\n[i] Stopped by user")
        return 0
    except SystemExit:
        return 0
    except Exception as e:
        print(f"[!] Error: {e}")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
