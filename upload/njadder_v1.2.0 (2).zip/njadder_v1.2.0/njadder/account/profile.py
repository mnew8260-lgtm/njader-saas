"""Account profile tools: change name, set profile pic, etc."""
from __future__ import annotations

import asyncio
import logging
import random
import string
from pathlib import Path

from pyrogram import Client

from ..config import Config, get_config
from ..core import SessionManager, load_phones, smart_delay

log = logging.getLogger(__name__)


async def changer_account(session_mgr: SessionManager) -> int:
    """Change first name, last name, and bio for all accounts."""
    phones = load_phones()
    if not phones:
        return 0

    first_name = input("Enter first name: ").strip()
    last_name = input("Enter last name (or empty): ").strip()
    bio = input("Enter bio (or empty): ").strip()

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                from pyrogram.raw import functions

                await app.invoke(
                    functions.account.UpdateProfile(
                        first_name=first_name,
                        last_name=last_name or "",
                        about=bio or "",
                    )
                )
                changed += 1
                log.info("%s: profile changed", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return changed


async def set_username(session_mgr: SessionManager, username: str) -> int:
    """Set the same username on all accounts.

    Note: Telegram usernames are globally unique — only the first
    account will succeed; subsequent accounts will get a
    ``UsernameOccupied`` error. For per-account unique usernames
    use :func:`set_usernames_from_csv`.

    Performs pre-validation and gives actionable error messages for
    common Telegram rejections:
    - ``USERNAME_PURCHASE_AVAILABLE`` → reserved for Telegram Premium.
    - ``USERNAME_OCCUPIED``            → taken by another user.
    - ``USERNAME_INVALID``            → bad format (5-32 chars, a-zA-Z0-9_).
    - ``USERNAME_NOT_MODIFIED``       → already set to that value.
    """
    username = (username or "").strip().lstrip("@")
    if not username:
        log.error("Empty username — nothing to set")
        return 0

    # Pre-validate format (cheap, no API call).
    issues = _validate_username_format(username)
    if issues:
        log.error("Username @%s fails validation: %s", username, "; ".join(issues))
        log.error(
            "Tips: use 5-32 chars, start with a letter, "
            "alphanumeric + underscores only. Avoid short/dictionary words."
        )
        return 0

    phones = load_phones()
    if not phones:
        return 0

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                await app.set_username(username)
                changed += 1
                log.info("%s: username set to @%s", phone, username)
                await smart_delay(2.0, "fast")
        except Exception as e:
            reason = _classify_username_error(e)
            log.error("%s: failed — %s", phone, reason)
            # Stop early if the username is unusable globally.
            if reason.startswith(("PURCHASE_AVAILABLE", "OCCUPIED")):
                log.error(
                    "Stopping — username @%s cannot be used on ANY account: %s",
                    username, reason,
                )
                break

    if changed == 0:
        log.error(
            "FAILED on all accounts. Username @%s is not usable. "
            "Try: (1) a longer username (8+ chars), "
            "(2) add digits/underscores, (3) use set_usernames_from_csv.",
            username,
        )
    else:
        log.info("set_username complete: %d/%d accounts now @%s", changed, len(phones), username)
    return changed


def _validate_username_format(username: str) -> list[str]:
    """Return a list of validation issues for ``username`` (empty if OK).

    Telegram rules:
    - 5-32 chars
    - alphanumeric + underscores
    - must start with a letter
    - cannot end with underscore
    - cannot have consecutive underscores
    """
    issues: list[str] = []
    if len(username) < 5:
        issues.append(f"too short ({len(username)} < 5)")
    if len(username) > 32:
        issues.append(f"too long ({len(username)} > 32)")
    if username and not username[0].isalpha():
        issues.append("must start with a letter")
    if username and username.endswith("_"):
        issues.append("cannot end with underscore")
    if "__" in username:
        issues.append("cannot have consecutive underscores")
    allowed = set(string.ascii_lowercase + string.ascii_uppercase + string.digits + "_")
    bad_chars = [c for c in username if c not in allowed]
    if bad_chars:
        issues.append(f"invalid chars: {''.join(bad_chars)}")
    return issues


def _classify_username_error(e: Exception) -> str:
    """Map a Pyrogram exception to a short, actionable reason string.

    Telegram returns several username-specific errors that pyrogram
    does not all wrap in named exception classes — we detect them
    via the message text.
    """
    msg = str(e).upper()
    # Check for the literal RPC error name in the message.
    if "USERNAME_PURCHASE_AVAILABLE" in msg:
        return ("PURCHASE_AVAILABLE — username reserved for Telegram Premium "
                "users. Use a longer/different name (e.g., add 3+ digits).")
    if "USERNAME_OCCUPIED" in msg:
        return "OCCUPIED — username is already taken by another user."
    if "USERNAME_INVALID" in msg:
        return "INVALID — bad format (5-32 chars, starts with letter, a-zA-Z0-9_)."
    if "USERNAME_NOT_MODIFIED" in msg:
        return "NOT_MODIFIED — same as current username (skip)."
    if "USERNAME_NOT_OCCUPIED" in msg:
        return "NOT_OCCUPIED — username not assigned to anyone (unexpected)."
    if "USERNAME_PURCHASE_AVAILABLE" in msg:
        return "PURCHASE_AVAILABLE"
    # Fall back to the exception type name.
    return type(e).__name__


async def set_usernames_from_csv(
    session_mgr: SessionManager,
    phone_csv: str = "phone.csv",
    username_csv: str = "username.csv",
) -> int:
    """Set per-account usernames from a CSV file.

    ``phone.csv`` and ``username.csv`` must have the same number of
    rows; row ``i`` of ``phone.csv`` is paired with row ``i`` of
    ``username.csv``. Each row gets its own unique username.

    Skips rows with invalid format and reports the per-row reason
    if Telegram rejects the username.
    """
    phone_path = Path(phone_csv)
    uname_path = Path(username_csv)
    if not phone_path.exists() or not uname_path.exists():
        log.error("Both %s and %s must exist", phone_csv, username_csv)
        return 0

    phones = _read_first_column(phone_path)
    usernames = _read_first_column(uname_path)
    if len(phones) != len(usernames):
        log.error(
            "Row count mismatch: %s has %d, %s has %d",
            phone_csv, len(phones), username_csv, len(usernames),
        )
        return 0

    changed = 0
    for phone, username in zip(phones, usernames):
        username = (username or "").strip().lstrip("@")
        if not username:
            log.warning("%s: empty username in CSV — skipped", phone)
            continue

        # Pre-validate format.
        issues = _validate_username_format(username)
        if issues:
            log.error(
                "%s: @%s fails validation — %s",
                phone, username, "; ".join(issues),
            )
            continue

        try:
            async with session_mgr.acquire(phone) as app:
                await app.set_username(username)
                changed += 1
                log.info("%s: username set to @%s", phone, username)
                await smart_delay(2.0, "fast")
        except Exception as e:
            reason = _classify_username_error(e)
            log.error("%s: @%s failed — %s", phone, username, reason)

    log.info(
        "set_usernames_from_csv complete: %d/%d succeeded",
        changed, len(phones),
    )
    return changed


async def set_profile_pic(session_mgr: SessionManager, photo_path: str) -> int:
    """Set profile picture for all accounts."""
    phones = load_phones()
    if not phones:
        return 0

    if not Path(photo_path).exists():
        log.error("Photo not found: %s", photo_path)
        return 0

    changed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                from pyrogram.raw.functions.photos import UploadProfilePhotoRequest

                file = await app.upload_file(photo_path)
                await app.invoke(UploadProfilePhotoRequest(file=file))
                changed += 1
                log.info("%s: profile pic set", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return changed


async def remove_profile_pic(session_mgr: SessionManager) -> int:
    """Remove all profile pictures from each account."""
    phones = load_phones()
    if not phones:
        return 0

    removed = 0
    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                # Collect chat photos (sync iterator — wrap in list).
                photos = []
                async for photo in app.get_chat_photos("me"):
                    photos.append(photo)
                if photos:
                    file_ids = [p.file_id for p in photos]
                    await app.delete_profile_photos(file_ids)
                    removed += 1
                    log.info("%s: removed %d profile photo(s)", phone, len(photos))
                else:
                    log.info("%s: no profile photos to remove", phone)
                await smart_delay(2.0, "fast")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)

    return removed


def random_username(length: int = 10, prefix: str = "") -> str:
    """Generate a random valid Telegram username.

    Telegram usernames:
    - Must be 5-32 characters.
    - Alphanumeric + underscores.
    - Must start with a letter.

    Default length is 10 (not 5) because short usernames are often
    reserved for Telegram Premium and trigger
    ``USERNAME_PURCHASE_AVAILABLE`` errors. 10+ chars rarely have
    that problem.
    """
    if length < 5:
        length = 5
    if length > 32:
        length = 32
    # First char must be a letter.
    first = random.choice(string.ascii_lowercase)
    rest = "".join(
        random.choice(string.ascii_lowercase + string.digits + "_")
        for _ in range(length - 1)
    )
    return f"{prefix}{first}{rest}"


def generate_usernames_file(
    n: int,
    out_path: str = "username.csv",
    length: int = 10,
) -> int:
    """Generate ``n`` random usernames and write them to ``out_path``.

    Useful for preparing ``username.csv`` before calling
    :func:`set_usernames_from_csv`.
    """
    out = Path(out_path)
    seen: set[str] = set()
    usernames: list[str] = []
    while len(usernames) < n:
        u = random_username(length=length)
        if u in seen:
            continue
        seen.add(u)
        usernames.append(u)
    with open(out, "w", encoding="utf-8", newline="") as f:
        import csv as _csv

        w = _csv.writer(f)
        for u in usernames:
            w.writerow([u])
    log.info("Generated %d usernames → %s", len(usernames), out_path)
    return len(usernames)


# ---------------------------------------------------------------------------
# Set Random Realistic Name (NEW v1.2.0)
# ---------------------------------------------------------------------------

# Realistic name pools. Curated to look like real Telegram users —
# mix of common Arabic + Gulf + Western names. Each first-name is paired
# with a fitting last-name from the same pool to keep cultural consistency.
_BOY_NAMES: list[tuple[str, str]] = [
    ("Ahmed", "Al-Harbi"), ("Mohammed", "Al-Qahtani"), ("Khalid", "Al-Otaibi"),
    ("Abdullah", "Al-Dossari"), ("Saud", "Al-Mutairi"), ("Faisal", "Al-Anazi"),
    ("Omar", "Al-Shehri"), ("Yousef", "Al-Subaie"), ("Salem", "Al-Ghamdi"),
    ("Hassan", "Al-Zahrani"), ("Ali", "Al-Maliki"), ("Hussein", "Al-Amri"),
    ("Nasser", "Al-Balawi"), ("Sultan", "Al-Hajri"), ("Mansour", "Al-Rashidi"),
    ("Tariq", "Al-Enazi"), ("Majed", "Al-Shammari"), ("Bandar", "Al-Harbi"),
    ("Nawaf", "Al-Otaibi"), ("Abdulaziz", "Al-Saud"), ("Rayan", "Al-Qarni"),
    ("Hamza", "Al-Asmari"), ("Bilal", "Al-Juhani"), ("Taleb", "Al-Khalifa"),
    ("Waleed", "Al-Sayed"), ("Salman", "Al-Ahmad"), ("Yara", "Al-Nasser"),
    ("Adel", "Al-Faris"), ("Marwan", "Al-Rasheed"), ("Karim", "Al-Mansour"),
    ("James", "Smith"), ("John", "Davis"), ("Michael", "Brown"),
    ("David", "Wilson"), ("Daniel", "Taylor"), ("Joseph", "Anderson"),
    ("Henry", "Thomas"), ("Samuel", "Moore"), ("Anthony", "Martin"),
    ("Matthew", "Lee"), ("Christopher", "Hill"), ("Andrew", "Walker"),
    ("Joshua", "Hall"), ("Ryan", "Young"), ("Ethan", "King"),
    ("Lucas", "Wright"), ("Liam", "Lopez"), ("Noah", "Hill"),
    ("Mason", "Scott"), ("Logan", "Green"),
]

_GIRL_NAMES: list[tuple[str, str]] = [
    ("Sarah", "Al-Harbi"), ("Fatimah", "Al-Qahtani"), ("Aisha", "Al-Otaibi"),
    ("Maryam", "Al-Dossari"), ("Noura", "Al-Mutairi"), ("Layla", "Al-Anazi"),
    ("Hessa", "Al-Shehri"), ("Reem", "Al-Subaie"), ("Amna", "Al-Ghamdi"),
    ("Shahad", "Al-Zahrani"), ("Maha", "Al-Maliki"), ("Latifa", "Al-Amri"),
    ("Alanoud", "Al-Balawi"), ("Shaikha", "Al-Hajri"), ("Moza", "Al-Rashidi"),
    ("Bodor", "Al-Enazi"), ("Latifa", "Al-Shammari"), ("Asma", "Al-Harbi"),
    ("Dana", "Al-Otaibi"), ("Joud", "Al-Saud"), ("Raghad", "Al-Qarni"),
    ("Lina", "Al-Asmari"), ("Hanan", "Al-Juhani"), ("Asmaa", "Al-Khalifa"),
    ("Munira", "Al-Sayed"), ("Sara", "Al-Ahmad"), ("Arwa", "Al-Nasser"),
    ("Eman", "Al-Faris"), ("Habiba", "Al-Rasheed"), ("Salma", "Al-Mansour"),
    ("Emily", "Smith"), ("Sarah", "Davis"), ("Olivia", "Brown"),
    ("Emma", "Wilson"), ("Sophia", "Taylor"), ("Isabella", "Anderson"),
    ("Charlotte", "Thomas"), ("Amelia", "Moore"), ("Mia", "Martin"),
    ("Ava", "Lee"), ("Harper", "Hill"), ("Evelyn", "Walker"),
    ("Abigail", "Hall"), ("Ella", "Young"), ("Scarlett", "King"),
    ("Grace", "Wright"), ("Chloe", "Lopez"), ("Victoria", "Hill"),
    ("Riley", "Scott"), ("Avery", "Green"),
]


def _pick_random_realistic_name(gender: str = "any") -> tuple[str, str]:
    """Pick a random realistic (first, last) name pair.

    Args:
        gender: "boy", "girl", or "any" (random choice of boy/girl first).

    Returns:
        Tuple of (first_name, last_name).
    """
    if gender == "boy":
        return random.choice(_BOY_NAMES)
    if gender == "girl":
        return random.choice(_GIRL_NAMES)
    # "any" → flip a coin to pick boy or girl.
    pool = _BOY_NAMES if random.random() < 0.5 else _GIRL_NAMES
    return random.choice(pool)


async def set_random_realistic_name(
    session_mgr: SessionManager,
    gender: str = "any",
    use_unique_per_account: bool = True,
    delay: float = 2.0,
) -> int:
    """Set a random realistic first+last name on every account.

    Each account gets a unique (first, last) pair by default — meaning
    no two accounts share the same name. Set ``use_unique_per_account=False``
    to allow duplicates.

    Args:
        session_mgr: Shared session manager.
        gender: "boy", "girl", or "any".
        use_unique_per_account: If True, ensure each account gets a
            unique (first, last) pair — re-pick if collision.
        delay: Delay between accounts.

    Returns:
        Number of accounts successfully updated.
    """
    from pyrogram.raw import functions

    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    log.info("Setting random realistic names on %d accounts (gender=%s)", len(phones), gender)

    used_names: set[tuple[str, str]] = set()
    changed = 0

    for idx, phone in enumerate(phones, 1):
        # Pick a unique name for this account.
        attempts = 0
        first_name, last_name = _pick_random_realistic_name(gender)
        while use_unique_per_account and (first_name, last_name) in used_names:
            first_name, last_name = _pick_random_realistic_name(gender)
            attempts += 1
            if attempts > 50:
                # Pool exhausted — accept the duplicate.
                break
        used_names.add((first_name, last_name))

        try:
            async with session_mgr.acquire(phone) as app:
                await app.invoke(
                    functions.account.UpdateProfile(
                        first_name=first_name,
                        last_name=last_name,
                        about="",  # Leave bio empty for realism.
                    )
                )
                changed += 1
                log.info(
                    "[%d/%d] %s: name set to %s %s",
                    idx, len(phones), phone, first_name, last_name,
                )
                await smart_delay(delay, "fast")
        except Exception as e:
            log.error("[%d/%d] %s: failed — %s", idx, len(phones), phone, e)

    log.info(
        "set_random_realistic_name complete: %d/%d succeeded",
        changed, len(phones),
    )
    return changed


async def account_info_getter() -> None:
    """Get account info for all accounts."""
    cfg = get_config()
    session_mgr = SessionManager()
    phones = load_phones()
    if not phones:
        return

    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                print(f"\n{phone}:")
                print(f"  Name: {me.first_name or ''} {me.last_name or ''}")
                print(f"  Username: @{me.username}" if me.username else "  Username: -")
                print(f"  ID: {me.id}")
                print(f"  Phone: +{me.phone_number}" if getattr(me, "phone_number", None) else "  Phone: -")
        except Exception as e:
            log.error("%s: failed: %s", phone, e)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_first_column(path: Path) -> list[str]:
    """Read the first column of a CSV into a list of strings."""
    result: list[str] = []
    import csv as _csv

    with open(path, "r", encoding="utf-8") as f:
        for row in _csv.reader(f):
            if row and row[0].strip():
                result.append(row[0].strip())
    return result
