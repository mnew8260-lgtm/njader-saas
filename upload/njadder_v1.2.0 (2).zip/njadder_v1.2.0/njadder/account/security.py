"""Account security tools: login, OTP viewer, 2FA setup."""
from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING

from pyrogram.errors import UserAlreadyParticipant

from ..config import get_config
from ..core import SessionManager, load_phones, smart_delay

if TYPE_CHECKING:
    from pyrogram import Client

log = logging.getLogger(__name__)

# Telegram's official OTP sender chat id (the "Telegram" service account).
OTP_SENDER_ID = 777000


async def login_all(session_mgr: SessionManager) -> int:
    """Login all accounts from phone.csv and join support channels.

    The support groups come from ``config.ini`` (``support_group`` key) plus
    a small built-in fallback list. A random 20-40 s human-like delay is
    inserted between consecutive joins to reduce ban-risk.

    Returns:
        Number of accounts successfully authenticated.
    """
    cfg = get_config()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Build support-group list: explicit config + default fallbacks.
    support_groups: list[str] = []
    configured = cfg.support_group
    if configured:
        support_groups.append(configured)
    for grp in ("@NMDDER_ch", "@NMDDER_SUPPORT"):
        if grp not in support_groups:
            support_groups.append(grp)

    log.info("Starting login for %d accounts", len(phones))
    logged_in = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] Login %s", idx, len(phones), phone)
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                log.info("%s: logged in as %s", phone, me.first_name or "?")

                for grp in support_groups:
                    if not grp:
                        continue
                    try:
                        await app.join_chat(grp)
                        log.info("%s: joined %s", phone, grp)
                        # Human-like delay between joins.
                        delay = random.randint(20, 40)
                        await asyncio.sleep(delay)
                    except UserAlreadyParticipant:
                        pass
                    except Exception as e:
                        log.warning("%s: join %s failed: %s", phone, grp, e)

                logged_in += 1
        except Exception as e:
            log.error("%s: login failed: %s", phone, e)

    log.info("Login complete: %d/%d", logged_in, len(phones))
    return logged_in


async def otp_viewer() -> None:
    """View latest OTP codes received from Telegram (chat 777000).

    Iterates every account in ``phone.csv`` and prints the most recent
    service message from the official Telegram OTP sender.
    """
    session_mgr = SessionManager()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return

    for phone in phones:
        try:
            async with session_mgr.acquire(phone) as app:
                await _print_latest_otp(app, phone)
        except Exception as e:
            log.error("%s: failed: %s", phone, e)


# ---------------------------------------------------------------------------
# Remove Non-Loggedin Accounts (NEW v1.2.0)
# ---------------------------------------------------------------------------

async def remove_non_loggedin_accounts(
    session_mgr: SessionManager,
    phone_file: str = "phone.csv",
    dry_run: bool = False,
) -> int:
    """Remove phone numbers from ``phone_file`` whose session is unusable.

    A session is considered "non-loginable" if:
    1. The .session file does not exist on disk, OR
    2. The .session file exists but cannot be authenticated (AuthKeyUnregistered,
       SessionRevoked, SessionDuplicated, UserDeactivated, etc.)

    The phone is removed from ``phone.csv`` only after we confirm it's broken.
    The original file is backed up to ``phone.csv.bak.<timestamp>``.

    Args:
        session_mgr: Shared session manager.
        phone_file: Path to phone.csv (default "phone.csv").
        dry_run: If True, only report which accounts would be removed — don't
            modify the CSV file.

    Returns:
        Number of accounts removed from phone.csv.
    """
    import csv as _csv
    import shutil
    from datetime import datetime
    from pathlib import Path

    from pyrogram.errors import (
        AuthKeyUnregistered,
        SessionRevoked,
        SessionDuplicated,
        UserDeactivated,
        UserDeactivatedBan,
        AuthKeyDuplicated,
    )

    # Subclass of exceptions that signal "session dead".
    _DEAD_SESSION_ERRORS = (
        AuthKeyUnregistered,
        SessionRevoked,
        SessionDuplicated,
        UserDeactivated,
        UserDeactivatedBan,
        AuthKeyDuplicated,
    )

    p = Path(phone_file)
    if not p.exists():
        log.error("Phone file not found: %s", phone_file)
        return 0

    phones = load_phones(phone_file)
    if not phones:
        log.warning("Phone file %s is empty — nothing to clean", phone_file)
        return 0

    log.info("Scanning %d accounts for non-loginable sessions", len(phones))

    broken: list[str] = []
    healthy: list[str] = []
    skipped: list[str] = []

    for idx, phone in enumerate(phones, 1):
        # First: check the .session file exists on disk.
        session_name = phone.lstrip("+")
        session_path = session_mgr.sessions_dir / f"{session_name}.session"
        if not session_path.exists():
            log.warning("[%d/%d] %s: NO SESSION FILE — marked broken", idx, len(phones), phone)
            broken.append(phone)
            continue

        # Second: try a real authentication cycle.
        try:
            async with session_mgr.acquire(phone) as app:
                me = await app.get_me()
                log.info(
                    "[%d/%d] %s: OK (logged in as %s)",
                    idx, len(phones), phone, me.first_name or "?",
                )
                healthy.append(phone)
        except _DEAD_SESSION_ERRORS as e:
            log.warning("[%d/%d] %s: DEAD SESSION (%s) — marked broken",
                        idx, len(phones), phone, type(e).__name__)
            broken.append(phone)
        except Exception as e:
            # Don't auto-remove on transient errors (FloodWait, network, etc.)
            err_name = type(e).__name__
            msg_upper = str(e).upper()
            if "FLOOD" in msg_upper or "TIMEOUT" in msg_upper or "CONNECTION" in msg_upper:
                log.warning("[%d/%d] %s: transient error (%s) — KEEP, will retry later",
                            idx, len(phones), phone, err_name)
                skipped.append(phone)
            else:
                log.warning("[%d/%d] %s: unhandled error (%s) — marked broken",
                            idx, len(phones), phone, err_name)
                broken.append(phone)

    log.info(
        "Scan complete: %d healthy / %d broken / %d skipped / %d total",
        len(healthy), len(broken), len(skipped), len(phones),
    )

    if not broken:
        log.info("No non-loginable accounts found — phone.csv unchanged")
        return 0

    if dry_run:
        log.info("[DRY-RUN] Would remove %d accounts: %s",
                 len(broken), ", ".join(broken))
        return 0

    # Backup the original file.
    backup = p.with_suffix(f".csv.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        shutil.copy2(p, backup)
        log.info("Backed up %s → %s", p, backup)
    except Exception as e:
        log.error("Backup failed: %s — aborting (no changes made)", e)
        return 0

    # Rewrite phone.csv with only healthy + skipped (exclude broken).
    keep = healthy + skipped
    try:
        tmp = p.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            w = _csv.writer(f)
            for ph in keep:
                w.writerow([ph])
        import os as _os
        _os.replace(str(tmp), str(p))
        log.info("Removed %d broken accounts from %s", len(broken), phone_file)
        log.info("Kept %d accounts (healthy=%d, skipped=%d)",
                 len(keep), len(healthy), len(skipped))
    except Exception as e:
        log.error("Failed to rewrite %s: %s — restoring from backup", phone_file, e)
        shutil.copy2(backup, p)
        return 0

    return len(broken)


async def _print_latest_otp(app: "Client", phone: str) -> None:
    """Fetch and print the latest OTP message for a single session."""
    log.info("%s: fetching latest OTP", phone)
    try:
        async for msg in app.get_chat_history(OTP_SENDER_ID, limit=1):
            text = msg.text or msg.caption or "(no text)"
            print(f"\n{phone}:")
            print(f"  {text}")
            return
        # No messages returned at all.
        print(f"\n{phone}: no OTP messages")
    except Exception as e:
        log.error("%s: get_chat_history failed: %s", phone, e)


# ---------------------------------------------------------------------------
# 2-Step Verification
# ---------------------------------------------------------------------------

async def set_2fa_password(
    session_mgr: SessionManager,
    password: str,
    current_password: str = "",
    delay: float = 2.0,
    per_account_passwords_csv: str | None = None,
) -> int:
    """Enable (or reset) Telegram 2-Step Verification for all accounts.

    Args:
        session_mgr: Shared session manager.
        password: New 2FA password to set on every account.
        current_password: Existing 2FA password used by all accounts
            (only needed if the accounts already have 2FA enabled).
            If accounts have **different** 2FA passwords, use
            ``per_account_passwords_csv`` instead.
        delay: Delay between accounts.
        per_account_passwords_csv: Optional CSV with columns
            ``phone,current_password``. When provided, each account's
            current password is loaded from this file (overriding
            ``current_password``). Useful when different accounts
            have different 2FA passwords.

    Returns:
        Number of accounts successfully updated.

    Error messages:
        - ``PASSWORD_HASH_INVALID`` → wrong current password.
        - ``PASSWORD_REQUIRED``     → account has 2FA but no password given.
        - ``FRESH_RESET_AUTHORISATION_FORBIDDEN`` → cannot reset within 7 days.
    """
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Load per-account current passwords if a CSV was provided.
    per_account_pw: dict[str, str] = {}
    if per_account_passwords_csv:
        per_account_pw = _load_2fa_passwords_csv(per_account_passwords_csv)
        if not per_account_pw:
            log.warning(
                "%s is empty or unreadable — using global current_password",
                per_account_passwords_csv,
            )

    changed = 0
    wrong_pw_count = 0
    skipped_no_current = 0
    errors_other = 0

    for phone in phones:
        # Per-account password overrides the global one.
        acct_pw = per_account_pw.get(phone, current_password)

        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    # Try direct enable (works if no 2FA is set yet).
                    await app.enable_cloud_password(password)
                    changed += 1
                    log.info("%s: 2FA enabled (new)", phone)
                except Exception as e:
                    err_name = type(e).__name__
                    err_msg = str(e).upper()
                    # Account already has 2FA → must remove first.
                    if not acct_pw:
                        log.warning(
                            "%s: 2FA already enabled; needs current_password to reset",
                            phone,
                        )
                        skipped_no_current += 1
                        continue
                    try:
                        await app.remove_cloud_password(acct_pw)
                        await app.enable_cloud_password(password)
                        changed += 1
                        log.info("%s: 2FA reset", phone)
                    except Exception as e2:
                        reason = _classify_2fa_error(e2)
                        log.error("%s: 2FA reset failed — %s", phone, reason)
                        if reason.startswith("PASSWORD_HASH_INVALID"):
                            wrong_pw_count += 1
                        else:
                            errors_other += 1
                await smart_delay(delay, "fast")
        except Exception as e:
            reason = _classify_2fa_error(e)
            log.error("%s: failed — %s", phone, reason)
            errors_other += 1

    # Final summary.
    log.info(
        "2FA summary: %d set / %d wrong-pw / %d need-current / %d other-errors / %d total",
        changed, wrong_pw_count, skipped_no_current, errors_other, len(phones),
    )
    if wrong_pw_count > 0:
        log.error(
            "%d account(s) had WRONG current password. "
            "Use per_account_passwords_csv with columns 'phone,current_password'.",
            wrong_pw_count,
        )
    if skipped_no_current > 0:
        log.error(
            "%d account(s) already have 2FA but no current_password was provided.",
            skipped_no_current,
        )
    return changed


def _classify_2fa_error(e: Exception) -> str:
    """Map a 2FA-related exception to a short, actionable reason string."""
    msg = str(e).upper()
    if "PASSWORD_HASH_INVALID" in msg:
        return ("PASSWORD_HASH_INVALID — current password is wrong for this account. "
                "If accounts have different passwords, use per_account_passwords_csv.")
    if "PASSWORD_REQUIRED" in msg:
        return ("PASSWORD_REQUIRED — account has 2FA but no current password was "
                "supplied.")
    if "FRESH_RESET_AUTHORISATION_FORBIDDEN" in msg or "FRESH_RESET" in msg:
        return ("FRESH_RESET_FORBIDDEN — Telegram requires a 7-day wait before "
                "fully removing the old password. Try again later.")
    if "PASSWORD_TOO_SHORT" in msg or "NEW_PASSWORD_TOO_SHORT" in msg:
        return "PASSWORD_TOO_SHORT — new password must be at least 8 chars (Telegram rule)."
    if "NEW_SALT_INVALID" in msg:
        return "NEW_SALT_INVALID — internal error, retry needed."
    return f"{type(e).__name__} — {e}"


def _load_2fa_passwords_csv(csv_path: str) -> dict[str, str]:
    """Load ``phone,current_password`` pairs from a CSV.

    Used by :func:`set_2fa_password` when accounts have different
    existing 2FA passwords. Returns a dict mapping phone → password.
    """
    import csv as _csv
    from pathlib import Path

    p = Path(csv_path)
    if not p.exists():
        return {}

    result: dict[str, str] = {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            reader = _csv.DictReader(f)
            for row in reader:
                phone = (row.get("phone") or "").strip()
                pw = (row.get("current_password") or row.get("password") or "").strip()
                if phone and pw:
                    result.setdefault(phone, pw)
    except Exception as e:
        log.error("Failed to read %s: %s", csv_path, e)
    return result


# ---------------------------------------------------------------------------
# Secure login (per-account API + device + proxy rotation)
# ---------------------------------------------------------------------------

async def login_using_security(
    delay: float = 2.0,
    skip_proxy_check: bool = False,
) -> int:
    """Login all accounts with **unique** API + device + proxy per account.

    Reads ``api.csv``, ``devices.csv``, ``proxies.csv`` (any that exist)
    and rotates them so every saved session has a different fingerprint.
    This is the recommended login method for multi-account setups.

    Falls back to ``config.ini`` API values if ``api.csv`` is missing,
    and to the built-in device pool if ``devices.csv`` is missing.

    Args:
        delay: Delay between accounts (seconds).
        skip_proxy_check: If True, skip the pre-flight proxy liveness
            check (faster but riskier).

    Returns:
        Number of accounts that successfully authenticated.
    """
    from pyrogram import Client
    from pyrogram.errors import UserAlreadyParticipant

    from ..core.secure_login import (
        build_secure_client_kwargs,
        check_all_proxies_before_start,
        print_resource_summary,
    )

    cfg = get_config()
    phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    total = len(phones)
    print_resource_summary(total)

    if not skip_proxy_check and not check_all_proxies_before_start(total):
        log.error("Aborting: proxy pre-flight check failed")
        return 0

    # Build the support-group list.
    support_groups: list[str] = []
    configured = cfg.support_group
    if configured:
        support_groups.append(configured)
    for grp in ("@NMDDER_ch", "@NMDDER_SUPPORT"):
        if grp not in support_groups:
            support_groups.append(grp)

    logged_in = 0
    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] Secure-login %s", idx, total, phone)
        try:
            kwargs = build_secure_client_kwargs(
                phone=phone,
                account_index=idx - 1,
                total_accounts=total,
            )
            app = Client(**kwargs)
            await app.start()
            me = await app.get_me()
            log.info(
                "%s: logged in as %s (api=%s, device=%s)",
                phone,
                me.first_name or "?",
                kwargs["api_id"],
                kwargs.get("device_model", "?"),
            )
            for grp in support_groups:
                if not grp:
                    continue
                try:
                    await app.join_chat(grp)
                    log.info("%s: joined %s", phone, grp)
                    await asyncio.sleep(15)  # Shorter than login_all since proxy is already rotating
                except UserAlreadyParticipant:
                    pass
                except Exception as e:
                    log.warning("%s: join %s failed: %s", phone, grp, e)
            await app.stop()
            logged_in += 1
        except Exception as e:
            log.error("%s: secure login failed: %s", phone, e)
        await smart_delay(delay, "fast")

    log.info("Secure login complete: %d/%d", logged_in, total)
    return logged_in
