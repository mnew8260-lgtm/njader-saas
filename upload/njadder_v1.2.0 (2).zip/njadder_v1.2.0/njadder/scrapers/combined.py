"""Combined scrape + add operations.

These functions scrape a source group and immediately act on the
scraped members — adding them as contacts, adding them to a target
group, or both. They are higher-level than :class:`BaseScraper` and
use :class:`BaseAdder`'s pipeline under the hood.
"""
from __future__ import annotations

import asyncio
import csv
import logging
from pathlib import Path
from typing import Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant

from ..config import get_config
from ..core import (
    DedupManager,
    ErrorCounter,
    FloodTracker,
    OpReport,
    SessionManager,
    load_phones,
    progress_bar,
    smart_delay,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Scrape + add as contacts (no group)
# ---------------------------------------------------------------------------

async def scrape_to_contacts(
    session_mgr: SessionManager,
    source_group: str,
    max_per_account: int = 50,
    delay: float = 2.0,
    phones: list[str] | None = None,
) -> int:
    """Scrape a source group and add members as **contacts** (no group add).

    Each account scrapes a chunk of members and adds them via
    ``add_contact``. Useful for building up contact lists across many
    accounts before doing a bulk group-add.

    Returns:
        Number of contacts added.
    """
    if phones is None:
        phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    report = OpReport("scrape_to_contacts")
    total_added = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] %s — scrape + add contacts", idx, len(phones), phone)
        counter = ErrorCounter()
        added = 0
        try:
            async with session_mgr.acquire(phone) as app:
                try:
                    await app.join_chat(source_group)
                except UserAlreadyParticipant:
                    pass
                try:
                    chat = await app.get_chat(source_group)
                except Exception as e:
                    log.error("%s: resolve source failed: %s", phone, e)
                    continue

                try:
                    async for member in app.get_chat_members(chat_id=chat.id):
                        if added >= max_per_account or counter.should_stop():
                            break
                        user = member.user
                        try:
                            await app.add_contact(
                                user.id,
                                user.first_name or "Contact",
                                last_name=user.last_name or "",
                            )
                            added += 1
                            await report.log(
                                account=phone, user_id=user.id,
                                first=user.first_name or "",
                                last=user.last_name or "",
                                username=user.username or "",
                                status="added",
                            )
                            await smart_delay(delay, "add_member")
                        except Exception as e:
                            kind = type(e).__name__
                            counter.add("other")
                            await report.log(
                                account=phone, user_id=user.id,
                                first=user.first_name or "",
                                username=user.username or "",
                                status="skipped", error_type=kind,
                            )
                            if "PeerFlood" in kind:
                                counter.add("peer")
                                break
                            if "FloodWait" in kind:
                                counter.add("flood")
                except Exception as e:
                    log.error("%s: scrape failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

        total_added += added
        log.info("%s: +%d contacts", phone, added)

    log.info("scrape_to_contacts complete: %d added", total_added)
    return total_added


# ---------------------------------------------------------------------------
# Scrape + add to contacts AND target group
# ---------------------------------------------------------------------------

async def scrape_to_contacts_and_group(
    session_mgr: SessionManager,
    source_group: str,
    target_group: str,
    max_per_account: int = 50,
    delay: float = 2.0,
    dedup: DedupManager | None = None,
    flood_tracker: FloodTracker | None = None,
    phones: list[str] | None = None,
) -> int:
    """Scrape source, add as contacts, then add the same users to target.

    Combines :func:`scrape_to_contacts` with a follow-up
    ``add_chat_members`` call per scraped user.

    Returns:
        Number of users added to the target group.
    """
    if phones is None:
        phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    if dedup is None:
        dedup = DedupManager()
    if flood_tracker is None:
        flood_tracker = FloodTracker()

    report = OpReport("scrape_contacts_group")
    total_added = 0

    for idx, phone in enumerate(phones, 1):
        log.info("[%d/%d] %s — scrape + contacts + group", idx, len(phones), phone)
        counter = ErrorCounter()
        added = 0
        try:
            async with session_mgr.acquire(phone) as app:
                # Join both groups.
                for grp in (source_group, target_group):
                    try:
                        await app.join_chat(grp)
                    except UserAlreadyParticipant:
                        pass
                try:
                    src = await app.get_chat(source_group)
                    tgt = await app.get_chat(target_group)
                except Exception as e:
                    log.error("%s: resolve failed: %s", phone, e)
                    continue

                try:
                    async for member in app.get_chat_members(chat_id=src.id):
                        if added >= max_per_account or counter.should_stop():
                            break
                        user = member.user
                        if dedup.is_done(user.id):
                            continue
                        # 1) add_contact
                        try:
                            await app.add_contact(
                                user.id,
                                user.first_name or "Contact",
                                last_name=user.last_name or "",
                            )
                            await asyncio.sleep(0.3)
                        except Exception:
                            pass  # Best-effort — the add_chat_members below is the real test.
                        # 2) add_chat_members
                        try:
                            await app.add_chat_members(tgt.id, user.id)
                            added += 1
                            await dedup.mark_done(
                                user.id, user.first_name or "", user.last_name or "",
                                user.username or "",
                            )
                            await report.log(
                                account=phone, user_id=user.id,
                                first=user.first_name or "",
                                last=user.last_name or "",
                                username=user.username or "",
                                status="added",
                            )
                            await smart_delay(delay, "add_member")
                        except UserAlreadyParticipant:
                            await dedup.mark_done(
                                user.id, user.first_name or "", user.last_name or "",
                                user.username or "",
                            )
                        except Exception as e:
                            kind = type(e).__name__
                            await report.log(
                                account=phone, user_id=user.id,
                                first=user.first_name or "",
                                username=user.username or "",
                                status="skipped", error_type=kind,
                            )
                            if "PeerFlood" in kind:
                                await flood_tracker.mark_flooded(phone)
                                break
                except Exception as e:
                    log.error("%s: scrape failed: %s", phone, e)
        except Exception as e:
            log.error("%s: account failed: %s", phone, e)

        total_added += added
        log.info("%s: +%d to group", phone, added)

    log.info("scrape_to_contacts_and_group complete: %d added", total_added)
    return total_added


# ---------------------------------------------------------------------------
# Filter members to CSV (no add — just write filtered users to a file)
# ---------------------------------------------------------------------------

# Same modes as RamexAdder.
_FILTER_MODES = {"all", "daily", "weekly", "monthly", "online", "nonactive", "hidden"}


async def filter_members_to_csv(
    session_mgr: SessionManager,
    source_group: str,
    mode: str = "all",
    output_csv: str = "filtered.csv",
    limit: int = 5000,
    phones: list[str] | None = None,
) -> int:
    """Scrape a group and write filtered members to a CSV.

    Modes (same as :class:`RamexAdder`):
    - ``all``        — every member.
    - ``daily``      — last seen today.
    - ``weekly``     — last seen within 7 days.
    - ``monthly``    — last seen within 30 days.
    - ``online``     — currently online.
    - ``nonactive``  — last seen > 30 days ago (or unknown).
    - ``hidden``     — scrape from chat history (members hidden by privacy).

    The output CSV has the same schema as ``data.csv`` so it can be
    fed directly to the adders.

    Returns:
        Number of members written to the CSV.
    """
    if mode not in _FILTER_MODES:
        log.error("Invalid mode '%s'. Valid: %s", mode, _FILTER_MODES)
        return 0

    if phones is None:
        phones = load_phones()
    if not phones:
        log.error("No phones in phone.csv")
        return 0

    # Use only the first account for filtering.
    phone = phones[0]
    log.info("Using %s to filter %d members from %s (mode=%s)", phone, limit, source_group, mode)

    from datetime import datetime, timedelta

    now = datetime.utcnow()
    out_path = Path(output_csv)
    fieldnames = ["user_id", "first_name", "last_name", "username", "is_premium", "phone_number"]
    seen: set[int] = set()
    written = 0

    try:
        async with session_mgr.acquire(phone) as app:
            try:
                await app.join_chat(source_group)
            except UserAlreadyParticipant:
                pass
            try:
                chat = await app.get_chat(source_group)
            except Exception as e:
                log.error("Failed to resolve %s: %s", source_group, e)
                return 0

            # Open output file (write header once).
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with open(out_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()

                if mode == "hidden":
                    # Scrape from chat history.
                    try:
                        async for msg in app.get_chat_history(chat.id, limit=limit):
                            if not msg.from_user:
                                continue
                            user = msg.from_user
                            if user.id in seen:
                                continue
                            seen.add(user.id)
                            writer.writerow(
                                {
                                    "user_id": user.id,
                                    "first_name": user.first_name or "",
                                    "last_name": user.last_name or "",
                                    "username": user.username or "",
                                    "is_premium": bool(getattr(user, "is_premium", False)),
                                    "phone_number": getattr(user, "phone_number", "") or "",
                                }
                            )
                            written += 1
                            if (written % 100) == 0:
                                progress_bar(written, limit, label="filtering")
                            if written >= limit:
                                break
                    except Exception as e:
                        log.error("Hidden scrape failed: %s", e)
                else:
                    # Filter-based scraping.
                    try:
                        async for member in app.get_chat_members(chat_id=chat.id):
                            user = member.user
                            if user.id in seen:
                                continue
                            if not _matches_filter(user, mode, now):
                                continue
                            seen.add(user.id)
                            writer.writerow(
                                {
                                    "user_id": user.id,
                                    "first_name": user.first_name or "",
                                    "last_name": user.last_name or "",
                                    "username": user.username or "",
                                    "is_premium": bool(getattr(user, "is_premium", False)),
                                    "phone_number": getattr(user, "phone_number", "") or "",
                                }
                            )
                            written += 1
                            if (written % 100) == 0:
                                progress_bar(written, limit, label="filtering")
                            if written >= limit:
                                break
                    except Exception as e:
                        log.error("Filter scrape failed: %s", e)
    except Exception as e:
        log.error("%s: filter failed: %s", phone, e)

    log.info("filter_members_to_csv complete: %d members → %s", written, output_csv)
    return written


def _matches_filter(user, mode: str, now) -> bool:
    """Check if a user matches the given filter mode (last-seen based)."""
    status = getattr(user, "status", None)
    last_seen = getattr(status, "last_online_date", None) if status else None

    if mode == "all":
        return True
    if mode == "online":
        # Pyrogram's UserStatus enum: "online" or recently.
        status_val = getattr(status, "value", None) if status else None
        return status_val == "online" or str(status).lower().endswith("online")
    if mode == "nonactive":
        if not last_seen:
            return True
        try:
            return (now - last_seen).days > 30
        except Exception:
            return True
    if mode == "daily":
        if not last_seen:
            return False
        try:
            return (now - last_seen).days <= 1
        except Exception:
            return False
    if mode == "weekly":
        if not last_seen:
            return False
        try:
            return (now - last_seen).days <= 7
        except Exception:
            return False
    if mode == "monthly":
        if not last_seen:
            return False
        try:
            return (now - last_seen).days <= 30
        except Exception:
            return False
    return True
