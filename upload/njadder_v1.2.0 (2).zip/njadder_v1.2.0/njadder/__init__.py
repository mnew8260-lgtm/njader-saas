"""njadder — Professional Telegram automation suite.

A modular toolkit for scraping, adding, messaging, and reporting on
Telegram groups. Merges functionality from the legacy ``opthree.py``,
``ramexfour.py``, and ``ts.py`` scripts into a clean, type-safe package.
"""

from __future__ import annotations

__version__ = "1.2.1"
__author__ = "NMDDER"
__license__ = "MIT"

__all__ = [
    "__version__",
    "__author__",
    "__license__",
]
